create table if not exists act_call_log
(
    id                  int(11) unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    process_instance_id varchar(63)         default ''   not null comment '流程实例id',
    execution_id        varchar(63)         default ''   not null comment '任务实例id, 如果是调用方是ExecutionListener, 则对应ExecutionId',
    element_name        varchar(255)        default ''   null comment '任务名称',
    service_type        tinyint(1) unsigned default 1    not null comment '1:Dubbo，2:Http',
    service_entry_point varchar(63)         default ''   not null comment '服务调用的切入地点(TaskListener, ExecutionListener, TaskService)',
    service_path        varchar(510)        default ''   not null comment '服务调用path',
    service_config      varchar(255)        default '{}' null comment '服务调用config配置json数据，zkAddress、version、timeout等',
    service_params      varchar(255)        default '{}' null comment '服务调用参数',
    service_error       varchar(510)        default ''   null comment '服务调用失败错误信息',
    service_error_stack text                             null comment '服务调用失败错误堆栈',
    start_time          datetime                         null comment '服务调用开始时间',
    end_time            datetime                         null comment '服务调用结束时间',
    status              tinyint(1)          default 0    null comment '-1：调用失败，1：调用成功',
    extra_json          varchar(1024)       default '{}' null comment '额外信息',
    created_at          datetime                         not null comment '创建时间',
    updated_at          datetime                         not null comment '修改时间'
)
    collate = utf8_bin;

create table if not exists act_evt_log
(
    LOG_NR_       bigint auto_increment
        constraint `PRIMARY`
        primary key,
    TYPE_         varchar(64)                               null,
    PROC_DEF_ID_  varchar(64)                               null,
    PROC_INST_ID_ varchar(64)                               null,
    EXECUTION_ID_ varchar(64)                               null,
    TASK_ID_      varchar(64)                               null,
    TIME_STAMP_   timestamp(3) default CURRENT_TIMESTAMP(3) not null on update CURRENT_TIMESTAMP(3),
    USER_ID_      varchar(255)                              null,
    DATA_         longblob                                  null,
    LOCK_OWNER_   varchar(255)                              null,
    LOCK_TIME_    timestamp(3)                              null,
    IS_PROCESSED_ tinyint      default 0                    null
)
    collate = utf8_bin;

create table if not exists act_ge_property
(
    NAME_  varchar(64)  not null,
    VALUE_ varchar(300) null,
    REV_   int          null,
    constraint `PRIMARY`
        primary key (NAME_)
)
    collate = utf8_bin;

create table if not exists act_hi_actinst
(
    ID_                varchar(64)             not null,
    PROC_DEF_ID_       varchar(64)             not null,
    PROC_INST_ID_      varchar(64)             not null,
    EXECUTION_ID_      varchar(64)             not null,
    ACT_ID_            varchar(255)            not null,
    TASK_ID_           varchar(64)             null,
    CALL_PROC_INST_ID_ varchar(64)             null,
    ACT_NAME_          varchar(255)            null,
    ACT_TYPE_          varchar(255)            not null,
    ASSIGNEE_          varchar(255)            null,
    START_TIME_        datetime(3)             not null,
    END_TIME_          datetime(3)             null,
    DURATION_          bigint                  null,
    DELETE_REASON_     varchar(4000)           null,
    TENANT_ID_         varchar(255) default '' null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_HI_ACT_INST_END
    on act_hi_actinst (END_TIME_);

create index ACT_IDX_HI_ACT_INST_EXEC
    on act_hi_actinst (EXECUTION_ID_, ACT_ID_);

create index ACT_IDX_HI_ACT_INST_PROCINST
    on act_hi_actinst (PROC_INST_ID_, ACT_ID_);

create index ACT_IDX_HI_ACT_INST_START
    on act_hi_actinst (START_TIME_);

create table if not exists act_hi_attachment
(
    ID_           varchar(64)   not null,
    REV_          int           null,
    USER_ID_      varchar(255)  null,
    NAME_         varchar(255)  null,
    DESCRIPTION_  varchar(4000) null,
    TYPE_         varchar(255)  null,
    TASK_ID_      varchar(64)   null,
    PROC_INST_ID_ varchar(64)   null,
    URL_          varchar(4000) null,
    CONTENT_ID_   varchar(64)   null,
    TIME_         datetime(3)   null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create table if not exists act_hi_comment
(
    ID_           varchar(64)   not null,
    TYPE_         varchar(255)  null,
    TIME_         datetime(3)   not null,
    USER_ID_      varchar(255)  null,
    TASK_ID_      varchar(64)   null,
    PROC_INST_ID_ varchar(64)   null,
    ACTION_       varchar(255)  null,
    MESSAGE_      varchar(4000) null,
    FULL_MSG_     longblob      null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create table if not exists act_hi_detail
(
    ID_           varchar(64)   not null,
    TYPE_         varchar(255)  not null,
    PROC_INST_ID_ varchar(64)   null,
    EXECUTION_ID_ varchar(64)   null,
    TASK_ID_      varchar(64)   null,
    ACT_INST_ID_  varchar(64)   null,
    NAME_         varchar(255)  not null,
    VAR_TYPE_     varchar(255)  null,
    REV_          int           null,
    TIME_         datetime(3)   not null,
    BYTEARRAY_ID_ varchar(64)   null,
    DOUBLE_       double        null,
    LONG_         bigint        null,
    TEXT_         varchar(4000) null,
    TEXT2_        varchar(4000) null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_HI_DETAIL_ACT_INST
    on act_hi_detail (ACT_INST_ID_);

create index ACT_IDX_HI_DETAIL_NAME
    on act_hi_detail (NAME_);

create index ACT_IDX_HI_DETAIL_PROC_INST
    on act_hi_detail (PROC_INST_ID_);

create index ACT_IDX_HI_DETAIL_TASK_ID
    on act_hi_detail (TASK_ID_);

create index ACT_IDX_HI_DETAIL_TIME
    on act_hi_detail (TIME_);

create table if not exists act_hi_identitylink
(
    ID_           varchar(64)  not null,
    GROUP_ID_     varchar(255) null,
    TYPE_         varchar(255) null,
    USER_ID_      varchar(255) null,
    TASK_ID_      varchar(64)  null,
    PROC_INST_ID_ varchar(64)  null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_HI_IDENT_LNK_PROCINST
    on act_hi_identitylink (PROC_INST_ID_);

create index ACT_IDX_HI_IDENT_LNK_TASK
    on act_hi_identitylink (TASK_ID_);

create index ACT_IDX_HI_IDENT_LNK_USER
    on act_hi_identitylink (USER_ID_);

create table if not exists act_hi_procinst
(
    ID_                        varchar(64)             not null,
    PROC_INST_ID_              varchar(64)             not null,
    BUSINESS_KEY_              varchar(255)            null,
    PROC_DEF_ID_               varchar(64)             not null,
    START_TIME_                datetime(3)             not null,
    END_TIME_                  datetime(3)             null,
    DURATION_                  bigint                  null,
    START_USER_ID_             varchar(255)            null,
    START_ACT_ID_              varchar(255)            null,
    END_ACT_ID_                varchar(255)            null,
    SUPER_PROCESS_INSTANCE_ID_ varchar(64)             null,
    DELETE_REASON_             varchar(4000)           null,
    TENANT_ID_                 varchar(255) default '' null,
    NAME_                      varchar(255)            null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint PROC_INST_ID_
        unique (PROC_INST_ID_)
)
    collate = utf8_bin;

create index ACT_IDX_HI_PRO_INST_END
    on act_hi_procinst (END_TIME_);

create index ACT_IDX_HI_PRO_I_BUSKEY
    on act_hi_procinst (BUSINESS_KEY_);

create table if not exists act_hi_taskinst
(
    ID_             varchar(64)             not null,
    PROC_DEF_ID_    varchar(64)             null,
    TASK_DEF_KEY_   varchar(255)            null,
    PROC_INST_ID_   varchar(64)             null,
    EXECUTION_ID_   varchar(64)             null,
    NAME_           varchar(255)            null,
    PARENT_TASK_ID_ varchar(64)             null,
    DESCRIPTION_    varchar(4000)           null,
    OWNER_          varchar(255)            null,
    ASSIGNEE_       varchar(255)            null,
    START_TIME_     datetime(3)             not null,
    CLAIM_TIME_     datetime(3)             null,
    END_TIME_       datetime(3)             null,
    DURATION_       bigint                  null,
    DELETE_REASON_  varchar(4000)           null,
    PRIORITY_       int                     null,
    DUE_DATE_       datetime(3)             null,
    FORM_KEY_       varchar(255)            null,
    CATEGORY_       varchar(255)            null,
    TENANT_ID_      varchar(255) default '' null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_HI_TASK_INST_PROCINST
    on act_hi_taskinst (PROC_INST_ID_);

create table if not exists act_hi_varinst
(
    ID_                varchar(64)   not null,
    PROC_INST_ID_      varchar(64)   null,
    EXECUTION_ID_      varchar(64)   null,
    TASK_ID_           varchar(64)   null,
    NAME_              varchar(255)  not null,
    VAR_TYPE_          varchar(100)  null,
    REV_               int           null,
    BYTEARRAY_ID_      varchar(64)   null,
    DOUBLE_            double        null,
    LONG_              bigint        null,
    TEXT_              varchar(4000) null,
    TEXT2_             varchar(4000) null,
    CREATE_TIME_       datetime(3)   null,
    LAST_UPDATED_TIME_ datetime(3)   null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_HI_PROCVAR_NAME_TYPE
    on act_hi_varinst (NAME_, VAR_TYPE_);

create index ACT_IDX_HI_PROCVAR_PROC_INST
    on act_hi_varinst (PROC_INST_ID_);

create index ACT_IDX_HI_PROCVAR_TASK_ID
    on act_hi_varinst (TASK_ID_);

create table if not exists act_id_group
(
    ID_   varchar(64)  not null,
    REV_  int          null,
    NAME_ varchar(255) null,
    TYPE_ varchar(255) null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create table if not exists act_id_info
(
    ID_        varchar(64)  not null,
    REV_       int          null,
    USER_ID_   varchar(64)  null,
    TYPE_      varchar(64)  null,
    KEY_       varchar(255) null,
    VALUE_     varchar(255) null,
    PASSWORD_  longblob     null,
    PARENT_ID_ varchar(255) null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create table if not exists act_id_user
(
    ID_         varchar(64)  not null,
    REV_        int          null,
    FIRST_      varchar(255) null,
    LAST_       varchar(255) null,
    EMAIL_      varchar(255) null,
    PWD_        varchar(255) null,
    PICTURE_ID_ varchar(64)  null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create table if not exists act_id_membership
(
    USER_ID_  varchar(64) not null,
    GROUP_ID_ varchar(64) not null,
    constraint `PRIMARY`
        primary key (USER_ID_, GROUP_ID_),
    constraint ACT_FK_MEMB_GROUP
        foreign key (GROUP_ID_) references act_id_group (ID_),
    constraint ACT_FK_MEMB_USER
        foreign key (USER_ID_) references act_id_user (ID_)
)
    collate = utf8_bin;

create table if not exists act_re_deployment
(
    ID_             varchar(64)             not null,
    NAME_           varchar(255)            null,
    CATEGORY_       varchar(255)            null,
    KEY_            varchar(255)            null,
    TENANT_ID_      varchar(255) default '' null,
    DEPLOY_TIME_    timestamp(3)            null,
    ENGINE_VERSION_ varchar(255)            null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create table if not exists act_ge_bytearray
(
    ID_            varchar(64)  not null,
    REV_           int          null,
    NAME_          varchar(255) null,
    DEPLOYMENT_ID_ varchar(64)  null,
    BYTES_         longblob     null,
    GENERATED_     tinyint      null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_BYTEARR_DEPL
        foreign key (DEPLOYMENT_ID_) references act_re_deployment (ID_)
)
    collate = utf8_bin;

create table if not exists act_re_model
(
    ID_                           varchar(64)             not null,
    REV_                          int                     null,
    NAME_                         varchar(255)            null,
    KEY_                          varchar(255)            null,
    CATEGORY_                     varchar(255)            null,
    CREATE_TIME_                  timestamp(3)            null,
    LAST_UPDATE_TIME_             timestamp(3)            null,
    VERSION_                      int                     null,
    META_INFO_                    varchar(4000)           null,
    DEPLOYMENT_ID_                varchar(64)             null,
    EDITOR_SOURCE_VALUE_ID_       varchar(64)             null,
    EDITOR_SOURCE_EXTRA_VALUE_ID_ varchar(64)             null,
    TENANT_ID_                    varchar(255) default '' null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_MODEL_DEPLOYMENT
        foreign key (DEPLOYMENT_ID_) references act_re_deployment (ID_),
    constraint ACT_FK_MODEL_SOURCE
        foreign key (EDITOR_SOURCE_VALUE_ID_) references act_ge_bytearray (ID_),
    constraint ACT_FK_MODEL_SOURCE_EXTRA
        foreign key (EDITOR_SOURCE_EXTRA_VALUE_ID_) references act_ge_bytearray (ID_)
)
    collate = utf8_bin;

create table if not exists act_re_procdef
(
    ID_                     varchar(64)             not null,
    REV_                    int                     null,
    CATEGORY_               varchar(255)            null,
    NAME_                   varchar(255)            null,
    KEY_                    varchar(255)            not null,
    VERSION_                int                     not null,
    DEPLOYMENT_ID_          varchar(64)             null,
    RESOURCE_NAME_          varchar(4000)           null,
    DGRM_RESOURCE_NAME_     varchar(4000)           null,
    DESCRIPTION_            varchar(4000)           null,
    HAS_START_FORM_KEY_     tinyint                 null,
    HAS_GRAPHICAL_NOTATION_ tinyint                 null,
    SUSPENSION_STATE_       int                     null,
    TENANT_ID_              varchar(255) default '' null,
    ENGINE_VERSION_         varchar(255)            null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_UNIQ_PROCDEF
        unique (KEY_, VERSION_, TENANT_ID_)
)
    collate = utf8_bin;

create table if not exists act_procdef_info
(
    ID_           varchar(64) not null,
    PROC_DEF_ID_  varchar(64) not null,
    REV_          int         null,
    INFO_JSON_ID_ varchar(64) null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_UNIQ_INFO_PROCDEF
        unique (PROC_DEF_ID_),
    constraint ACT_FK_INFO_JSON_BA
        foreign key (INFO_JSON_ID_) references act_ge_bytearray (ID_),
    constraint ACT_FK_INFO_PROCDEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_INFO_PROCDEF
    on act_procdef_info (PROC_DEF_ID_);

create table if not exists act_ru_execution
(
    ID_                   varchar(64)             not null,
    REV_                  int                     null,
    PROC_INST_ID_         varchar(64)             null,
    BUSINESS_KEY_         varchar(255)            null,
    PARENT_ID_            varchar(64)             null,
    PROC_DEF_ID_          varchar(64)             null,
    SUPER_EXEC_           varchar(64)             null,
    ROOT_PROC_INST_ID_    varchar(64)             null,
    ACT_ID_               varchar(255)            null,
    IS_ACTIVE_            tinyint                 null,
    IS_CONCURRENT_        tinyint                 null,
    IS_SCOPE_             tinyint                 null,
    IS_EVENT_SCOPE_       tinyint                 null,
    IS_MI_ROOT_           tinyint                 null,
    SUSPENSION_STATE_     int                     null,
    CACHED_ENT_STATE_     int                     null,
    TENANT_ID_            varchar(255) default '' null,
    NAME_                 varchar(255)            null,
    START_TIME_           datetime(3)             null,
    START_USER_ID_        varchar(255)            null,
    LOCK_TIME_            timestamp(3)            null,
    IS_COUNT_ENABLED_     tinyint                 null,
    EVT_SUBSCR_COUNT_     int                     null,
    TASK_COUNT_           int                     null,
    JOB_COUNT_            int                     null,
    TIMER_JOB_COUNT_      int                     null,
    SUSP_JOB_COUNT_       int                     null,
    DEADLETTER_JOB_COUNT_ int                     null,
    VAR_COUNT_            int                     null,
    ID_LINK_COUNT_        int                     null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_EXE_PARENT
        foreign key (PARENT_ID_) references act_ru_execution (ID_)
            on delete cascade,
    constraint ACT_FK_EXE_PROCDEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_),
    constraint ACT_FK_EXE_PROCINST
        foreign key (PROC_INST_ID_) references act_ru_execution (ID_)
            on update cascade on delete cascade,
    constraint ACT_FK_EXE_SUPER
        foreign key (SUPER_EXEC_) references act_ru_execution (ID_)
            on delete cascade
)
    collate = utf8_bin;

create table if not exists act_ru_deadletter_job
(
    ID_                  varchar(64)             not null,
    REV_                 int                     null,
    TYPE_                varchar(255)            not null,
    EXCLUSIVE_           tinyint(1)              null,
    EXECUTION_ID_        varchar(64)             null,
    PROCESS_INSTANCE_ID_ varchar(64)             null,
    PROC_DEF_ID_         varchar(64)             null,
    EXCEPTION_STACK_ID_  varchar(64)             null,
    EXCEPTION_MSG_       varchar(4000)           null,
    DUEDATE_             timestamp(3)            null,
    REPEAT_              varchar(255)            null,
    HANDLER_TYPE_        varchar(255)            null,
    HANDLER_CFG_         varchar(4000)           null,
    TENANT_ID_           varchar(255) default '' null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_DEADLETTER_JOB_EXCEPTION
        foreign key (EXCEPTION_STACK_ID_) references act_ge_bytearray (ID_),
    constraint ACT_FK_DEADLETTER_JOB_EXECUTION
        foreign key (EXECUTION_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_DEADLETTER_JOB_PROCESS_INSTANCE
        foreign key (PROCESS_INSTANCE_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_DEADLETTER_JOB_PROC_DEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_)
)
    collate = utf8_bin;

create table if not exists act_ru_event_subscr
(
    ID_            varchar(64)                               not null,
    REV_           int                                       null,
    EVENT_TYPE_    varchar(255)                              not null,
    EVENT_NAME_    varchar(255)                              null,
    EXECUTION_ID_  varchar(64)                               null,
    PROC_INST_ID_  varchar(64)                               null,
    ACTIVITY_ID_   varchar(64)                               null,
    CONFIGURATION_ varchar(255)                              null,
    CREATED_       timestamp(3) default CURRENT_TIMESTAMP(3) not null,
    PROC_DEF_ID_   varchar(64)                               null,
    TENANT_ID_     varchar(255) default ''                   null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_EVENT_EXEC
        foreign key (EXECUTION_ID_) references act_ru_execution (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_EVENT_SUBSCR_CONFIG_
    on act_ru_event_subscr (CONFIGURATION_);

create index ACT_IDC_EXEC_ROOT
    on act_ru_execution (ROOT_PROC_INST_ID_);

create index ACT_IDX_EXEC_BUSKEY
    on act_ru_execution (BUSINESS_KEY_);

create table if not exists act_ru_job
(
    ID_                  varchar(64)             not null,
    REV_                 int                     null,
    TYPE_                varchar(255)            not null,
    LOCK_EXP_TIME_       timestamp(3)            null,
    LOCK_OWNER_          varchar(255)            null,
    EXCLUSIVE_           tinyint(1)              null,
    EXECUTION_ID_        varchar(64)             null,
    PROCESS_INSTANCE_ID_ varchar(64)             null,
    PROC_DEF_ID_         varchar(64)             null,
    RETRIES_             int                     null,
    EXCEPTION_STACK_ID_  varchar(64)             null,
    EXCEPTION_MSG_       varchar(4000)           null,
    DUEDATE_             timestamp(3)            null,
    REPEAT_              varchar(255)            null,
    HANDLER_TYPE_        varchar(255)            null,
    HANDLER_CFG_         varchar(4000)           null,
    TENANT_ID_           varchar(255) default '' null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_JOB_EXCEPTION
        foreign key (EXCEPTION_STACK_ID_) references act_ge_bytearray (ID_),
    constraint ACT_FK_JOB_EXECUTION
        foreign key (EXECUTION_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_JOB_PROCESS_INSTANCE
        foreign key (PROCESS_INSTANCE_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_JOB_PROC_DEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_)
)
    collate = utf8_bin;

create table if not exists act_ru_suspended_job
(
    ID_                  varchar(64)             not null,
    REV_                 int                     null,
    TYPE_                varchar(255)            not null,
    EXCLUSIVE_           tinyint(1)              null,
    EXECUTION_ID_        varchar(64)             null,
    PROCESS_INSTANCE_ID_ varchar(64)             null,
    PROC_DEF_ID_         varchar(64)             null,
    RETRIES_             int                     null,
    EXCEPTION_STACK_ID_  varchar(64)             null,
    EXCEPTION_MSG_       varchar(4000)           null,
    DUEDATE_             timestamp(3)            null,
    REPEAT_              varchar(255)            null,
    HANDLER_TYPE_        varchar(255)            null,
    HANDLER_CFG_         varchar(4000)           null,
    TENANT_ID_           varchar(255) default '' null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_SUSPENDED_JOB_EXCEPTION
        foreign key (EXCEPTION_STACK_ID_) references act_ge_bytearray (ID_),
    constraint ACT_FK_SUSPENDED_JOB_EXECUTION
        foreign key (EXECUTION_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_SUSPENDED_JOB_PROCESS_INSTANCE
        foreign key (PROCESS_INSTANCE_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_SUSPENDED_JOB_PROC_DEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_)
)
    collate = utf8_bin;

create table if not exists act_ru_task
(
    ID_               varchar(64)             not null,
    REV_              int                     null,
    EXECUTION_ID_     varchar(64)             null,
    PROC_INST_ID_     varchar(64)             null,
    PROC_DEF_ID_      varchar(64)             null,
    NAME_             varchar(255)            null,
    PARENT_TASK_ID_   varchar(64)             null,
    DESCRIPTION_      varchar(4000)           null,
    TASK_DEF_KEY_     varchar(255)            null,
    OWNER_            varchar(255)            null,
    ASSIGNEE_         varchar(255)            null,
    DELEGATION_       varchar(64)             null,
    PRIORITY_         int                     null,
    CREATE_TIME_      timestamp(3)            null,
    DUE_DATE_         datetime(3)             null,
    CATEGORY_         varchar(255)            null,
    SUSPENSION_STATE_ int                     null,
    TENANT_ID_        varchar(255) default '' null,
    FORM_KEY_         varchar(255)            null,
    CLAIM_TIME_       datetime(3)             null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_TASK_EXE
        foreign key (EXECUTION_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_TASK_PROCDEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_),
    constraint ACT_FK_TASK_PROCINST
        foreign key (PROC_INST_ID_) references act_ru_execution (ID_)
)
    collate = utf8_bin;

create table if not exists act_ru_identitylink
(
    ID_           varchar(64)  not null,
    REV_          int          null,
    GROUP_ID_     varchar(255) null,
    TYPE_         varchar(255) null,
    USER_ID_      varchar(255) null,
    TASK_ID_      varchar(64)  null,
    PROC_INST_ID_ varchar(64)  null,
    PROC_DEF_ID_  varchar(64)  null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_ATHRZ_PROCEDEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_),
    constraint ACT_FK_IDL_PROCINST
        foreign key (PROC_INST_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_TSKASS_TASK
        foreign key (TASK_ID_) references act_ru_task (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_ATHRZ_PROCEDEF
    on act_ru_identitylink (PROC_DEF_ID_);

create index ACT_IDX_IDENT_LNK_GROUP
    on act_ru_identitylink (GROUP_ID_);

create index ACT_IDX_IDENT_LNK_USER
    on act_ru_identitylink (USER_ID_);

create index ACT_DUE_DATE
    on act_ru_task (DUE_DATE_);

create index ACT_IDX_TASK_CREATE
    on act_ru_task (CREATE_TIME_);

create table if not exists act_ru_timer_job
(
    ID_                  varchar(64)             not null,
    REV_                 int                     null,
    TYPE_                varchar(255)            not null,
    LOCK_EXP_TIME_       timestamp(3)            null,
    LOCK_OWNER_          varchar(255)            null,
    EXCLUSIVE_           tinyint(1)              null,
    EXECUTION_ID_        varchar(64)             null,
    PROCESS_INSTANCE_ID_ varchar(64)             null,
    PROC_DEF_ID_         varchar(64)             null,
    RETRIES_             int                     null,
    EXCEPTION_STACK_ID_  varchar(64)             null,
    EXCEPTION_MSG_       varchar(4000)           null,
    DUEDATE_             timestamp(3)            null,
    REPEAT_              varchar(255)            null,
    HANDLER_TYPE_        varchar(255)            null,
    HANDLER_CFG_         varchar(4000)           null,
    TENANT_ID_           varchar(255) default '' null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_TIMER_JOB_EXCEPTION
        foreign key (EXCEPTION_STACK_ID_) references act_ge_bytearray (ID_),
    constraint ACT_FK_TIMER_JOB_EXECUTION
        foreign key (EXECUTION_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_TIMER_JOB_PROCESS_INSTANCE
        foreign key (PROCESS_INSTANCE_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_TIMER_JOB_PROC_DEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_)
)
    collate = utf8_bin;

create table if not exists act_ru_variable
(
    ID_           varchar(64)   not null,
    REV_          int           null,
    TYPE_         varchar(255)  not null,
    NAME_         varchar(255)  not null,
    EXECUTION_ID_ varchar(64)   null,
    PROC_INST_ID_ varchar(64)   null,
    TASK_ID_      varchar(64)   null,
    BYTEARRAY_ID_ varchar(64)   null,
    DOUBLE_       double        null,
    LONG_         bigint        null,
    TEXT_         varchar(4000) null,
    TEXT2_        varchar(4000) null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_VAR_BYTEARRAY
        foreign key (BYTEARRAY_ID_) references act_ge_bytearray (ID_),
    constraint ACT_FK_VAR_EXE
        foreign key (EXECUTION_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_VAR_PROCINST
        foreign key (PROC_INST_ID_) references act_ru_execution (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_VARIABLE_TASK_ID
    on act_ru_variable (TASK_ID_);

create table if not exists flow_apply
(
    id            bigint auto_increment comment '自增主键'
        constraint `PRIMARY`
        primary key,
    flow_id       varchar(63) charset utf8        not null comment '流程实例id',
    flow_name     varchar(127) charset utf8       not null comment '流程实例名称',
    type_id       bigint                          not null comment '流程类型表外键',
    type_name     varchar(31) default ''          not null comment '类型名称',
    biz_id        varchar(63) charset utf8        null comment '业务id',
    biz_type      varchar(63) charset utf8        null comment '业务类型',
    biz_detail    text collate utf8mb4_unicode_ci null comment '业务详情信息',
    status        varchar(31) charset utf8        not null comment '审核状态',
    extra_json    text charset utf8               null comment '额外信息',
    creator_id    varchar(31) charset utf8        not null comment '创建人id',
    creator_name  varchar(63) charset utf8        not null comment '创建人名称',
    created_at    datetime                        not null comment '创建时间',
    updated_at    datetime                        not null comment '更新时间',
    biz_type_name varchar(255) charset utf8       null comment '业务类型名称'
)
    comment '流程申请记录表';

create table if not exists flow_apps
(
    id               bigint unsigned auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    parent_id        bigint unsigned default 0  null comment '当不为0时，表示他是由deafult_app下拷贝生成的',
    name             varchar(31)     default '' null comment 'app名称',
    tenant_id        varchar(31)                null comment '租户id，is_default为1时tenant_id为null',
    tenant_name      varchar(31)     default '' null comment '租户名称',
    creator_id       varchar(31)     default '' not null comment '创建用户的id',
    creator_name     varchar(31)     default '' null comment '创建用户的用户名',
    description      varchar(255)    default '' null comment '系统描述',
    image            varchar(1022)   default '' null comment 'app图片',
    is_default       tinyint(1)                 not null comment '0-非默认app,1-默认app',
    server_host_json varchar(2046)              null comment 'http调用地址映射',
    status           tinyint(1)      default 0  null comment '-1:已删除,0:待发布,1:已发布',
    extra_json       varchar(1022)   default '' null comment '额外信息',
    created_at       datetime                   not null,
    updated_at       datetime                   not null
)
    comment '应用系统';

create table if not exists flow_config
(
    id                 bigint unsigned auto_increment comment '编号'
        constraint `PRIMARY`
        primary key,
    biz_type           varchar(64)     null comment '业务类型编码',
    biz_name           varchar(128)    null comment '业务名称',
    parent_system_code varchar(64)     null comment '父系统编码',
    system_code        varchar(64)     null comment '系统编码',
    process_def_key    varchar(100)    null comment '审批流程定义key',
    process_def_name   varchar(255)    null comment '审批流程定义名称',
    flow_app_id        bigint unsigned null comment '流程应用Id',
    flow_type_id       bigint unsigned null comment '流程类型Id',
    flow_type_name     varchar(31)     null comment '流程类型名称',
    extra_json         text            null comment '额外信息',
    created_at         datetime        null comment '创建时间',
    created_by         bigint          null comment '创建者',
    updated_at         datetime        null comment '更新时间',
    updated_by         bigint          null comment '更新者'
)
    comment '审批流配置表';

create table if not exists flow_entrust_log
(
    id             bigint unsigned auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    creator_id     varchar(31)          not null comment '委托人id',
    creator_name   varchar(128)         not null comment '委托人名称',
    target_id      varchar(31)          not null comment '被委托人id',
    target_name    varchar(128)         not null comment '被委托人名称',
    process_json   text                 null comment '被委托流程唯一标示',
    is_all_process tinyint(1) default 0 not null comment '是否是全流程委托 1-是 0-否',
    is_switch_open tinyint(1)           not null comment '委托开关 true-开 false-关',
    start_at       datetime             not null comment '委托开始时间',
    end_at         datetime             not null comment '委托结束时间',
    created_at     datetime             not null,
    updated_at     datetime             not null
)
    comment '委托记录表';

create index creator_view_query
    on flow_entrust_log (end_at, start_at, creator_id)
    comment '委托人视角查询';

create index target_view_query
    on flow_entrust_log (end_at, start_at, target_id)
    comment '被委托人视角查询';

create table if not exists flow_export_task
(
    id           bigint auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    name         varchar(127)      not null comment '任务名称',
    flow_id      varchar(63)       not null comment '流程实例id',
    file_name    varchar(63)       null comment '文件名称',
    file_url     varchar(255)      null comment '文件下载链接',
    status       varchar(31)       null comment '导出状态 WAITING-待导出 SUCCESS-导出成功 FAILED-导出失败',
    retry_count  int(10) default 0 not null comment '重试次数',
    cause        varchar(500)      null comment '错误原因',
    extra_json   text              null comment '额外信息',
    creator_id   varchar(31)       not null comment '创建人id',
    creator_name varchar(63)       not null comment '创建人名称',
    created_at   datetime          not null comment '创建时间',
    updated_at   datetime          not null comment '更新时间'
)
    comment '流程导出任务表' charset = utf8;

create table if not exists flow_model_scopes
(
    id           int(11) unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    type_id      bigint unsigned          not null comment 'flow_types Id',
    app_id       bigint unsigned          not null comment 'flow_app Id',
    app_name     varchar(63)   default '' not null comment 'flow_app name',
    tenant_id    varchar(31)   default '' not null comment '租户id',
    tenant_name  varchar(31)   default '' not null comment '租户名称',
    company_id   bigint unsigned          null comment '公司Id',
    company_name varchar(63)   default '' null comment '公司名称',
    creator_id   varchar(31)   default '' not null comment '创建用户的id',
    creator_name varchar(31)   default '' null comment '创建用户的用户名',
    model_id     bigint unsigned          not null comment 'flow_models Id',
    model_name   varchar(31)   default '' not null comment 'flow_models name',
    extra_json   varchar(1022) default '' null comment '额外信息',
    created_at   datetime                 not null,
    updated_at   datetime                 not null
)
    comment '流程具体适用范围表';

create table if not exists flow_models
(
    id                    int(11) unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    app_id                bigint unsigned              not null comment '应用系统外键',
    type_id               bigint                       not null comment '流程类型表外键',
    type_name             varchar(31)     default ''   not null comment '类型名称',
    definition            tinyint         default 2    null comment '流程类型定义：1、业务流程，2、审批流',
    tenant_id             varchar(31)                  null comment '租户id，is_default为1时tenant_id为null',
    tenant_name           varchar(31)     default ''   null comment '租户名称',
    parent_id             bigint unsigned default 0    not null comment '当不为null时，表示他是由deafult_app下拷贝生成的',
    creator_id            varchar(31)     default ''   not null comment '创建用户的id',
    creator_name          varchar(128)    default ''   null comment '创建用户的用户名',
    process_key           varchar(63)                  not null comment '唯一标识流程的key，用于后端检索流程定义（同时相同key的流程定义，已发布的只能存在一个）',
    process_definition_id varchar(63)     default ''   null comment '关联的activiti中的流程定义编号',
    name                  varchar(31)                  not null comment '流程名称, 默认取流程类型名称',
    serial_number_prefix  varchar(7)      default 'FP' not null,
    description           varchar(255)    default ''   null comment '流程简介',
    version               int             default 0    not null comment '版本号，成功发布后递增',
    activit_editor_xml    longtext                     null comment '序列化存储到Activiti中的流程&节点数据',
    model_error_json      varchar(4096)                null comment '配置错误',
    flow_node_json        longtext                     null comment '存储业务系统的状态机、挂载需要渲染的前端页面路径、执行人权限的设定',
    flow_sequence_json    longtext                     null comment '存储流程线上的条件表达式',
    default_config_json   longtext                     null comment '流程默认配置',
    is_default            tinyint(1)                   not null comment '0-非默认,1-默认',
    status                tinyint(1)      default 0    not null comment '-1:已删除,0:正在编辑,1:已发布,2:历史版本',
    is_switch_open        tinyint(1)      default 1    null comment '1-可执行 0-不可执行',
    affiliation_code      varchar(15)                  null comment '流程归属编码',
    affiliation_name      varchar(15)                  null comment '流程归属名称',
    extra_json            varchar(1022)   default ''   null comment '额外信息',
    publish_at            datetime                     null comment '发布时间',
    created_at            datetime                     not null,
    updated_at            datetime                     not null
)
    comment '流程模型数据';

create index defId
    on flow_models (process_definition_id);

create table if not exists flow_notice_log
(
    id                         int(11) unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    error_type                 tinyint(1)             null comment '错误状态',
    execution_id               varchar(63) default '' not null,
    target_value               varchar(1022)          null comment '消息接收方id集合',
    send_to_process_creator    tinyint(1)             null comment '为 true 时表示发送给流程创建人',
    process_instance_creatorId varchar(31)            null comment '流程创建人id',
    send_to_candidate          tinyint(1)             null comment '为 true 时表示发送给当前节点的所有候选人',
    task_candidate_value       varchar(510)           null comment '节点候选人的值',
    sms_json_string            varchar(510)           null comment '短信数据类',
    station_letter_json_string varchar(510)           null comment '站内信数据类',
    email_json_string          varchar(510)           null comment '邮件信数据类',
    error_message              varchar(255)           null comment '错误信息',
    error_stack                varchar(1022)          null comment '错误堆栈信息',
    extra_json                 varchar(510)           null,
    created_at                 date                   null,
    updated_at                 date                   null,
    constraint execution_id
        unique (execution_id)
);

create table if not exists flow_service_dice_reference
(
    id                    bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    user_custom_config_id bigint unsigned not null comment '自定义配置id',
    service_dict_id       bigint unsigned not null comment '服务字典id'
)
    comment '自定义服务配置与引用的服务字典关系表' collate = utf8mb4_unicode_ci;

create index service_dict_id
    on flow_service_dice_reference (service_dict_id);

create index user_custom_config_id
    on flow_service_dice_reference (user_custom_config_id);

create table if not exists flow_service_dict
(
    id             bigint unsigned auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    name           varchar(31)              not null comment '服务名称',
    expression     varchar(1022)            not null comment '服务地址json字符',
    expressionType varchar(31)              not null comment '服务类型 dubbo, http, delegateExpression',
    description    varchar(255)  default '' null comment '描述',
    extra_json     varchar(1022) default '' null comment '额外信息',
    created_at     datetime                 not null,
    updated_at     datetime                 not null,
    constraint `name-unique`
        unique (name)
)
    comment '服务字典表';

create table if not exists flow_task_log
(
    id                       bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id                varchar(31)            null comment '租户编号',
    tenant_name              varchar(20)            null comment '租户名称',
    company_id               varchar(31)            null comment '公司id',
    company_name             varchar(31)            null comment '公司名',
    type_id                  bigint                 not null comment '流程类型表外键',
    type_name                varchar(31) default '' not null comment '类型名称',
    model_id                 bigint unsigned        null comment '流程模型id',
    definition               tinyint     default 2  null comment '流程类型定义：1、业务流程，2、审批流',
    log_type                 tinyint                null comment '1:发起的流程，2:待办任务',
    candidate_type           int(10)                null comment '处理人类型',
    candidate_index          varchar(127)           null comment '候选索引',
    candidate_value          varchar(127)           null comment '候选索引值',
    user_id                  varchar(31)            null comment '任务处理人编号',
    user_name                varchar(127)           null comment '任务处理人名称',
    left_user_id             varchar(31)            null comment '上一节点处理人',
    left_user_name           varchar(127)           null comment '上一节点处理人名称',
    process_create_user_id   varchar(31)            null comment '任务创建人id',
    process_create_user_name varchar(127)           null comment '任务创建人名称',
    process_instance_id      varchar(63)            null comment '流程实例id',
    process_serial_number    varchar(31)            null comment '流程业务流水号',
    process_name             varchar(63)            null comment '流程名称',
    task_id                  varchar(63)            null comment '任务id',
    task_name                varchar(63)            null comment '任务名称',
    task_description         varchar(255)           null comment '任务描述',
    view_path                varchar(255)           null comment '审核页面路径',
    module_name              varchar(31)            null comment '模块名称',
    status                   tinyint     default 0  null comment '0：待处理，1：已处理，-1：不能再处理',
    is_simulate              tinyint     default 0  not null comment '是否是模拟流程',
    claim_time               datetime               null comment '任务认领时间',
    start_time               datetime               null comment '任务开始时间',
    end_time                 datetime               null comment '任务结束时间',
    extra_json               text                   null comment '额外信息',
    created_at               datetime               not null,
    updated_at               datetime               not null,
    fiduciary_json           text                   null comment '受托人信息'
)
    comment '任务列表';

create index idx_candidate_index
    on flow_task_log (candidate_index);

create index idx_candidate_type
    on flow_task_log (candidate_type);

create index idx_process_instance_id
    on flow_task_log (process_instance_id);

create index idx_task_id
    on flow_task_log (task_id);

create index idx_user_id
    on flow_task_log (user_id);

create table if not exists flow_task_reject_log
(
    id                  int(11) unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    source_task_def_id  varchar(31) default '' not null comment '跳转的源节点定义id',
    target_task_def_id  varchar(31) default '' not null comment '跳转的目标节点定义id',
    reject_user_id      varchar(31)            null comment '发起驳回的用户id',
    reject_user_name    varchar(31)            null comment '发起驳回的用户名称',
    process_def_id      varchar(63)            not null comment '流程定义id',
    process_instance_id varchar(63) default '' not null comment '流程实例id',
    need_turn_back      tinyint(1)  default 0  not null comment '是否需要返回源节点',
    already_turn_back   tinyint(1)  default 0  not null comment '是否已经返回源节点',
    extra_json          varchar(1022)          null comment '额外信息',
    created_at          datetime               not null,
    updated_at          datetime               not null
);

create table if not exists flow_types
(
    id                     bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    app_id                 bigint unsigned                not null comment 'flow_app表的外键',
    parent_id              bigint unsigned     default 0  null comment '当不为null时，表示他是由deafult_app下拷贝生成的',
    name                   varchar(128)        default '' not null comment '类型名称',
    definition             tinyint             default 2  null comment '流程类型定义：1、业务流程，2、审批流',
    tenant_id              varchar(31)                    null comment '租户id，is_default为1时tenant_id为null',
    tenant_name            varchar(31)         default '' null comment '租户名称',
    creator_id             varchar(31)         default '' not null comment '创建用户的id',
    creator_name           varchar(128)        default '' null comment '创建用户的用户名',
    description            varchar(255)        default '' null comment 'type描述',
    is_user_customize_flow tinyint(1) unsigned default 0  null comment '是否是用户自定义流程类型',
    bpmn_data              varchar(2046)       default '' null comment '用户自定义流程的预设数据',
    web_view_conf          varchar(2046)       default '' null comment '用户自定义流程时，用于保存前端页面的显示配置',
    view_bind              varchar(1022)                  null,
    flow_status            varchar(1022)       default '' null comment 'type下的状态机集合json，status更改不对model中引用的状态机更改',
    is_default             tinyint(1)                     not null comment '0-非默认,1-默认',
    status                 tinyint(1)          default 1  null comment '-1:已删除，1:正常',
    extra_json             varchar(1022)       default '' null comment '额外信息',
    created_at             datetime                       not null,
    updated_at             datetime                       not null
)
    comment '流程类型表';

create table if not exists flow_user_custom_config
(
    id                      bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    flow_type_id            bigint unsigned        not null comment '流程类型外键',
    specific_type           tinyint(11) unsigned   not null comment '自定义节点类型',
    name                    varchar(15) default '' not null comment '节点名称',
    listeners               text                   null comment '节点监听器配置',
    form_variables          text                   null comment '节点表单变量配置',
    view_path               varchar(31)            null comment '节点所绑定的页面',
    result_keys             varchar(2046)          null comment '节点返回结果描述',
    url_keys                varchar(2046)          null comment '待办列表返回结果变量',
    `condition`             varchar(255)           null comment '流程执行条件',
    flow_notice_json_string text                   null,
    created_at              datetime               not null,
    updated_at              datetime               not null
)
    comment '流程自定义数据表';

create table if not exists flow_user_info
(
    id              bigint unsigned auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id       bigint            null comment '租户编号',
    tenant_name     varchar(64)       null comment '租户名称',
    company_id      bigint unsigned   null comment '公司 Id',
    company_name    varchar(200)      null comment '公司名称',
    user_id         bigint unsigned   null comment '用户 Id',
    user_name       varchar(255)      null comment '用户名称',
    oa_code         varchar(100)      null comment '员工OA编号',
    real_name       varchar(20)       null comment '真实姓名',
    email           varchar(255)      null comment '邮箱',
    phone           varchar(20)       null comment '手机号',
    freeze_status   tinyint default 0 not null comment '0：正常;1:冻结状态 ',
    user_type       tinyint default 1 null comment '用户类型，1：Design管理员；2：租户管理员；',
    audit_user_id   varchar(64)       null comment '审核人',
    audit_user_name varchar(64)       null comment '审核人名称',
    audit_status    tinyint default 0 null comment '审核状态,0:待审核；1：审核通过；-1：审核不通过',
    audit_content   varchar(200)      null comment '审核意见',
    audit_time      datetime          null comment '审核时间',
    created_at      datetime          not null comment '创建时间',
    updated_at      datetime          not null comment '最后更新时间',
    is_deleted      tinyint default 0 null comment '是否删除'
)
    comment '授权用户信息表';


