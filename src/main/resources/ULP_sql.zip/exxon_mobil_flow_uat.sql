create table if not exists flow_config
(
    id               bigint unsigned auto_increment comment '编号'
        constraint `PRIMARY`
        primary key,
    biz_type         varchar(64)     null comment '业务类型编码',
    biz_name         varchar(128)    null comment '业务名称',
    system_code      varchar(64)     null comment '系统编码',
    process_def_key  varchar(100)    null comment '审批流程定义key',
    process_def_name varchar(255)    null comment '审批流程定义名称',
    flow_app_id      bigint unsigned null comment '流程应用Id',
    flow_type_id     bigint unsigned null comment '流程类型Id',
    flow_type_name   varchar(31)     null comment '流程类型名称',
    extra_json       text            null comment '额外信息',
    created_at       datetime        null comment '创建时间',
    created_by       bigint          null comment '创建者',
    updated_at       datetime        null comment '更新时间',
    updated_by       bigint          null comment '更新者'
)
    comment '审批流配置表';


