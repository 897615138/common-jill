create table if not exists scorpio_abnormal_member_temp
(
    id                    bigint unsigned auto_increment comment '自增主键'
        constraint `PRIMARY`
        primary key,
    member_id             bigint       not null comment '会员ID',
    zone_name             varchar(128) null comment '区部名称',
    member_card           varchar(128) null comment '会员卡号',
    register_shop_name    varchar(128) null comment '注册店铺名称',
    register_shop_code    varchar(128) null comment '注册店铺代码',
    register_shop_company varchar(128) null comment '注册店铺公司代码',
    serve_shop_name       varchar(128) null comment '服务店铺名称',
    serve_shop_code       varchar(128) null comment '服务店铺代码',
    serve_shop_company    varchar(128) null comment '服务店铺公司代码',
    reason                varchar(200) null comment '异常原因'
)
    comment '临时异常用户信息表';

create table if not exists scorpio_apply
(
    id           bigint auto_increment comment '主键id'
        constraint `PRIMARY`
        primary key,
    apply_id     varchar(100) default '0'               not null comment '申请id',
    member_id    bigint                                 not null comment '会员id',
    type         varchar(50)                            not null comment '类型: 单笔积分解冻,会员积分账户解冻',
    apply_status varchar(20)                            null comment '申请状态',
    apply_json   text                                   null comment '申请表单',
    reason       varchar(255)                           null comment '解冻原因',
    created_by   varchar(255)                           null comment '创建人',
    updated_by   varchar(255) charset utf8              null comment '修改人',
    created_at   timestamp    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at   timestamp    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    ext1         varchar(255)                           null comment '拓展字段1',
    ext2         varchar(255)                           null comment '拓展字段2',
    ext3         varchar(255)                           null comment '拓展字段3',
    extra_json   varchar(512)                           null comment '拓展json'
)
    comment '积分解冻申请表';

create table if not exists scorpio_behavior
(
    id                  int(6) auto_increment comment '主键id'
        constraint `PRIMARY`
        primary key,
    behavior            varchar(50)                         not null comment '行为',
    behavior_name       varchar(255)                        not null comment '行为名称',
    subject             varchar(20)                         not null comment '主体',
    value_operator_type varchar(10)                         not null comment '值操作类型',
    created_at          timestamp default CURRENT_TIMESTAMP not null comment '操作时间',
    constraint idx_behavior
        unique (behavior)
)
    comment '行为表';

create index idx_subject
    on scorpio_behavior (subject);

create table if not exists scorpio_delayed_delivery_member
(
    id            bigint auto_increment comment '主键id'
        constraint `PRIMARY`
        primary key,
    member_id     bigint                              not null comment '会员id',
    strategy_id   bigint                              not null comment '触发风控id',
    strategy_name varchar(50)                         not null comment '触发风控名称',
    created_at    timestamp default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '创建时间'
)
    comment '延迟发货会员列表';

create table if not exists scorpio_email
(
    id              int(6) auto_increment comment '主键ID'
        constraint `PRIMARY`
        primary key,
    email           varchar(64)                         not null comment '邮箱账号',
    status          varchar(20)                         not null comment '邮箱状态',
    updated_by      varchar(255)                        null comment '操作人',
    created_at      timestamp default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at      timestamp default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    ext1            varchar(256)                        null comment '扩展字段1',
    ext2            varchar(256)                        null comment '扩展字段2',
    ext3            varchar(256)                        null comment '扩展字段3',
    extra_json      varchar(512)                        null comment '扩展信息json格式',
    approval_id     varchar(128)                        null,
    approval_status varchar(128)                        null comment 'WAITING 审批中 ,SUCCESS 审批通过  ,FAILED 审批不通过',
    constraint idx_email
        unique (email)
)
    comment '邮箱配置';

create table if not exists scorpio_email_strategy_mapping
(
    id          bigint auto_increment
        constraint `PRIMARY`
        primary key,
    email_id    bigint not null comment '邮箱id',
    strategy_id bigint not null comment '策略id'
)
    comment '邮箱策略关系表';

create table if not exists scorpio_field
(
    id                  bigint auto_increment comment '主键id'
        constraint `PRIMARY`
        primary key,
    name                varchar(255)                        null comment '字段名称',
    code                varchar(255)                        null comment '规则码',
    subject             varchar(20)                         not null comment '主体',
    scene               varchar(255)                        null comment '关联场景，多个以,分割',
    `condition`         varchar(255)                        null comment '条件',
    type                varchar(10)                         not null comment 'FEATURE(特征型),BEHAVIOR(行为类型)',
    value_operator_type varchar(20)                         null comment '字段计算方式',
    status              varchar(20)                         not null comment '状态',
    updated_by          varchar(255)                        null comment '创建人',
    created_at          timestamp default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at          timestamp default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    ext1                varchar(256)                        null comment '扩展字段1',
    ext2                varchar(256)                        null comment '扩展字段2',
    ext3                varchar(256)                        null comment '扩展字段3',
    extra_json          varchar(512)                        null comment '扩展信息json格式',
    constraint idx_code
        unique (code)
)
    charset = utf8;

create index idx_name
    on scorpio_field (name);

create index idx_subject
    on scorpio_field (subject);

create table if not exists scorpio_field_strategy_mapping
(
    id          bigint auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    strategy_id bigint not null comment '策略id',
    field_id    bigint not null comment '字段id'
)
    comment '字段策略关系表';

create index idx_field_id
    on scorpio_field_strategy_mapping (field_id);

create index idx_strategy_id
    on scorpio_field_strategy_mapping (strategy_id);

create table if not exists scorpio_import_tasks
(
    id            bigint unsigned auto_increment comment '自增主键'
        constraint `PRIMARY`
        primary key,
    business_type varchar(32) default 'WHITE_LIST'      not null comment '业务类型 WHITE_LIST:加入白名单',
    file_name     varchar(64)                           null comment '文件名称',
    status        varchar(32)                           not null comment '任务状态 WAIT_HANDLE：待处理 PROCESSING：处理中 SUCCESS：处理成功 FAIL：处理失败',
    total_count   int                                   null comment '总记录数',
    success_count int                                   null comment '成功记录数',
    fail_count    int                                   null comment '失败记录数',
    file_url      varchar(512)                          null comment '导入文件url',
    updated_by    varchar(32)                           null comment '操作人名称',
    fail_reason   varchar(200)                          null comment '失败原因',
    fail_file_url varchar(2048)                         null comment '失败文件url',
    remark        varchar(1024)                         null comment '备注',
    extra_json    varchar(2048)                         null comment '扩展信息json格式',
    created_at    timestamp   default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at    timestamp   default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    comment '导入任务表';

create index idx_business_type
    on scorpio_import_tasks (business_type);

create table if not exists scorpio_report_data
(
    id               bigint auto_increment comment '主键ID'
        constraint `PRIMARY`
        primary key,
    report_data_json varchar(3000)                       null comment '上报数据结构',
    remark           varchar(255)                        null comment '备注',
    reserve          varchar(255)                        null comment '预留字段',
    created_at       timestamp default CURRENT_TIMESTAMP null comment '创建时间'
)
    comment '上报数据表';

create table if not exists scorpio_risk_user
(
    id                 bigint auto_increment comment '主键id'
        constraint `PRIMARY`
        primary key,
    subject            varchar(255)                        not null comment '主体json',
    type               varchar(20)                         not null,
    white_list_type_id bigint                              null comment '白名单类型ID',
    remark             varchar(128)                        null comment '异常原因标记',
    extra_json         varchar(3000)                       null comment '扩展json',
    updated_by         varchar(255)                        null comment '更新人',
    created_at         timestamp default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at         timestamp default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    comment '异常记录表';

create table if not exists scorpio_scene
(
    id         int(6) auto_increment comment '主键id'
        constraint `PRIMARY`
        primary key,
    scene_name varchar(255)                        null comment '场景名称',
    scene_code varchar(20)                         not null comment '场景code',
    status     varchar(10)                         not null comment '状态 DRAFT:草稿  EFFECTIVE:生效  EXPIRED:失效',
    updated_by varchar(255)                        null comment '操作人',
    created_at timestamp default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at timestamp default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    constraint idx_scene_code
        unique (scene_code)
)
    charset = utf8;

create index idx_scene_name
    on scorpio_scene (scene_name);

create table if not exists scorpio_special_member
(
    id                 bigint unsigned auto_increment comment '自增主键'
        constraint `PRIMARY`
        primary key,
    member_id          bigint      default 0                 not null comment '会员ID',
    mobile             varchar(20)                           null comment '手机号',
    white_list_type_id bigint                                null comment '白名单类型ID',
    type               varchar(32) default ''                not null comment '类型：回归正常用户、异常用户、白名单、冻结用户',
    updated_by         varchar(32)                           null comment '操作人信息',
    remark             varchar(128)                          null comment '备注',
    extra_json         varchar(2048)                         null comment '扩展信息json格式',
    created_at         timestamp   default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at         timestamp   default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    ext1               varchar(256)                          null comment '扩展字段1',
    ext2               varchar(256)                          null comment '扩展字段2',
    ext3               varchar(256)                          null comment '扩展字段3',
    constraint idx_member_id
        unique (member_id)
)
    comment '风控异常用户';

create index idx_update_at
    on scorpio_special_member (updated_at);

create table if not exists scorpio_special_member_log
(
    id                 bigint unsigned auto_increment comment '自增主键'
        constraint `PRIMARY`
        primary key,
    member_id          bigint       default 0                 not null comment '会员ID',
    strategy_id        varchar(100) default ''                null comment '策略ID,多个用,分隔',
    white_list_type_id bigint                                 null comment '白名单类型ID',
    updated_by         varchar(32)                            null comment '操作人信息',
    type               varchar(32)  default ''                not null comment '类型：回归正常用户、异常用户、白名单、冻结用户',
    remark             varchar(128)                           null comment '备注',
    created_at         timestamp    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at         timestamp    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    ext1               varchar(256)                           null comment '扩展字段1',
    ext2               varchar(256)                           null comment '扩展字段2',
    ext3               varchar(256)                           null comment '扩展字段3',
    extra_json         varchar(512)                           null comment '扩展信息json格式'
)
    comment '风控异常用户日志表';

create index idx_member_id
    on scorpio_special_member_log (member_id);

create table if not exists scorpio_strategy
(
    id              bigint auto_increment comment '主键ID'
        constraint `PRIMARY`
        primary key,
    strategy_name   varchar(50)                            null comment '名称',
    type            varchar(10)                            null comment 'SDK/SERVER',
    scene_code      varchar(20)                            not null comment '场景',
    measure_type    varchar(20)                            not null comment '风控措施:
INTERCEPT,
FREEZE,
INSTANT_NOTIFYING,
TIMING_NOTIFYING',
    status          varchar(20)                            null comment 'DRAFT(草稿),IN_USE(生效中),PAUSE(暂停),STOP(停止)',
    rule            text                                   null comment '规则,json格式',
    logic           varchar(10)                            null comment 'and/or',
    created_at      timestamp    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at      timestamp    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by      varchar(255)                           null comment '更新人',
    ext1            varchar(256)                           null comment '扩展字段1',
    ext2            varchar(256) default 'VISUAL'          null comment '是否可见 VISUAL:可见  NOT_VISUAL:不可见',
    ext3            varchar(256)                           null comment '扩展字段3',
    extra_json      text                                   null comment '扩展信息json格式',
    approval_id     varchar(128)                           null,
    approval_status varchar(128)                           null comment 'WAITING 审批中 ,SUCCESS 审批通过  ,FAILED 审批不通过',
    constraint idx_strategy_name
        unique (strategy_name)
)
    comment '策略表';

create index idx_scene_code
    on scorpio_strategy (scene_code);

create table if not exists scorpio_subject
(
    id         int(6) auto_increment comment '主键ID'
        constraint `PRIMARY`
        primary key,
    subject    varchar(20)                         not null comment '主体',
    type       varchar(20)                         null comment '主体类型',
    `desc`     varchar(255)                        null comment '描述',
    status     varchar(10)                         not null comment '状态:IN_USE(使用中),STOP(停止使用)',
    created_at timestamp default CURRENT_TIMESTAMP not null comment '创建时间',
    constraint idx_subject
        unique (subject)
)
    comment '主体表' charset = utf8;

create table if not exists scorpio_white_list_type
(
    id         bigint auto_increment
        constraint `PRIMARY`
        primary key,
    name       varchar(32)  not null,
    is_delete  varchar(4)   not null,
    updated_by varchar(32)  null,
    created_at datetime     not null,
    updated_at datetime     not null,
    ext1       varchar(256) null comment '扩展字段1',
    ext2       varchar(256) null comment '扩展字段2',
    ext3       varchar(256) null comment '扩展字段3',
    extra_json varchar(512) null comment '扩展信息json格式'
)
    comment '白名单类型表';


