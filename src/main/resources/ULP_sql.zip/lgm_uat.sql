create table if not exists compensate_message
(
    id            bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    topic         varchar(64)       null,
    tag           varchar(64)       null,
    context       longtext          null comment '明细内容',
    msg_id        varchar(128)      null comment '消息id',
    biz_type      varchar(64)       null comment '业务类型',
    status        tinyint           null comment ' 0 处理中 1成功，-1 失败',
    fail_count    tinyint default 0 null comment '失败次数',
    priority      tinyint           null comment '优先级',
    failed_reason text              null comment '上次失败原因',
    created_at    datetime          null comment '创建时间',
    updated_at    datetime          null comment '更新时间',
    constraint idx_cm_msg_id
        unique (msg_id)
)
    comment '业务补偿表' charset = utf8mb4;

create table if not exists experience_expire_temp_id
(
    id                bigint unsigned     not null comment 'level_record_id',
    tenant_id         int                 null comment 'tenant_id',
    target_id         bigint unsigned     not null comment 'target_id',
    level_template_id bigint unsigned     null comment 'level_template_id',
    level_id          bigint(11) unsigned not null comment 'level_id',
    updated_at        datetime            null comment '更新时间',
    constraint `PRIMARY`
        primary key (id)
)
    comment '会员等级临时表' collate = utf8mb4_unicode_ci;

create table if not exists experience_record_log_temp_id
(
    id        bigint unsigned not null comment '等级记录id',
    tenant_id bigint          null comment '租户编号',
    constraint `PRIMARY`
        primary key (id)
)
    comment '成长值日志临时表' collate = utf8mb4_unicode_ci;

create table if not exists leaf_alloc
(
    biz_tag     varchar(128) default ''                not null comment '业务类型,唯一',
    max_id      bigint       default 1                 not null comment '当前最大id',
    step        int                                    not null comment '步长',
    description varchar(256)                           null comment '描述',
    update_time timestamp    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    constraint `PRIMARY`
        primary key (biz_tag)
)
    charset = utf8mb4;

create table if not exists lgm_job_execution_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
)
    collate = utf8mb4_unicode_ci;

create table if not exists lgm_job_instance
(
    JOB_INSTANCE_ID bigint       not null,
    VERSION         bigint       null,
    JOB_NAME        varchar(100) not null,
    JOB_KEY         varchar(32)  not null,
    constraint `PRIMARY`
        primary key (JOB_INSTANCE_ID),
    constraint JOB_INST_UN
        unique (JOB_NAME, JOB_KEY)
)
    collate = utf8mb4_unicode_ci;

create table if not exists lgm_job_execution
(
    JOB_EXECUTION_ID           bigint        not null,
    VERSION                    bigint        null,
    JOB_INSTANCE_ID            bigint        not null,
    CREATE_TIME                datetime      not null,
    START_TIME                 datetime      null,
    END_TIME                   datetime      null,
    STATUS                     varchar(10)   null,
    EXIT_CODE                  varchar(2500) null,
    EXIT_MESSAGE               varchar(2500) null,
    LAST_UPDATED               datetime      null,
    JOB_CONFIGURATION_LOCATION varchar(2500) null,
    constraint `PRIMARY`
        primary key (JOB_EXECUTION_ID),
    constraint JOB_INST_EXEC_FK
        foreign key (JOB_INSTANCE_ID) references lgm_job_instance (JOB_INSTANCE_ID)
)
    collate = utf8mb4_unicode_ci;

create table if not exists lgm_job_execution_context
(
    JOB_EXECUTION_ID   bigint        not null,
    SHORT_CONTEXT      varchar(2500) not null,
    SERIALIZED_CONTEXT text          null,
    constraint `PRIMARY`
        primary key (JOB_EXECUTION_ID),
    constraint JOB_EXEC_CTX_FK
        foreign key (JOB_EXECUTION_ID) references lgm_job_execution (JOB_EXECUTION_ID)
)
    collate = utf8mb4_unicode_ci;

create table if not exists lgm_job_execution_params
(
    JOB_EXECUTION_ID bigint       not null,
    TYPE_CD          varchar(6)   not null,
    KEY_NAME         varchar(100) not null,
    STRING_VAL       varchar(250) null,
    DATE_VAL         datetime     null,
    LONG_VAL         bigint       null,
    DOUBLE_VAL       double       null,
    IDENTIFYING      char         not null,
    constraint JOB_EXEC_PARAMS_FK
        foreign key (JOB_EXECUTION_ID) references lgm_job_execution (JOB_EXECUTION_ID)
)
    collate = utf8mb4_unicode_ci;

create table if not exists lgm_job_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
)
    collate = utf8mb4_unicode_ci;

create table if not exists lgm_qrtz_calendars
(
    SCHED_NAME    varchar(120) not null,
    CALENDAR_NAME varchar(190) not null,
    CALENDAR      blob         not null,
    constraint `PRIMARY`
        primary key (SCHED_NAME, CALENDAR_NAME)
)
    charset = utf8mb4;

create table if not exists lgm_qrtz_fired_triggers
(
    SCHED_NAME        varchar(120) not null,
    ENTRY_ID          varchar(95)  not null,
    TRIGGER_NAME      varchar(190) not null,
    TRIGGER_GROUP     varchar(190) not null,
    INSTANCE_NAME     varchar(190) not null,
    FIRED_TIME        bigint(13)   not null,
    SCHED_TIME        bigint(13)   not null,
    PRIORITY          int          not null,
    STATE             varchar(16)  not null,
    JOB_NAME          varchar(190) null,
    JOB_GROUP         varchar(190) null,
    IS_NONCONCURRENT  varchar(1)   null,
    REQUESTS_RECOVERY varchar(1)   null,
    constraint `PRIMARY`
        primary key (SCHED_NAME, ENTRY_ID)
)
    charset = utf8mb4;

create index IDX_QRTZ_FT_INST_JOB_REQ_RCVRY
    on lgm_qrtz_fired_triggers (SCHED_NAME, INSTANCE_NAME, REQUESTS_RECOVERY);

create index IDX_QRTZ_FT_JG
    on lgm_qrtz_fired_triggers (SCHED_NAME, JOB_GROUP);

create index IDX_QRTZ_FT_J_G
    on lgm_qrtz_fired_triggers (SCHED_NAME, JOB_NAME, JOB_GROUP);

create index IDX_QRTZ_FT_TG
    on lgm_qrtz_fired_triggers (SCHED_NAME, TRIGGER_GROUP);

create index IDX_QRTZ_FT_TRIG_INST_NAME
    on lgm_qrtz_fired_triggers (SCHED_NAME, INSTANCE_NAME);

create index IDX_QRTZ_FT_T_G
    on lgm_qrtz_fired_triggers (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP);

create table if not exists lgm_qrtz_job_details
(
    SCHED_NAME        varchar(120) not null,
    JOB_NAME          varchar(190) not null,
    JOB_GROUP         varchar(190) not null,
    DESCRIPTION       varchar(250) null,
    JOB_CLASS_NAME    varchar(250) not null,
    IS_DURABLE        varchar(1)   not null,
    IS_NONCONCURRENT  varchar(1)   not null,
    IS_UPDATE_DATA    varchar(1)   not null,
    REQUESTS_RECOVERY varchar(1)   not null,
    JOB_DATA          blob         null,
    constraint `PRIMARY`
        primary key (SCHED_NAME, JOB_NAME, JOB_GROUP)
)
    charset = utf8mb4;

create index IDX_QRTZ_J_GRP
    on lgm_qrtz_job_details (SCHED_NAME, JOB_GROUP);

create index IDX_QRTZ_J_REQ_RECOVERY
    on lgm_qrtz_job_details (SCHED_NAME, REQUESTS_RECOVERY);

create table if not exists lgm_qrtz_locks
(
    SCHED_NAME varchar(120) not null,
    LOCK_NAME  varchar(40)  not null,
    constraint `PRIMARY`
        primary key (SCHED_NAME, LOCK_NAME)
)
    charset = utf8mb4;

create table if not exists lgm_qrtz_paused_trigger_grps
(
    SCHED_NAME    varchar(120) not null,
    TRIGGER_GROUP varchar(190) not null,
    constraint `PRIMARY`
        primary key (SCHED_NAME, TRIGGER_GROUP)
)
    charset = utf8mb4;

create table if not exists lgm_qrtz_scheduler_state
(
    SCHED_NAME        varchar(120) not null,
    INSTANCE_NAME     varchar(190) not null,
    LAST_CHECKIN_TIME bigint(13)   not null,
    CHECKIN_INTERVAL  bigint(13)   not null,
    constraint `PRIMARY`
        primary key (SCHED_NAME, INSTANCE_NAME)
)
    charset = utf8mb4;

create table if not exists lgm_qrtz_triggers
(
    SCHED_NAME     varchar(120) not null,
    TRIGGER_NAME   varchar(190) not null,
    TRIGGER_GROUP  varchar(190) not null,
    JOB_NAME       varchar(190) not null,
    JOB_GROUP      varchar(190) not null,
    DESCRIPTION    varchar(250) null,
    NEXT_FIRE_TIME bigint(13)   null,
    PREV_FIRE_TIME bigint(13)   null,
    PRIORITY       int          null,
    TRIGGER_STATE  varchar(16)  not null,
    TRIGGER_TYPE   varchar(8)   not null,
    START_TIME     bigint(13)   not null,
    END_TIME       bigint(13)   null,
    CALENDAR_NAME  varchar(190) null,
    MISFIRE_INSTR  smallint(2)  null,
    JOB_DATA       blob         null,
    constraint `PRIMARY`
        primary key (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP),
    constraint lgm_qrtz_triggers_ibfk_1
        foreign key (SCHED_NAME, JOB_NAME, JOB_GROUP) references lgm_qrtz_job_details (SCHED_NAME, JOB_NAME, JOB_GROUP)
)
    charset = utf8mb4;

create table if not exists lgm_qrtz_blob_triggers
(
    SCHED_NAME    varchar(120) not null,
    TRIGGER_NAME  varchar(190) not null,
    TRIGGER_GROUP varchar(190) not null,
    BLOB_DATA     blob         null,
    constraint `PRIMARY`
        primary key (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP),
    constraint lgm_qrtz_blob_triggers_ibfk_1
        foreign key (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP) references lgm_qrtz_triggers (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP)
)
    charset = utf8mb4;

create index SCHED_NAME
    on lgm_qrtz_blob_triggers (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP);

create table if not exists lgm_qrtz_cron_triggers
(
    SCHED_NAME      varchar(120) not null,
    TRIGGER_NAME    varchar(190) not null,
    TRIGGER_GROUP   varchar(190) not null,
    CRON_EXPRESSION varchar(120) not null,
    TIME_ZONE_ID    varchar(80)  null,
    constraint `PRIMARY`
        primary key (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP),
    constraint lgm_qrtz_cron_triggers_ibfk_1
        foreign key (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP) references lgm_qrtz_triggers (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP)
)
    charset = utf8mb4;

create table if not exists lgm_qrtz_simple_triggers
(
    SCHED_NAME      varchar(120) not null,
    TRIGGER_NAME    varchar(190) not null,
    TRIGGER_GROUP   varchar(190) not null,
    REPEAT_COUNT    bigint(7)    not null,
    REPEAT_INTERVAL bigint(12)   not null,
    TIMES_TRIGGERED bigint(10)   not null,
    constraint `PRIMARY`
        primary key (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP),
    constraint lgm_qrtz_simple_triggers_ibfk_1
        foreign key (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP) references lgm_qrtz_triggers (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP)
)
    charset = utf8mb4;

create table if not exists lgm_qrtz_simprop_triggers
(
    SCHED_NAME    varchar(120)   not null,
    TRIGGER_NAME  varchar(190)   not null,
    TRIGGER_GROUP varchar(190)   not null,
    STR_PROP_1    varchar(512)   null,
    STR_PROP_2    varchar(512)   null,
    STR_PROP_3    varchar(512)   null,
    INT_PROP_1    int            null,
    INT_PROP_2    int            null,
    LONG_PROP_1   bigint         null,
    LONG_PROP_2   bigint         null,
    DEC_PROP_1    decimal(13, 4) null,
    DEC_PROP_2    decimal(13, 4) null,
    BOOL_PROP_1   varchar(1)     null,
    BOOL_PROP_2   varchar(1)     null,
    constraint `PRIMARY`
        primary key (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP),
    constraint lgm_qrtz_simprop_triggers_ibfk_1
        foreign key (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP) references lgm_qrtz_triggers (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP)
)
    charset = utf8mb4;

create index IDX_QRTZ_T_C
    on lgm_qrtz_triggers (SCHED_NAME, CALENDAR_NAME);

create index IDX_QRTZ_T_G
    on lgm_qrtz_triggers (SCHED_NAME, TRIGGER_GROUP);

create index IDX_QRTZ_T_J
    on lgm_qrtz_triggers (SCHED_NAME, JOB_NAME, JOB_GROUP);

create index IDX_QRTZ_T_JG
    on lgm_qrtz_triggers (SCHED_NAME, JOB_GROUP);

create index IDX_QRTZ_T_NEXT_FIRE_TIME
    on lgm_qrtz_triggers (SCHED_NAME, NEXT_FIRE_TIME);

create index IDX_QRTZ_T_NFT_MISFIRE
    on lgm_qrtz_triggers (SCHED_NAME, MISFIRE_INSTR, NEXT_FIRE_TIME);

create index IDX_QRTZ_T_NFT_ST
    on lgm_qrtz_triggers (SCHED_NAME, TRIGGER_STATE, NEXT_FIRE_TIME);

create index IDX_QRTZ_T_NFT_ST_MISFIRE
    on lgm_qrtz_triggers (SCHED_NAME, MISFIRE_INSTR, NEXT_FIRE_TIME, TRIGGER_STATE);

create index IDX_QRTZ_T_NFT_ST_MISFIRE_GRP
    on lgm_qrtz_triggers (SCHED_NAME, MISFIRE_INSTR, NEXT_FIRE_TIME, TRIGGER_GROUP, TRIGGER_STATE);

create index IDX_QRTZ_T_N_G_STATE
    on lgm_qrtz_triggers (SCHED_NAME, TRIGGER_GROUP, TRIGGER_STATE);

create index IDX_QRTZ_T_N_STATE
    on lgm_qrtz_triggers (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP, TRIGGER_STATE);

create index IDX_QRTZ_T_STATE
    on lgm_qrtz_triggers (SCHED_NAME, TRIGGER_STATE);

create table if not exists lgm_step_execution
(
    STEP_EXECUTION_ID  bigint        not null,
    VERSION            bigint        not null,
    STEP_NAME          varchar(100)  not null,
    JOB_EXECUTION_ID   bigint        not null,
    START_TIME         datetime      not null,
    END_TIME           datetime      null,
    STATUS             varchar(10)   null,
    COMMIT_COUNT       bigint        null,
    READ_COUNT         bigint        null,
    FILTER_COUNT       bigint        null,
    WRITE_COUNT        bigint        null,
    READ_SKIP_COUNT    bigint        null,
    WRITE_SKIP_COUNT   bigint        null,
    PROCESS_SKIP_COUNT bigint        null,
    ROLLBACK_COUNT     bigint        null,
    EXIT_CODE          varchar(2500) null,
    EXIT_MESSAGE       varchar(2500) null,
    LAST_UPDATED       datetime      null,
    constraint `PRIMARY`
        primary key (STEP_EXECUTION_ID),
    constraint JOB_EXEC_STEP_FK
        foreign key (JOB_EXECUTION_ID) references lgm_job_execution (JOB_EXECUTION_ID)
)
    collate = utf8mb4_unicode_ci;

create table if not exists lgm_step_execution_context
(
    STEP_EXECUTION_ID  bigint        not null,
    SHORT_CONTEXT      varchar(2500) not null,
    SERIALIZED_CONTEXT text          null,
    constraint `PRIMARY`
        primary key (STEP_EXECUTION_ID),
    constraint STEP_EXEC_CTX_FK
        foreign key (STEP_EXECUTION_ID) references lgm_step_execution (STEP_EXECUTION_ID)
)
    collate = utf8mb4_unicode_ci;

create table if not exists lgm_step_execution_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
)
    collate = utf8mb4_unicode_ci;

create table if not exists mc_behaviour
(
    id                      bigint(11) auto_increment comment '编号'
        constraint `PRIMARY`
        primary key,
    tenant_id               int                   null comment '租户编号',
    level_template_id       bigint                null comment '等级模版编号',
    behaviour_template_id   bigint                null comment '模版编号',
    behaviour_template_code varchar(20)           null comment '模版code',
    root_event_code         varchar(20)           null comment '根事件编码',
    behaviour_type          varchar(20)           null comment '指标类型',
    behaviour_name          varchar(20)           null comment '指标名称',
    group_code              varchar(20)           null comment '成长值分组编码',
    group_name              varchar(20)           null comment '分组名称',
    lazy_field_json         text                  null comment '懒加载字段json',
    rule                    text                  null comment '指标规则',
    event_def_id            bigint                null comment '事件定义ID',
    action_def_json         longtext charset utf8 null comment '动作定义json',
    description             varchar(255)          null comment '指标介绍',
    display_index           int default 9999      null comment '展示顺序',
    status                  varchar(10)           null comment '状态',
    extra_json              varchar(255)          null comment '额外信息',
    draft_json              longtext charset utf8 null comment '草稿json',
    delete_flag             smallint              null comment '逻辑删除标志',
    created_at              datetime              null comment '创建时间',
    updated_at              datetime              null comment '更新时间',
    strategy_def_json       longtext charset utf8 null comment '策略定义json'
)
    comment '成长行为' charset = utf8mb4;

create index idx_tenant_behaviour
    on mc_behaviour (tenant_id, level_template_id, behaviour_template_id);

create table if not exists mc_behaviour_template
(
    id                bigint(11) auto_increment comment '编号'
        constraint `PRIMARY`
        primary key,
    tenant_id         int          null comment '租户ID',
    level_template_id bigint       null comment '模版等级编号',
    tags              varchar(20)  null comment '标签',
    template_code     varchar(20)  null comment '模版code',
    template_name     varchar(20)  null comment '模版名称',
    description       varchar(255) null comment '模版介绍',
    event_id          bigint       null comment '事件编号',
    event_code        varchar(30)  null comment '事件编码',
    event_name        varchar(20)  null comment '事件名称',
    group_code        varchar(20)  null comment '成长值分组编码',
    composite_id      bigint       null comment '组合事件编号',
    action_code       varchar(30)  null comment '动作编码',
    action_name       varchar(20)  null comment '动作名称',
    extra_json        text         null comment '额外信息',
    status            varchar(10)  null comment '状态',
    delete_flag       smallint     null comment '逻辑删除标志',
    created_at        datetime     null comment '创建时间',
    updated_at        datetime     null comment '更新时间',
    constraint mc_behaviour_template_template_code_uindex
        unique (template_code)
)
    comment '成长行为模版' charset = utf8mb4;

create index idx_tennant_behaviour
    on mc_behaviour_template (tenant_id, level_template_id);

create table if not exists mc_experience_group
(
    id          bigint auto_increment comment '编号'
        constraint `PRIMARY`
        primary key,
    tenant_id   bigint       null comment '租户编号',
    group_code  varchar(20)  null comment '分组编码',
    group_name  varchar(30)  null comment '分组名称',
    description varchar(255) null comment '分组说明',
    delete_flag smallint     null comment '逻辑删除标志',
    created_at  datetime     null comment '创建时间',
    updated_at  datetime     null comment '更新时间'
)
    comment '成长值分组' charset = utf8mb4;

create table if not exists mc_experience_record_log
(
    id                      bigint auto_increment comment '编号'
        constraint `PRIMARY`
        primary key,
    request_no              varchar(20)  not null,
    tenant_id               bigint       null comment '租户编号',
    target_id               bigint       null comment '会员编号',
    out_id                  varchar(20)  null comment '外围流水',
    template_id             bigint       null,
    group_code              varchar(30)  null comment '分组编码',
    group_name              varchar(20)  null comment '分组名称',
    behaviour_id            bigint       null comment '行为编号',
    behaviour_name          varchar(20)  null comment '行为名称',
    from_score              int          null comment '旧指标值',
    change_type             varchar(10)  null comment '变更类型',
    to_score                int          null comment '新指标值',
    change_score            int          null comment '变化量',
    event_id                int          null comment '事件ID',
    event_code              varchar(30)  null comment '事件编码',
    event_name              varchar(20)  null comment '事件名称',
    action_code             varchar(30)  null,
    source                  varchar(30)  null comment '来源',
    source_type             varchar(30)  null comment '来源类型',
    behaviour_rule_snapshot text         null comment '指标规则快照',
    extra_json              text         null,
    handle_status           varchar(10)  null comment '处理状态',
    remark                  varchar(255) null comment '备注',
    delete_flag             smallint     null comment '逻辑删除标志',
    created_at              datetime     null comment '创建时间',
    updated_at              datetime     null comment '更新时间',
    occur_time              datetime     null comment '生效时间',
    effect_day              varchar(12)  null comment '下月生效时间',
    ext1                    varchar(30)  null comment '扩展字段1',
    ext2                    varchar(30)  null comment '扩展字段2',
    ext3                    varchar(30)  null comment '扩展字段3'
)
    comment '成长值变化日志' charset = utf8mb4;

create index idx_merl_occur_time
    on mc_experience_record_log (occur_time);

create index idx_merl_target_status
    on mc_experience_record_log (target_id, handle_status);

create table if not exists mc_experience_score
(
    id                bigint auto_increment comment '编号'
        constraint `PRIMARY`
        primary key,
    tenant_id         bigint      null comment '租户ID',
    target_id         bigint      null comment '对象编号',
    level_template_id bigint      null comment '等级模版编号',
    group_code        varchar(30) null comment '分组编号',
    group_name        varchar(20) null comment '分组名称',
    group_score       int         null comment '成长值',
    delete_flag       smallint    null comment '逻辑删除标志',
    created_at        datetime    null comment '创建时间',
    updated_at        datetime    null comment '更新时间'
)
    comment '等级指标值记录' charset = utf8mb4;

create index idx_tenant_experience_score
    on mc_experience_score (tenant_id, target_id, level_template_id, group_code);

create table if not exists mc_level_change_log
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log (member_id);

create table if not exists mc_level_change_log_0
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_0 (member_id);

create table if not exists mc_level_change_log_1
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_1 (member_id);

create table if not exists mc_level_change_log_10
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_10 (member_id);

create table if not exists mc_level_change_log_100
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_100 (member_id);

create table if not exists mc_level_change_log_101
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_101 (member_id);

create table if not exists mc_level_change_log_102
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_102 (member_id);

create table if not exists mc_level_change_log_103
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_103 (member_id);

create table if not exists mc_level_change_log_104
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_104 (member_id);

create table if not exists mc_level_change_log_105
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_105 (member_id);

create table if not exists mc_level_change_log_106
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_106 (member_id);

create table if not exists mc_level_change_log_107
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_107 (member_id);

create table if not exists mc_level_change_log_108
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_108 (member_id);

create table if not exists mc_level_change_log_109
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_109 (member_id);

create table if not exists mc_level_change_log_11
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_11 (member_id);

create table if not exists mc_level_change_log_110
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_110 (member_id);

create table if not exists mc_level_change_log_111
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_111 (member_id);

create table if not exists mc_level_change_log_112
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_112 (member_id);

create table if not exists mc_level_change_log_113
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_113 (member_id);

create table if not exists mc_level_change_log_114
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_114 (member_id);

create table if not exists mc_level_change_log_115
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_115 (member_id);

create table if not exists mc_level_change_log_116
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_116 (member_id);

create table if not exists mc_level_change_log_117
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_117 (member_id);

create table if not exists mc_level_change_log_118
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_118 (member_id);

create table if not exists mc_level_change_log_119
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_119 (member_id);

create table if not exists mc_level_change_log_12
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_12 (member_id);

create table if not exists mc_level_change_log_120
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_120 (member_id);

create table if not exists mc_level_change_log_121
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_121 (member_id);

create table if not exists mc_level_change_log_122
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_122 (member_id);

create table if not exists mc_level_change_log_123
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_123 (member_id);

create table if not exists mc_level_change_log_124
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_124 (member_id);

create table if not exists mc_level_change_log_125
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_125 (member_id);

create table if not exists mc_level_change_log_126
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_126 (member_id);

create table if not exists mc_level_change_log_127
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_127 (member_id);

create table if not exists mc_level_change_log_13
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_13 (member_id);

create table if not exists mc_level_change_log_14
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_14 (member_id);

create table if not exists mc_level_change_log_15
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_15 (member_id);

create table if not exists mc_level_change_log_16
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_16 (member_id);

create table if not exists mc_level_change_log_17
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_17 (member_id);

create table if not exists mc_level_change_log_18
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_18 (member_id);

create table if not exists mc_level_change_log_19
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_19 (member_id);

create table if not exists mc_level_change_log_2
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_2 (member_id);

create table if not exists mc_level_change_log_20
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_20 (member_id);

create table if not exists mc_level_change_log_21
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_21 (member_id);

create table if not exists mc_level_change_log_22
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_22 (member_id);

create table if not exists mc_level_change_log_23
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_23 (member_id);

create table if not exists mc_level_change_log_24
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_24 (member_id);

create table if not exists mc_level_change_log_25
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_25 (member_id);

create table if not exists mc_level_change_log_26
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_26 (member_id);

create table if not exists mc_level_change_log_27
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_27 (member_id);

create table if not exists mc_level_change_log_28
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_28 (member_id);

create table if not exists mc_level_change_log_29
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_29 (member_id);

create table if not exists mc_level_change_log_3
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_3 (member_id);

create table if not exists mc_level_change_log_30
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_30 (member_id);

create table if not exists mc_level_change_log_31
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_31 (member_id);

create table if not exists mc_level_change_log_32
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_32 (member_id);

create table if not exists mc_level_change_log_33
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_33 (member_id);

create table if not exists mc_level_change_log_34
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_34 (member_id);

create table if not exists mc_level_change_log_35
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_35 (member_id);

create table if not exists mc_level_change_log_36
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_36 (member_id);

create table if not exists mc_level_change_log_37
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_37 (member_id);

create table if not exists mc_level_change_log_38
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_38 (member_id);

create table if not exists mc_level_change_log_39
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_39 (member_id);

create table if not exists mc_level_change_log_4
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_4 (member_id);

create table if not exists mc_level_change_log_40
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_40 (member_id);

create table if not exists mc_level_change_log_41
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_41 (member_id);

create table if not exists mc_level_change_log_42
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_42 (member_id);

create table if not exists mc_level_change_log_43
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_43 (member_id);

create table if not exists mc_level_change_log_44
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_44 (member_id);

create table if not exists mc_level_change_log_45
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_45 (member_id);

create table if not exists mc_level_change_log_46
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_46 (member_id);

create table if not exists mc_level_change_log_47
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_47 (member_id);

create table if not exists mc_level_change_log_48
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_48 (member_id);

create table if not exists mc_level_change_log_49
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_49 (member_id);

create table if not exists mc_level_change_log_5
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_5 (member_id);

create table if not exists mc_level_change_log_50
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_50 (member_id);

create table if not exists mc_level_change_log_51
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_51 (member_id);

create table if not exists mc_level_change_log_52
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_52 (member_id);

create table if not exists mc_level_change_log_53
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_53 (member_id);

create table if not exists mc_level_change_log_54
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_54 (member_id);

create table if not exists mc_level_change_log_55
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_55 (member_id);

create table if not exists mc_level_change_log_56
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_56 (member_id);

create table if not exists mc_level_change_log_57
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_57 (member_id);

create table if not exists mc_level_change_log_58
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_58 (member_id);

create table if not exists mc_level_change_log_59
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_59 (member_id);

create table if not exists mc_level_change_log_6
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_6 (member_id);

create table if not exists mc_level_change_log_60
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_60 (member_id);

create table if not exists mc_level_change_log_61
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_61 (member_id);

create table if not exists mc_level_change_log_62
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_62 (member_id);

create table if not exists mc_level_change_log_63
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_63 (member_id);

create table if not exists mc_level_change_log_64
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_64 (member_id);

create table if not exists mc_level_change_log_65
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_65 (member_id);

create table if not exists mc_level_change_log_66
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_66 (member_id);

create table if not exists mc_level_change_log_67
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_67 (member_id);

create table if not exists mc_level_change_log_68
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_68 (member_id);

create table if not exists mc_level_change_log_69
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_69 (member_id);

create table if not exists mc_level_change_log_7
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_7 (member_id);

create table if not exists mc_level_change_log_70
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_70 (member_id);

create table if not exists mc_level_change_log_71
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_71 (member_id);

create table if not exists mc_level_change_log_72
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_72 (member_id);

create table if not exists mc_level_change_log_73
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_73 (member_id);

create table if not exists mc_level_change_log_74
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_74 (member_id);

create table if not exists mc_level_change_log_75
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_75 (member_id);

create table if not exists mc_level_change_log_76
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_76 (member_id);

create table if not exists mc_level_change_log_77
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_77 (member_id);

create table if not exists mc_level_change_log_78
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_78 (member_id);

create table if not exists mc_level_change_log_79
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_79 (member_id);

create table if not exists mc_level_change_log_8
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_8 (member_id);

create table if not exists mc_level_change_log_80
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_80 (member_id);

create table if not exists mc_level_change_log_81
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_81 (member_id);

create table if not exists mc_level_change_log_82
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_82 (member_id);

create table if not exists mc_level_change_log_83
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_83 (member_id);

create table if not exists mc_level_change_log_84
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_84 (member_id);

create table if not exists mc_level_change_log_85
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_85 (member_id);

create table if not exists mc_level_change_log_86
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_86 (member_id);

create table if not exists mc_level_change_log_87
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_87 (member_id);

create table if not exists mc_level_change_log_88
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_88 (member_id);

create table if not exists mc_level_change_log_89
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_89 (member_id);

create table if not exists mc_level_change_log_9
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_9 (member_id);

create table if not exists mc_level_change_log_90
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_90 (member_id);

create table if not exists mc_level_change_log_91
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_91 (member_id);

create table if not exists mc_level_change_log_92
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_92 (member_id);

create table if not exists mc_level_change_log_93
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_93 (member_id);

create table if not exists mc_level_change_log_94
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_94 (member_id);

create table if not exists mc_level_change_log_95
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_95 (member_id);

create table if not exists mc_level_change_log_96
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_96 (member_id);

create table if not exists mc_level_change_log_97
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_97 (member_id);

create table if not exists mc_level_change_log_98
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_98 (member_id);

create table if not exists mc_level_change_log_99
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint            not null comment '会员ID',
    tenant_id         bigint(11)        null comment '租户编号',
    level_template_id int               null comment '等级模版编号',
    level_id          bigint            null comment '等级编号',
    level_name        varchar(50)       null comment '等级名称',
    from_level        smallint          not null comment '变化前等级',
    to_level          smallint          not null comment '变化后等级',
    description       varchar(128)      not null comment '描述',
    extra_json        varchar(1024)     null comment '额外信息',
    maintain          tinyint default 0 null comment '保级标识, 是否保级成功',
    occurred_at       datetime          not null comment '发生时间',
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '会员等级变化记录';

create index idx_mc_mlcl_member_id
    on mc_level_change_log_99 (member_id);

create table if not exists mc_level_equity
(
    id          bigint(11) auto_increment comment '编号'
        constraint `PRIMARY`
        primary key,
    level_id    bigint(18)    null comment '等级编号',
    equity_id   varchar(64)   null comment '权益编号',
    status      smallint(255) null comment '状态',
    delete_flag smallint(255) null comment '逻辑删除标志',
    created_at  datetime      null comment '创建时间',
    updated_at  datetime      null comment '更新时间'
)
    comment '等级权益' charset = utf8mb4;

create index idx_tenant_level_equity
    on mc_level_equity (level_id);

create table if not exists mc_level_expire_temp_id
(
    id                bigint unsigned not null comment '暂存的会员ID',
    level_template_id bigint          not null comment '等级模版编号'
)
    comment '会员ID临时表';

create index uk_memberId
    on mc_level_expire_temp_id (id, level_template_id);

create table if not exists mc_level_measurement
(
    id           bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    `key`        varchar(128)               not null comment '模板key',
    display_name varchar(128)               not null comment '显示名称',
    is_display   varchar(16) default 'true' null comment '是否展示',
    output_type  varchar(32)                not null comment '输出类型',
    unit         varchar(32)                not null comment '单位',
    description  varchar(128)               null comment '描述',
    loading_rule longtext                   null comment '加载规则',
    level_type   varchar(32)                null comment '等级类型',
    created_at   datetime                   not null comment '创建时间',
    updated_at   datetime                   not null comment '更新时间',
    constraint idx_mlm_key
        unique (`key`)
);

create table if not exists mc_level_record
(
    id                bigint auto_increment comment '编号'
        constraint `PRIMARY`
        primary key,
    tenant_id         bigint        null,
    target_id         bigint        null comment '对象编号',
    level_template_id bigint        null comment '等级模版编号',
    level_id          bigint        null comment '等级编号',
    level_name        varchar(255)  null comment '等级名称',
    level_code        varchar(255)  null comment '等级编码',
    level_expire_at   datetime      null,
    extra_json        varchar(1024) null comment '额外信息',
    delete_flag       smallint      null comment '逻辑删除标志',
    source            varchar(32)   null comment '来源',
    source_type       varchar(32)   null comment '来源类型',
    created_at        datetime      null comment '创建时间',
    updated_at        datetime      null comment '更新时间',
    updated_by        varchar(64)   null comment '编辑人',
    sum_at            datetime      null comment '统计时间(若为空则取上次等级变更时间)'
)
    comment '等级记录' charset = utf8mb4;

create index idx_tenant_level_log
    on mc_level_record (target_id, level_template_id);

create table if not exists mc_level_template
(
    id            bigint(11) auto_increment comment '编号'
        constraint `PRIMARY`
        primary key,
    tenant_id     int          null comment '租户ID',
    tenant_name   varchar(20)  null comment '租户名称',
    template_name varchar(20)  null comment '模版名称',
    description   varchar(255) null comment '模版介绍',
    type          varchar(10)  null comment '等级类型',
    extra_json    text         null comment '额外信息',
    upgrade_mode  varchar(10)  null comment '升级模式',
    status        varchar(10)  null comment '状态',
    delete_flag   smallint     null comment '逻辑删除标志',
    created_at    datetime     null comment '创建时间',
    updated_at    datetime     null comment '更新时间'
)
    comment '等级模版' charset = utf8mb4;

create index idx_tennant
    on mc_level_template (tenant_id);

create table if not exists mc_level_type
(
    id           bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    type         varchar(64)  not null comment '等级类型',
    display_name varchar(64)  not null comment '显示名称',
    description  varchar(128) null comment '描述',
    status       smallint     not null comment '状态: 未启用(-1) 启用(1)',
    created_at   datetime     not null comment '创建时间',
    updated_at   datetime     not null comment '更新时间',
    constraint idx_mlt_type
        unique (type)
);

create table if not exists mc_levels
(
    id                  bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id           bigint(11)              null comment '租户id',
    level_template_id   bigint(11)              null comment '等级模板编号',
    level_template_name varchar(255)            null comment '等级模板名称',
    level_template_type varchar(10)             null comment '等级模板类型',
    period_type         varchar(50)             null comment '会员有效期类型',
    level_code          varchar(255)            null comment '等级编码',
    name                varchar(32)             not null comment '等级名称',
    description         varchar(256)            null comment '等级描述',
    level               smallint                not null comment '会员等级权重',
    discount            bigint                  null comment '折扣率（万分之一）',
    logo                varchar(512)            null comment 'LOGO图片',
    up_expression       longtext                null comment '升级条件的规则表达式',
    down_expression     longtext                null comment '降级条件的规则表达式',
    extra_json          varchar(1024)           null comment '额外信息',
    equities            varchar(2048)           null comment '会员权益',
    period_expression   varchar(256) default '' null comment '有效时间表达式(参考ISO8601)',
    duration_of_month   smallint                not null comment '有效期（秒）',
    status              smallint                not null comment '状态 0:未生效, 1:已生效',
    flag                smallint     default 0  not null comment '系统标识 0:非系统配置 1:系统配置',
    permanent           smallint                null comment '是否永久有效, 0:非永久有效, 1:永久有效',
    created_at          datetime                not null comment '创建时间',
    updated_at          datetime                not null comment '更新时间',
    updated_by          varchar(64)             null comment '编辑人',
    flow_id             varchar(63)             null comment '流程实例id',
    audit_status        varchar(31)             null comment '审批状态 WAITING 审批中 ,SUCCESS 审批通过  ,FAILED 审批不通过',
    constraint idx_mc_levels_level_unique
        unique (level, level_template_id)
)
    comment '会员等级';

create table if not exists mc_summaries
(
    id                             bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id                      bigint   not null comment '会员ID',
    current_year_sale_amount_top   bigint   null comment '本年单笔最高消费(单位：当前币制的最小单位, 如人民币分)',
    current_year_sale_amount_total bigint   null comment '本年消费总额(同上)',
    current_year_sale_number       bigint   null comment '本年消费次数',
    last_year_sale_amount_top      bigint   null comment '上年单笔最高消费(同上)',
    last_year_sale_amount_total    bigint   null comment '上年消费总额(同上)',
    last_year_sale_number          bigint   null comment '上年消费次数',
    created_at                     datetime not null comment '创建时间',
    updated_at                     datetime not null comment '更新时间'
)
    comment '会员统计信息';

create index idx_mc_ms_member_id
    on mc_summaries (member_id);

create index idx_mcs_updated_at
    on mc_summaries (updated_at);

create table if not exists mc_summary_detail_items
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id         bigint      not null comment '会员ID',
    summary_detail_id bigint      not null comment '统计明细ID',
    parent_id         varchar(32) null comment '主单ID',
    parent_type       varchar(64) null comment '主单类型',
    child_id          varchar(32) null comment '子单ID',
    child_type        varchar(64) null comment '子单类型',
    trade_amount      varchar(32) null comment '交易金额',
    created_at        datetime    not null comment '创建时间',
    updated_at        datetime    not null comment '更新时间'
)
    comment '累计金额明细';

create index idx_mc_msdi_summary_deail_id
    on mc_summary_detail_items (summary_detail_id);

create index idx_mc_msdi_summary_member_id
    on mc_summary_detail_items (member_id);

create index idx_mc_msdi_summary_parent_id
    on mc_summary_detail_items (parent_id);

create table if not exists mc_summary_details
(
    id                  bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id           bigint      not null comment '会员ID',
    trade_amount        bigint      not null comment '交易金额',
    refund_trade_amount bigint      not null comment '累计退货金额',
    rest_trade_amount   bigint      not null comment '有效交易金额',
    point_amount        bigint      null comment '积分金额',
    change_point        bigint      null comment '积分变化(增加时为正, 扣减为负)',
    outer_id            varchar(32) null comment '外部单号',
    outer_type          varchar(64) null comment '外部单据类型',
    source              varchar(32) null comment '来源(可以考虑取服务渠道)',
    source_type         varchar(64) null comment '来源类型',
    status              smallint    not null comment '0: 无效, 1: 有效',
    year                varchar(4)  not null comment '发生年',
    occurred_at         datetime    not null comment '发生时间',
    created_at          datetime    not null comment '创建时间',
    updated_at          datetime    not null comment '更新时间',
    constraint idx_msd_unique_id
        unique (outer_id, outer_type)
)
    comment '累计金额明细`';

create index idx_mc_msd_member_id
    on mc_summary_details (member_id);

create table if not exists mq_consume_log
(
    tenant_id     bigint      not null comment '编号',
    request_no    varchar(20) not null comment '请求流水号',
    biz_type      varchar(10) null,
    handle_status varchar(10) null,
    created_at    datetime    null comment '创建时间',
    updated_at    datetime    null comment '更新时间',
    constraint `PRIMARY`
        primary key (tenant_id, request_no)
)
    comment 'MQ消费去重表' charset = utf8mb4;

create table if not exists sagittarius_action_def
(
    id                 bigint auto_increment
        constraint `PRIMARY`
        primary key,
    activity_id        bigint       null comment '活动id',
    composite_id       bigint       null comment '事件组合id',
    action_name        varchar(64)  not null comment '动作名称',
    action_code        varchar(64)  not null comment '动作代码',
    action_description varchar(256) null comment '动作描述',
    action_context     longtext     not null comment '动作上下文',
    status             varchar(32)  not null comment 'INIT:初始, FROZEN:禁用',
    created_at         datetime     not null comment '创建时间',
    updated_at         datetime     not null comment '更新时间'
);

create table if not exists sagittarius_activity_def
(
    id                bigint auto_increment
        constraint `PRIMARY`
        primary key,
    root_event_code   varchar(64)             not null comment '根事件CODE',
    event_def_id      bigint                  null comment '事件定义id',
    composite_def_id  bigint                  null comment '事件组合定义',
    activity_name     varchar(64)             not null comment '策略名称',
    action_def_json   longtext                null comment '活动定义json',
    strategy_def_json longtext                null comment '策略定义json',
    submit_json       longtext                null comment '表单提交json',
    status            varchar(16)             not null comment '活动状态 INIT:初始, FROZEN:禁用',
    is_invalid        varchar(4) default 'NO' null comment '活动是否失效 YES:是, NO:否',
    creator_name      varchar(32)             null comment '创建人名称',
    creator_id        bigint                  null comment '创建人ID',
    start_at          datetime                null comment '开始时间',
    end_at            datetime                null comment '截止时间',
    created_at        datetime                not null comment '创建时间',
    updated_at        datetime                not null comment '更新时间'
);

create table if not exists sagittarius_composite_def
(
    id                bigint auto_increment
        constraint `PRIMARY`
        primary key,
    event_def_name    varchar(64) default '' not null comment '事件定义名称',
    event_def_type    varchar(32)            not null comment '事件定义类型',
    creator_id        bigint                 null comment '创建人ID',
    creator_name      varchar(32) default '' null comment '创建人姓名',
    event_def_json    longtext               null comment '事件json',
    action_def_json   longtext               null comment '动作json',
    strategy_def_json longtext               null comment '策略json',
    submit_json       longtext               not null comment '前端提交的json',
    start_at          datetime               null comment '开始事件',
    end_at            datetime               null comment '截止事件',
    status            varchar(32)            not null comment '状态',
    created_at        datetime               not null comment '创建时间',
    updated_at        datetime               not null comment '更新事件'
);

create table if not exists sagittarius_event_def
(
    id                bigint auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id         varchar(64)  null comment '租户',
    composite_id      bigint       null comment '事件组合id',
    event_name        varchar(64)  not null comment '事件名称',
    event_code        varchar(64)  not null comment '事件代码',
    event_description varchar(256) not null comment '事件描述',
    event_icon        varchar(256) null comment '事件图标',
    tags              varchar(32)  null comment '标签',
    status            varchar(32)  not null comment 'INIT:初始, FROZEN:禁用',
    permanent         varchar(4)   not null comment '是否永久有效 YES:是, NO:否',
    fields            longtext     null comment '字段定义',
    extra             longtext     null comment '字段定义',
    start_at          datetime     null comment '开始时间',
    end_at            datetime     null comment '截止时间',
    created_at        datetime     not null comment '创建时间',
    updated_at        datetime     not null comment '修改时间'
);

create table if not exists sagittarius_events
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_0
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_1
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_10
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_11
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_12
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_13
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_14
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_15
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_2
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_3
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_4
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_5
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_6
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_7
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_8
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_events_9
(
    id                    bigint auto_increment
        constraint `PRIMARY`
        primary key,
    identity              varchar(64)   not null comment '会员识别码',
    tenant_id             bigint        null comment '租户',
    unique_key            varchar(64)   not null comment '去重判定Key',
    event_biz_id          varchar(64)   null comment '事件业务id',
    event_biz_type        varchar(64)   null comment '事件业务类型',
    event_def_id          bigint        not null comment '事件定义id',
    strategy_def_id       bigint        null comment '策略定义id',
    action_def_id         bigint        null comment '动作定义id',
    activity_id           bigint        null comment '活动id',
    event_context         longtext      null comment '事件上下文',
    current_event_context longtext      null comment '加载内容事件上下文',
    status                varchar(20)   not null comment '事件状态',
    retry                 int default 0 null comment '重试次数',
    exit_message          longtext      null comment '错误信息',
    start_at              datetime      null comment '开始时间',
    end_at                datetime      null comment '截止时间',
    created_at            datetime      null comment '创建时间',
    updated_at            datetime      null comment '更新时间',
    rpc_time_out          int default 0 null comment 'rpc调用是否超时,1为超时，0未超时',
    constraint uk_sagitterius_event
        unique (unique_key)
);

create table if not exists sagittarius_strategy_def
(
    id                   bigint auto_increment
        constraint `PRIMARY`
        primary key,
    activity_id          bigint       null comment '活动id',
    composite_id         bigint       null comment '事件组合id',
    strategy_name        varchar(64)  not null comment '策略名称',
    strategy_code        varchar(64)  not null comment '策略代码',
    strategy_description varchar(256) null comment '策略描述',
    event_def_id         bigint       not null comment '事件代码',
    rules                longtext     not null comment '事件规则',
    permanent            varchar(4)   not null comment '是否永久有效 YES:是, NO:否',
    status               varchar(32)  not null comment '策略状态 INIT:初始, FROZEN:禁用',
    created_at           datetime     not null comment '创建时间',
    updated_at           datetime     not null comment '更新时间'
);

create table if not exists sagittarius_template_json
(
    id                   bigint auto_increment
        constraint `PRIMARY`
        primary key,
    template_description varchar(255) not null comment '模板描述',
    template_code        varchar(64)  not null comment '模板code',
    template_name        varchar(64)  not null comment '模板名称',
    template_type        varchar(64)  not null comment '模板类型',
    template_context     longtext     not null comment 'json',
    created_at           datetime     null comment '创建时间',
    updated_at           datetime     null comment '更新时间',
    constraint UKfnq7nckshfmvwd8ge5s2fw7w5
        unique (template_code, template_type)
);


