create table if not exists batch_job_execution_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
);

create table if not exists batch_job_instance
(
    JOB_INSTANCE_ID bigint       not null,
    VERSION         bigint       null,
    JOB_NAME        varchar(100) not null,
    JOB_KEY         varchar(32)  not null,
    constraint `PRIMARY`
        primary key (JOB_INSTANCE_ID),
    constraint JOB_INST_UN
        unique (JOB_NAME, JOB_KEY)
);

create table if not exists batch_job_execution
(
    JOB_EXECUTION_ID           bigint        not null,
    VERSION                    bigint        null,
    JOB_INSTANCE_ID            bigint        not null,
    CREATE_TIME                datetime      not null,
    START_TIME                 datetime      null,
    END_TIME                   datetime      null,
    STATUS                     varchar(10)   null,
    EXIT_CODE                  varchar(2500) null,
    EXIT_MESSAGE               varchar(2500) null,
    LAST_UPDATED               datetime      null,
    JOB_CONFIGURATION_LOCATION varchar(2500) null,
    constraint `PRIMARY`
        primary key (JOB_EXECUTION_ID),
    constraint JOB_INST_EXEC_FK
        foreign key (JOB_INSTANCE_ID) references batch_job_instance (JOB_INSTANCE_ID)
);

create table if not exists batch_job_execution_context
(
    JOB_EXECUTION_ID   bigint        not null,
    SHORT_CONTEXT      varchar(2500) not null,
    SERIALIZED_CONTEXT text          null,
    constraint `PRIMARY`
        primary key (JOB_EXECUTION_ID),
    constraint JOB_EXEC_CTX_FK
        foreign key (JOB_EXECUTION_ID) references batch_job_execution (JOB_EXECUTION_ID)
);

create table if not exists batch_job_execution_params
(
    JOB_EXECUTION_ID bigint       not null,
    TYPE_CD          varchar(6)   not null,
    KEY_NAME         varchar(100) not null,
    STRING_VAL       varchar(250) null,
    DATE_VAL         datetime     null,
    LONG_VAL         bigint       null,
    DOUBLE_VAL       double       null,
    IDENTIFYING      char         not null,
    constraint JOB_EXEC_PARAMS_FK
        foreign key (JOB_EXECUTION_ID) references batch_job_execution (JOB_EXECUTION_ID)
);

create table if not exists batch_job_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
);

create table if not exists batch_step_execution
(
    STEP_EXECUTION_ID  bigint        not null,
    VERSION            bigint        not null,
    STEP_NAME          varchar(100)  not null,
    JOB_EXECUTION_ID   bigint        not null,
    START_TIME         datetime      not null,
    END_TIME           datetime      null,
    STATUS             varchar(10)   null,
    COMMIT_COUNT       bigint        null,
    READ_COUNT         bigint        null,
    FILTER_COUNT       bigint        null,
    WRITE_COUNT        bigint        null,
    READ_SKIP_COUNT    bigint        null,
    WRITE_SKIP_COUNT   bigint        null,
    PROCESS_SKIP_COUNT bigint        null,
    ROLLBACK_COUNT     bigint        null,
    EXIT_CODE          varchar(2500) null,
    EXIT_MESSAGE       varchar(2500) null,
    LAST_UPDATED       datetime      null,
    constraint `PRIMARY`
        primary key (STEP_EXECUTION_ID),
    constraint JOB_EXEC_STEP_FK
        foreign key (JOB_EXECUTION_ID) references batch_job_execution (JOB_EXECUTION_ID)
);

create table if not exists batch_step_execution_context
(
    STEP_EXECUTION_ID  bigint        not null,
    SHORT_CONTEXT      varchar(2500) not null,
    SERIALIZED_CONTEXT text          null,
    constraint `PRIMARY`
        primary key (STEP_EXECUTION_ID),
    constraint STEP_EXEC_CTX_FK
        foreign key (STEP_EXECUTION_ID) references batch_step_execution (STEP_EXECUTION_ID)
);

create table if not exists batch_step_execution_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
);

create table if not exists tag
(
    id                 bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id          bigint                    null comment '租户Id',
    target_code        varchar(32)               not null comment '打标对象编号',
    name               varchar(256) default ''   not null comment '标签项目名称',
    code               varchar(32)               not null comment '标签项目唯一编码,用于提交运算',
    english_name       varchar(256)              null comment '英文名',
    tag_type           tinyint(1)                not null comment '标签类型, 1:自动标签；2:手动标签',
    value_type         tinyint(1)                not null comment '取值类型, 0:单值非枚举；1:单值枚举；2:多值非枚举；3:多值枚举',
    usage_rate         int(4)                    null comment '标签使用率，单位为百分比*10000, 即只存储整数',
    coverage_rate      int(4)                    null comment '标签覆盖率，单位为百分比*10000, 即只存储整数',
    threshold_coverage int(4)       default 2500 null comment '覆盖率阈值',
    version            varchar(512)              null comment '标签版本',
    status             tinyint(1)                not null comment '状态：1-启用；0-停用',
    description        varchar(1024)             null,
    is_config_channel  int(4)       default 0    null comment '是否配置渠道排序信息',
    is_business_tag    tinyint                   null comment '是否可加工成业务标签 1:是 2:否',
    relation_tag_id    bigint                    null comment '关联自动标签',
    period_type        tinyint                   null comment '周期类型 1:固定时间 2:固定天数',
    start_time         datetime                  null comment '时间周期-开始时间',
    end_time           datetime                  null comment '时间周期-结束时间',
    days               tinyint                   null comment '固定天数',
    compute_type       tinyint                   null comment '0:X= 1:X< 2:X> 3:X<= 4:X>= 5:<X< 6:<=X< 7:<X<= 8:<=X<=',
    value_a            tinyint                   null comment 'A值',
    value_b            tinyint                   null comment 'B值',
    created_by         varchar(32)               null,
    updated_by         varchar(32)               null,
    created_at         datetime                  not null comment '创建时间',
    updated_at         datetime                  not null comment '更新时间'
)
    comment '标签表' charset = utf8;

create index idx_tag_code
    on tag (code);

create table if not exists tag_batch_job_execution_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
)
    collate = utf8mb4_unicode_ci;

create table if not exists tag_batch_job_instance
(
    JOB_INSTANCE_ID bigint       not null,
    VERSION         bigint       null,
    JOB_NAME        varchar(100) not null,
    JOB_KEY         varchar(32)  not null,
    constraint `PRIMARY`
        primary key (JOB_INSTANCE_ID),
    constraint TAG_BATCH_JOB_INST_UN
        unique (JOB_NAME, JOB_KEY)
)
    collate = utf8mb4_unicode_ci;

create table if not exists tag_batch_job_execution
(
    JOB_EXECUTION_ID           bigint        not null,
    VERSION                    bigint        null,
    JOB_INSTANCE_ID            bigint        not null,
    CREATE_TIME                datetime      not null,
    START_TIME                 datetime      null,
    END_TIME                   datetime      null,
    STATUS                     varchar(10)   null,
    EXIT_CODE                  varchar(2500) null,
    EXIT_MESSAGE               varchar(2500) null,
    LAST_UPDATED               datetime      null,
    JOB_CONFIGURATION_LOCATION varchar(2500) null,
    constraint `PRIMARY`
        primary key (JOB_EXECUTION_ID),
    constraint TAG_BATCH_JOB_INST_EXEC_FK
        foreign key (JOB_INSTANCE_ID) references tag_batch_job_instance (JOB_INSTANCE_ID)
)
    collate = utf8mb4_unicode_ci;

create table if not exists tag_batch_job_execution_context
(
    JOB_EXECUTION_ID   bigint        not null,
    SHORT_CONTEXT      varchar(2500) not null,
    SERIALIZED_CONTEXT text          null,
    constraint `PRIMARY`
        primary key (JOB_EXECUTION_ID),
    constraint TAG_JOB_EXEC_CTX_FK
        foreign key (JOB_EXECUTION_ID) references tag_batch_job_execution (JOB_EXECUTION_ID)
)
    collate = utf8mb4_unicode_ci;

create table if not exists tag_batch_job_execution_params
(
    JOB_EXECUTION_ID bigint       not null,
    TYPE_CD          varchar(6)   not null,
    KEY_NAME         varchar(100) not null,
    STRING_VAL       varchar(250) null,
    DATE_VAL         datetime     null,
    LONG_VAL         bigint       null,
    DOUBLE_VAL       double       null,
    IDENTIFYING      char         not null,
    constraint TAG_JOB_EXEC_PARAMS_FK
        foreign key (JOB_EXECUTION_ID) references tag_batch_job_execution (JOB_EXECUTION_ID)
)
    collate = utf8mb4_unicode_ci;

create index JOB_EXEC_PARAMS_FK
    on tag_batch_job_execution_params (JOB_EXECUTION_ID);

create table if not exists tag_batch_job_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
)
    collate = utf8mb4_unicode_ci;

create table if not exists tag_batch_step_execution
(
    STEP_EXECUTION_ID  bigint        not null,
    VERSION            bigint        not null,
    STEP_NAME          varchar(100)  not null,
    JOB_EXECUTION_ID   bigint        not null,
    START_TIME         datetime      not null,
    END_TIME           datetime      null,
    STATUS             varchar(10)   null,
    COMMIT_COUNT       bigint        null,
    READ_COUNT         bigint        null,
    FILTER_COUNT       bigint        null,
    WRITE_COUNT        bigint        null,
    READ_SKIP_COUNT    bigint        null,
    WRITE_SKIP_COUNT   bigint        null,
    PROCESS_SKIP_COUNT bigint        null,
    ROLLBACK_COUNT     bigint        null,
    EXIT_CODE          varchar(2500) null,
    EXIT_MESSAGE       varchar(2500) null,
    LAST_UPDATED       datetime      null,
    constraint `PRIMARY`
        primary key (STEP_EXECUTION_ID),
    constraint TAG_BATCH_JOB_EXEC_STEP_FK
        foreign key (JOB_EXECUTION_ID) references tag_batch_job_execution (JOB_EXECUTION_ID)
)
    collate = utf8mb4_unicode_ci;

create table if not exists tag_batch_step_execution_context
(
    STEP_EXECUTION_ID  bigint        not null,
    SHORT_CONTEXT      varchar(2500) not null,
    SERIALIZED_CONTEXT text          null,
    constraint `PRIMARY`
        primary key (STEP_EXECUTION_ID),
    constraint TAG_STEP_EXEC_CTX_FK
        foreign key (STEP_EXECUTION_ID) references tag_batch_step_execution (STEP_EXECUTION_ID)
)
    collate = utf8mb4_unicode_ci;

create table if not exists tag_batch_step_execution_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
)
    collate = utf8mb4_unicode_ci;

create table if not exists tag_channel_call_log
(
    id           bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    channel_id   bigint      null comment '调用渠道id',
    channel_name varchar(32) null comment '调用渠道名称',
    created_at   datetime    null comment '创建时间'
)
    comment '渠道调用日志表' charset = utf8;

create table if not exists tag_channel_sort
(
    id                bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id         bigint            null comment '租户Id',
    tag_id            bigint            not null comment '标签编号',
    tag_name          varchar(256)      not null comment '标签名称',
    channel_sort_json text              not null comment '标签渠道排序json',
    delete_flag       tinyint default 0 null comment '删除标识，0:未删除,1:已删除',
    created_by        varchar(32)       null,
    updated_by        varchar(32)       null,
    created_at        datetime          not null comment '创建时间',
    updated_at        datetime          not null comment '更新时间'
)
    comment '标签渠道排序表' charset = utf8;

create table if not exists tag_classify
(
    id           bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id    bigint       null comment '租户Id',
    target_code  varchar(32)  not null comment '打标对象编号',
    parent_id    bigint       null comment '父级id',
    has_children tinyint(1)   null comment '是否有孩子',
    name         varchar(256) not null comment '分类名称',
    english_name varchar(256) null comment '英文名',
    table_num    int(10)      null comment '表数',
    tag_num      int(10)      null comment '标签数',
    description  varchar(512) null comment '分类描述',
    level        int(10)      null comment '层级',
    created_by   varchar(32)  null comment '创建人id',
    updated_by   varchar(32)  null comment '修改人id',
    created_at   datetime     not null comment '创建时间',
    updated_at   datetime     not null comment '更新时间'
)
    comment '标签分类表' charset = utf8;

create table if not exists tag_classify_rel
(
    id          bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    classify_id bigint      null comment '标签分类id',
    tag_id      bigint      null comment '标签项id',
    created_by  varchar(32) null comment '创建人id',
    updated_by  varchar(32) null comment '修改人id',
    created_at  datetime    not null comment '创建时间',
    updated_at  datetime    not null comment '更新时间'
)
    comment '标签项标签分类关系表' charset = utf8;

create table if not exists tag_coverage_rate
(
    code       varchar(255) default ''                not null comment '标签编码',
    rate       int                                    null comment '标签覆盖率',
    created_at datetime     default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at datetime     default CURRENT_TIMESTAMP not null comment '更新时间',
    constraint `PRIMARY`
        primary key (code)
)
    comment '标签覆盖率表' charset = utf8;

create table if not exists tag_extension
(
    id         bigint(11) unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    tag_id     bigint(11)   not null comment 'tag_key主键',
    special    tinyint(1)   null comment '是否特殊标签',
    excel_hint varchar(255) null comment 'excel模板提示',
    created_at datetime     null comment '创建日期',
    updated_at datetime     null comment '更新日期'
)
    charset = utf8;

create table if not exists tag_group
(
    id          bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id   bigint                  null comment '租户Id',
    target_code varchar(32)             not null comment '打标对象编号',
    name        varchar(32)             null comment '群组名称',
    description varchar(255)            null comment '群组描述',
    is_public   tinyint                 null,
    is_top      tinyint                 null comment '是否置顶 1-是 0-否',
    object_num  int                     null comment '关联的打标对象数',
    status      tinyint(1)              not null comment '状态：1-启用；0-停用',
    created_by  varchar(32)             null comment '创建人id',
    updated_by  varchar(32)             null comment '修改人id',
    created_at  datetime                not null comment '创建时间',
    updated_at  datetime                not null comment '更新时间',
    source_type tinyint                 null comment '类型 1:外部群组 2：内部群组',
    group_type  varchar(32) default '1' not null comment '类型：1：正式群组 0：零时群组'
)
    comment '标签群组表' charset = utf8;

create index idx_target
    on tag_group (target_code);

create table if not exists tag_group_copy1
(
    id          bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id   bigint                  null comment '租户Id',
    target_code varchar(32)             not null comment '打标对象编号',
    name        varchar(32)             null comment '群组名称',
    description varchar(255)            null comment '群组描述',
    is_public   tinyint                 null,
    is_top      tinyint                 null comment '是否置顶 1-是 0-否',
    object_num  int                     null comment '关联的打标对象数',
    status      tinyint(1)              not null comment '状态：1-启用；0-停用',
    created_by  varchar(32)             null comment '创建人id',
    updated_by  varchar(32)             null comment '修改人id',
    created_at  datetime                not null comment '创建时间',
    updated_at  datetime                not null comment '更新时间',
    source_type tinyint                 null comment '类型 1:外部群组 2：内部群组',
    group_type  varchar(32) default '1' not null comment '类型：1：正式群组 0：零时群组'
)
    comment '标签群组表' charset = utf8;

create index idx_target
    on tag_group_copy1 (target_code);

create table if not exists tag_group_intersection_info
(
    id               bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id        bigint            null comment '租户Id',
    group_a_id       bigint            not null comment '群组A编号',
    group_b_id       bigint            not null comment '群组B编号',
    group_a_num      bigint            null comment '群组A人数',
    group_b_num      bigint            null comment '群组B人数',
    intersection_num bigint            null comment '交集人数',
    plan             smallint          null comment '进度',
    delete_flag      tinyint default 0 null comment '删除标识，0:未删除,1:已删除',
    created_by       varchar(32)       null,
    updated_by       varchar(32)       null,
    created_at       datetime          not null comment '创建时间',
    updated_at       datetime          not null comment '更新时间'
)
    comment '群组对比记录表' charset = utf8;

create table if not exists tag_group_rel
(
    id          bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    target_code varchar(32) not null comment '打标对象编号',
    group_id    bigint      null comment '群组id',
    tag_id      bigint      null comment '标签id',
    tag_code    varchar(32) null comment '标签编码',
    tag_type    tinyint(1)  not null comment '标签类型, 1:自动标签；2:手动标签',
    value_id    bigint      null comment '标签值id',
    value_name  varchar(32) null comment '标签值名称',
    select_flag tinyint     null comment '链接标志，1-in，0-not in, 2-and',
    created_by  varchar(32) null comment '创建人id',
    updated_by  varchar(32) null comment '修改人id',
    created_at  datetime    not null comment '创建时间',
    updated_at  datetime    not null comment '更新时间'
)
    comment '群组标签关系表' charset = utf8;

create table if not exists tag_group_rel_model
(
    id          bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    target_code varchar(32) not null comment '打标对象编号',
    group_id    bigint      null comment '群组id',
    rel_json    text        null comment '群组标签关系json',
    created_by  varchar(32) null comment '创建人id',
    updated_by  varchar(32) null comment '修改人id',
    created_at  datetime    not null comment '创建时间',
    updated_at  datetime    not null comment '更新时间'
)
    comment '群组标签关系表' charset = utf8;

create index idx_groupid
    on tag_group_rel_model (group_id);

create table if not exists tag_index_factor
(
    id                      bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    tenant_id               bigint                   null comment '租户ID',
    tag_extraction_index_id bigint                   not null comment '萃取指标配置ID',
    index_name              varchar(64)   default '' not null comment '指标名称',
    index_attr_type         tinyint                  not null comment '指标属性(1:文本,2:数字)',
    factor_type             tinyint                  not null comment '因子类型(0:指标,1:字段,2:标签值,3事件)',
    factor_id               varchar(256)  default '' not null comment '因子ID',
    factor_name             varchar(64)   default '' not null comment '因子名称',
    factor_attr_type        tinyint                  not null comment '因子属性(1:文本,2:数字)',
    extra_json              varchar(1024) default '' null comment '扩展',
    created_by              varchar(64)              null comment '创建人',
    updated_by              varchar(64)              null comment '更新人',
    created_at              datetime                 null comment '创建时间',
    updated_at              datetime                 null comment '更新时间'
)
    comment '萃取指标因子';

create table if not exists tag_manual_batch_task
(
    id              bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    manual_key_id   bigint      null comment '手动标签id',
    manual_key_code varchar(32) null comment '手动标签编码',
    manual_key_name varchar(32) null comment '手动标签名称',
    status          tinyint(1)  null comment '状态',
    type            tinyint(1)  null comment '类型',
    created_at      datetime    null comment '创建时间',
    updated_at      datetime    null comment '更新时间'
)
    comment '批量手动标签任务' charset = utf8;

create table if not exists tag_marketing_task
(
    id          bigint unsigned auto_increment comment 'ID'
        constraint `PRIMARY`
        primary key,
    activity_id varchar(64) default '' not null comment '活动ID',
    request_no  varchar(64) default '' not null comment '请求编号',
    request     text                   not null comment '请求体',
    url         text                   null comment '文件路径',
    sign        varchar(64) default '' not null comment 'MD5',
    status      tinyint                not null comment '状态0：任务创建成功，1：任务执行中，2：任务执行成功，3：任务执行失败，4：任务回调中，5：任务回调成功，6：任务回调失败',
    created_at  datetime               not null comment '创建时间',
    updated_at  datetime               not null comment '更新时间'
)
    comment '营销活动预查用户信息任务' collate = utf8mb4_unicode_ci;

create index ac_re_si_key
    on tag_marketing_task (activity_id, request_no, sign);

create table if not exists tag_portrait_charts_config
(
    id          bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id   int(20)    default 0 null comment '租户Id',
    target_code varchar(32)          null,
    name        varchar(32)          null comment '配置名称',
    code        varchar(255)         null comment '配置编码',
    type        tinyint    default 2 null comment '类型，比如单体画像 - 1，群组画像 - 2',
    config_json mediumtext           null comment '配置json串',
    extra_json  varchar(2048)        null comment 'extra_json',
    status      tinyint(2) default 1 null comment '启用标志：1-启用；0-停用',
    created_at  datetime             null comment '创建时间',
    updated_at  datetime             null comment '更新时间'
)
    comment '标签画像的配置表' charset = utf8;

create index idx_type_status
    on tag_portrait_charts_config (type, status);

create table if not exists tag_portrait_charts_info
(
    id          bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id   bigint            null comment '租户Id',
    chart_name  varchar(32)       not null comment '图表名称',
    tab_id      bigint            not null comment '所属模块',
    tag_id      bigint            not null comment '关联标签',
    chart_type  varchar(32)       not null comment '图标类型 Gender:性别分布,Map-district:地域分布，Pie:饼图，Bar-orthogonal:柱状图，line:折线图',
    is_top      smallint          null comment '是否top 1:是，0:否',
    top_num     smallint(8)       null comment 'top num',
    `order`     smallint          null comment '排序 0:无,1:asc顺序,2:desc逆序',
    delete_flag tinyint default 0 null comment '删除标识，0:未删除,1:已删除',
    created_by  varchar(32)       null,
    updated_by  varchar(32)       null,
    created_at  datetime          not null comment '创建时间',
    updated_at  datetime          not null comment '更新时间'
)
    comment '群组画像配置' charset = utf8;

create table if not exists tag_portrait_tab_info
(
    id          bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id   bigint            null comment '租户Id',
    tab_name    varchar(32)       not null comment 'tab名称',
    delete_flag tinyint default 0 null comment '删除标识，0:未删除,1:已删除',
    created_by  varchar(32)       null,
    updated_by  varchar(32)       null,
    created_at  datetime          not null comment '创建时间',
    updated_at  datetime          not null comment '更新时间'
)
    comment '群组画像Tab表' charset = utf8;

create table if not exists tag_project
(
    id              bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    name            varchar(32)  null comment '项目名称',
    `desc`          varchar(255) null comment '标签描述',
    tag_num         int(10)      null comment '标签数',
    created_by_id   bigint       null comment '创建人id',
    created_by_name varchar(64)  null comment '创建人名称',
    created_at      datetime     null comment '创建时间',
    updated_at      datetime     null comment '更新时间'
)
    comment '标签项目表' charset = utf8;

create table if not exists tag_project_rel
(
    id         bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    project_id bigint   null comment '标签项目id',
    tag_id     bigint   null comment '标签项id',
    created_at datetime null comment '创建时间',
    updated_at datetime null comment '更新时间'
)
    comment '项目标签关联关系表' charset = utf8;

create table if not exists tag_refresh_monitor
(
    id               bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id        bigint      null comment '租户Id',
    target_code      varchar(32) not null comment '打标对象编号',
    tag_id           bigint      null comment '标签id',
    tag_refresh_icon int         null comment '刷新频率',
    status           tinyint(2)  not null comment '同步状态 0-新建 1-同步中 2-同步成功 3-同步失败',
    created_by       varchar(32) null comment '创建人id',
    created_at       datetime    not null comment '创建时间',
    updated_at       datetime    not null comment '更新时间'
)
    comment '标签刷新监控表' charset = utf8;

create table if not exists tag_relation_table
(
    id              bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    name            varchar(32)  null comment '标签分类id',
    `desc`          varchar(255) null comment '标签项id',
    hive_table      varchar(255) null comment '大数据表名',
    partition       varchar(255) null comment '分区值',
    created_by_id   bigint       null comment '创建人id',
    created_by_name varchar(32)  null comment '创建人姓名',
    created_at      datetime     null comment '创建时间',
    updated_at      datetime     null comment '更新时间',
    is_increment    tinyint(1)   not null comment '是否增量',
    example         varchar(255) null comment '数据示例'
)
    comment '标签 计算关联结构表 表' charset = utf8;

create table if not exists tag_rule
(
    id              bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id       bigint       null comment '租户Id',
    target_code     varchar(32)  not null comment '打标对象编号',
    tag_id          bigint       not null comment '标签项id',
    tag_code        varchar(32)  not null comment '标签项编码',
    rule_json_all   text         null comment '全量规则配置json',
    rule_json_incr  text         null comment '增量规则配置json',
    dependency_flag tinyint(1)   not null comment '独立计算标识，0:独立在计算平台计算；1:依赖标签工厂逻辑计算',
    refresh_icon    varchar(32)  null comment '标签刷新频率',
    is_increment    tinyint(1)   null,
    description     varchar(255) null comment '说明',
    created_by      varchar(32)  null comment '创建人id',
    updated_by      varchar(32)  null comment '修改人id',
    created_at      datetime     not null comment '创建时间',
    updated_at      datetime     not null comment '更新时间'
)
    comment '自动打标规则表' charset = utf8;

create index idx_tag_code
    on tag_rule (tag_code);

create index idx_tag_id
    on tag_rule (tag_id);

create table if not exists tag_schedule_all
(
    id            int(11) unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id     bigint                 null comment '租户Id',
    name          varchar(255)           null,
    id_start      bigint                 null,
    id_end        bigint                 null,
    updated_start varchar(32) default '' not null,
    updated_end   varchar(32) default '' not null
)
    charset = utf8;

create table if not exists tag_sync_task
(
    id              bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id       bigint                 null comment '租户Id',
    target_code     varchar(32)            not null comment '打标对象编号',
    tag_id          bigint                 not null comment '标签id',
    tag_code        varchar(32) default '' not null comment '标签编码',
    tag_name        varchar(32) default '' not null comment '标签名称',
    value_type      tinyint(1)             not null comment '标签类型, 0:单值非枚举；1:单值枚举；2:多值非枚举；3:多值枚举',
    rule_id         bigint                 not null comment '使用规则id',
    rule_json       text                   null comment '使用规则当时配置',
    dependency_flag tinyint(1)             null comment '独立计算标识，0:独立在计算平台计算；1:依赖标签工厂逻辑计算',
    refresh_icon    varchar(32)            null comment '标签刷新频率',
    usage_rate      int(4)                 null comment '标签使用率，单位为百分比*10000, 即只存储整数',
    coverage_rate   int(4)                 null comment '标签覆盖率，单位为百分比*10000, 即只存储整数',
    bigdata_task_id text                   null comment '大数据任务id',
    last_version    varchar(255)           null comment '同步之前的标签版本',
    bigdata_job_id  varchar(255)           null comment '此次大数据同步任务id',
    version         varchar(255)           null comment '此次标签版本',
    status          tinyint                not null comment '同步状态 0-新建 1-已提交（同步中） 2-提交失败 3-计算成功 4-计算失败',
    created_by      varchar(32)            null comment '创建人id',
    created_at      datetime               not null comment '创建时间',
    updated_at      datetime               not null comment '更新时间',
    constraint idx_job_id
        unique (bigdata_job_id)
)
    comment '标签同步任务表' charset = utf8;

create table if not exists tag_target
(
    id          bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id   bigint       null comment '租户Id',
    code        varchar(32)  not null comment '打标对象编号',
    name        varchar(128) not null comment '打标对象名称',
    description varchar(255) null comment '说明',
    created_by  varchar(32)  null comment '创建人id',
    updated_by  varchar(32)  null comment '修改人id',
    created_at  datetime     not null comment '创建时间',
    updated_at  datetime     not null comment '更新时间',
    constraint code
        unique (code)
)
    comment '打标对象' charset = utf8;

create table if not exists tag_target_result
(
    id          bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id   bigint                   null comment '租户Id',
    target_code varchar(32)              not null comment '打标对象编号',
    object_id   bigint                   null comment '打标对象实例id',
    tag_id      bigint                   not null comment '标签项id',
    tag_code    varchar(32)              not null comment '标签项编码',
    tag_type    tinyint(1)               not null comment '标签类型, 1:自动标签；2:手动标签',
    value_id    bigint                   null,
    value       varchar(1024) default '' not null comment '标签项枚举值',
    version     varchar(255)             null comment '标签版本',
    created_by  varchar(32)              null comment '创建人id',
    updated_by  varchar(32)              null comment '修改人id',
    created_at  datetime                 not null comment '创建时间',
    updated_at  datetime                 not null comment '更新时间',
    constraint object_id_tag_unique
        unique (target_code, object_id, tag_code)
)
    comment '打标结果表' charset = utf8;

create index idx_tag_code
    on tag_target_result (tag_code);

create index idx_target_code
    on tag_target_result (tag_id, target_code);

create table if not exists tag_value
(
    id          bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id   bigint                  null comment '租户Id',
    tag_id      bigint                  not null comment '标签id',
    tag_code    varchar(32)  default '' not null comment '标签编码',
    tag_type    tinyint(1)              not null comment '标签类型, 1:自动标签；2:手动标签',
    value_type  tinyint(1)              not null comment '取值类型, 0:单值非枚举；1:单值枚举；2:多值非枚举；3:多值枚举',
    value       varchar(128) default '' not null comment '标签值',
    description varchar(512)            null comment '标签值说明',
    created_by  varchar(32)             null,
    updated_by  varchar(32)             null,
    created_at  datetime                not null comment '创建时间',
    updated_at  datetime                not null comment '更新时间',
    constraint idx_tag_code_value
        unique (tag_id, tag_code, value, tag_type)
)
    comment '标签值表' charset = utf8;

create table if not exists tag_value_index_rel
(
    id               bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id        bigint                 null comment '租户Id',
    tag_id           bigint                 not null comment '标签Id',
    tag_code         varchar(32) default '' not null comment '标签编码',
    value_id         bigint                 not null comment '标签值id',
    value            varchar(128)           null comment '标签项枚举值',
    index_id         bigint                 not null comment '标签计算关联表id',
    description      varchar(1024)          null,
    is_increment     tinyint(1)             null comment '是否增量 0-否  1-是',
    compute_function tinyint(1)             null comment '关联字段计算函数， 0:不使用，1:%',
    compute_type     tinyint(1)             null comment '关联字段计算逻辑, 0:X= 1:X< 2:X> 3:X<= 4:X>= 5:<X< 6:<=X< 7:<X<= 8:<=X<= 9:like',
    max_range        varchar(128)           null comment '计算范围的上限',
    min_range        varchar(128)           null comment '计算范围的下限',
    logic_type       tinyint(1)             null comment '逻辑标识  1-and；0-or',
    created_by       varchar(32)            null,
    updated_by       varchar(32)            null,
    created_at       datetime               not null comment '创建时间',
    updated_at       datetime               not null comment '更新时间'
)
    comment '标签值萃取表关系表' charset = utf8;

create index idx_key_value_index
    on tag_value_index_rel (tag_id, value_id, index_id);


