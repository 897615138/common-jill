create table if not exists aquarius_city_config
(
    id           bigint auto_increment
        constraint `PRIMARY`
        primary key,
    p_id         bigint        null comment '省ID',
    p_name       varchar(50)   null comment '省名称',
    c_id         bigint        null comment '市ID',
    c_name       varchar(50)   null comment '市名称',
    city_status  tinyint       not null comment '状态 1：已添加2：未添加',
    creator_id   varchar(32)   null comment '创建人id',
    creator_name varchar(32)   null comment '创建人名称',
    created_at   datetime      null comment '创建时间',
    updator_id   varchar(32)   null comment '更新人id',
    updator_name varchar(32)   null comment '更新人名称',
    updated_at   datetime      null comment '更新时间',
    del_flag     tinyint       null comment '是否删除',
    extra_json   varchar(1024) null comment '其他信息'
)
    charset = utf8;

create index idx_city_pname
    on aquarius_city_config (p_name);

create table if not exists aquarius_composite_task
(
    id            bigint auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    target_id     varchar(64)       not null comment '目标ID',
    task_type     varchar(32)       not null comment '任务类型',
    task_status   varchar(16)       not null comment '任务状态 WAITING:待处理 SUCCESS:失败 FAILED:成功',
    retry_count   int(10) default 0 not null comment '重试次数',
    extra_json    text              null comment '任务额外任务额外信息',
    create_at     datetime          null comment '创建时间',
    update_at     datetime          null comment '更新时间',
    notice_status varchar(16)       not null comment '通知状态 NOT_NOTICE:未通知,FINISH_NOTICE:通知',
    constraint target_id_type_unique
        unique (target_id, task_type)
)
    comment '补偿任务表' charset = utf8;

create table if not exists aquarius_configure
(
    id           bigint auto_increment comment '配置ID'
        constraint `PRIMARY`
        primary key,
    name         varchar(256)      not null comment '版本标题',
    status       tinyint           null comment '状态：1：草稿 2 ：启用 3 ：停用',
    type         tinyint           not null comment '类型 ：1 会员协议 2 隐私条款 3常用问答',
    content      text              not null comment '内容',
    creator      varchar(256)      not null comment '创建人',
    creator_id   varchar(256)      not null comment '创建人ID',
    created_at   datetime          not null comment '创建时间',
    updator      varchar(256)      null comment '更新人',
    updator_id   varchar(256)      null comment '更新人ID',
    updated_at   datetime          null comment '更新时间',
    extra_json   varchar(256)      null comment '其他',
    del_flag     tinyint           null comment '是否删除',
    weight       int(10) default 1 not null comment '权重',
    flow_id      varchar(63)       null comment '流程实例id',
    audit_status varchar(31)       null comment '审批状态 WAITING 审批中 ,SUCCESS 审批通过  ,FAILED 审批不通过',
    channel      varchar(32)       not null comment '渠道信息'
);

create table if not exists aquarius_item
(
    id                   bigint auto_increment comment '商品ID'
        constraint `PRIMARY`
        primary key,
    tenant_id            bigint                                 not null comment '租户ID',
    name                 varchar(200) default ''                not null comment '商品名称',
    category_id          bigint                                 not null comment '商品类目id',
    code                 varchar(32)                            not null comment '商品编码',
    type                 varchar(16)  default ''                not null comment 'GIFT:礼品 COUPON:优惠券',
    description          mediumtext                             null comment '商品描述',
    supplier_id          varchar(64)                            not null comment '供应商id',
    supplier_name        varchar(64)                            not null comment '供应商名称',
    out_code             varchar(32)                            null comment '外部商品编码',
    out_name             text                                   null comment '外部商品名称',
    bu_code              varchar(64)  default ''                not null comment '关联渠道',
    bu_name              varchar(64)  default ''                not null comment '关联渠道名',
    thumbnail            text                                   not null comment '缩略图',
    main_image           text                                   not null comment '主图',
    price                decimal(18, 2)                         null comment '市面价值',
    sellable_quantity    int          default 0                 null comment '可用数量',
    withhold_quantity    int          default 0                 null comment '锁定数量',
    real_quantity        int          default 0                 null comment '实际使用数量',
    exchange_accounts    text                                   not null comment '兑换账户的信息 [{"glCode":"","glName":"","price":10}]',
    rule_id              text                                   null comment '兑换规则ID',
    activity_id          varchar(64)                            null comment '活动ID',
    activity_name        varchar(64)                            null comment '活动名称',
    status               varchar(16)  default 'OFF_SHELVES'     not null comment '状态 TOBE_ONSALE:待上架 TOBE_OFFSALE:待下架 ONSALE:上架 OFFSALE:下架',
    onsale_time          datetime                               null comment '上架时间',
    offsale_time         datetime                               null comment '下架时间',
    flow_id              varchar(64)                            null comment '审批流id',
    reason               text                                   null comment '审批原因',
    approval_type        varchar(16)                            null comment '审批类型 ONSALE:上架 OFFSALE:下架',
    delay                datetime                               null comment '延迟时间',
    approval_start       datetime                               null comment '审批发起时间',
    approval_end         datetime                               null comment '审批结束时间',
    approval_status      varchar(16)                            null comment '审批状态 APPROVALING:审批中 APPROVALED:已审批 UNAPPROVAL:驳回',
    approval_sponsor     varchar(128)                           null comment '审批发起人',
    ext1                 text                                   null comment '扩展字段1',
    ext2                 varchar(32)  default 'NOT_IMPORT'      null comment '扩展字段2 商品打标标记 NOT_IMPORT:未导入 FINISH_IMPORT:已导入',
    ext3                 text                                   null comment '扩展字段3',
    extra_json           text                                   null comment '扩展json字段',
    created_at           datetime     default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at           datetime     default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    created_by           varchar(128) default ''                not null comment '创建人',
    updated_by           varchar(128) default ''                not null comment '更新人',
    activity_use_channel varchar(64)                            null comment '活动使用渠道',
    constraint UK_code_tenant_id
        unique (code)
)
    comment '商品' charset = utf8;

create table if not exists aquarius_item_approval
(
    id                bigint auto_increment comment 'ID'
        constraint `PRIMARY`
        primary key,
    tenant_id         bigint                                 not null comment '租户ID',
    name              varchar(200) default ''                not null comment '商品名称',
    category_id       bigint                                 not null comment '商品类目id',
    code              varchar(32)                            not null comment '商品编码',
    type              varchar(16)  default ''                not null comment 'GIFT:礼品 COUPON:优惠券',
    description       text                                   null comment '商品描述',
    supplier_id       varchar(64)                            not null comment '供应商id',
    supplier_name     varchar(64)                            not null comment '供应商名称',
    out_code          varchar(32)                            null comment '外部商品编码',
    out_name          text                                   null comment '外部商品名称',
    bu_code           varchar(64)  default ''                not null comment '关联渠道',
    bu_name           varchar(64)  default ''                not null comment '关联渠道名',
    thumbnail         text                                   not null comment '缩略图',
    main_image        text                                   not null comment '主图',
    price             decimal(18, 2)                         null comment '市面价值',
    sellable_quantity int          default 0                 null comment '可用数量',
    withhold_quantity int          default 0                 null comment '锁定数量',
    real_quantity     int          default 0                 null comment '实际使用数量',
    exchange_accounts text                                   not null comment '兑换账户的信息 [{"glCode":"","glName":"","price":10}]',
    rule_id           text                                   null comment '兑换规则ID',
    activity_id       varchar(64)                            null comment '活动ID',
    activity_name     varchar(64)                            null comment '活动名称',
    status            varchar(16)  default 'OFF_SHELVES'     not null comment '状态 TOBE_ONSALE:待上架 TOBE_OFFSALE:待下架 ONSALE:上架 OFFSALE:下架',
    onsale_time       datetime                               null comment '上架时间',
    offsale_time      datetime                               null comment '下架时间',
    flow_id           varchar(64)  default ''                not null comment '审批流id',
    reason            text                                   null comment '审批原因',
    approval_type     varchar(16)                            null comment '审批类型 ONSALE:上架 OFFSALE:下架',
    delay             datetime                               null comment '延迟时间',
    approval_start    datetime                               null comment '审批发起时间',
    approval_end      datetime                               null comment '审批结束时间',
    approval_status   varchar(16)                            null comment '审批状态 APPROVALING:审批中 APPROVALED:已审批 UNAPPROVAL:驳回',
    approval_sponsor  varchar(128)                           null comment '审批发起人',
    ext1              text                                   null comment '扩展字段1',
    ext2              text                                   null comment '扩展字段2',
    ext3              text                                   null comment '扩展字段3',
    extra_json        text                                   null comment '扩展json字段',
    created_at        datetime     default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at        datetime     default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    created_by        varchar(128) default ''                not null comment '创建人',
    updated_by        varchar(128) default ''                not null comment '更新人',
    constraint UK_flowId
        unique (flow_id)
)
    comment '审批快照' charset = utf8;

create table if not exists aquarius_item_cart
(
    id         bigint auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id  bigint                                 not null comment '租户ID',
    member_id  bigint                                 not null comment '会员ID',
    item_code  varchar(32)                            not null comment '商品编码',
    item_type  varchar(16)                            not null comment 'GIFT:礼品 COUPON:优惠券',
    item_name  varchar(200) default ''                not null comment '商品名称',
    thumbnail  text                                   not null comment '缩略图',
    gl_code    varchar(16)                            not null comment '账户类型',
    gl_name    varchar(32)                            not null comment '账户类型名称',
    item_num   int(4)                                 not null comment '商品数量',
    total      int(4)                                 not null comment '积分总额',
    status     varchar(16)  default 'NOORDER'         not null comment '状态 NOORDER:未下单 PLACEORDER:已下单 DELETED:删除',
    ext1       text                                   null comment '扩展字段1',
    ext2       text                                   null comment '扩展字段2',
    ext3       text                                   null comment '扩展字段3',
    extra_json text                                   null comment '扩展json字段',
    created_at datetime     default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at datetime     default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by varchar(128)                           null comment '更新人'
)
    comment '购物车' charset = utf8;

create index cart_unique_index
    on aquarius_item_cart (member_id, item_code, gl_code, status);

create table if not exists aquarius_item_category
(
    id         bigint auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    tenant_id  bigint                                not null comment '租户ID',
    name       varchar(64)                           not null comment '类目名',
    type       varchar(16) default ''                not null comment 'UNLEAF:非叶子节点 LEAF:叶子节点',
    biz_type   varchar(20) default ''                not null comment 'GIFT:礼品 COUPON:优惠券',
    level      tinyint                               not null comment '层级',
    pid        bigint                                null comment '父id',
    status     varchar(16) default 'NORMAL'          not null comment '状态 NORMAL:正常 DELETED:删除',
    ext1       text                                  null comment '扩展字段1',
    ext2       text                                  null comment '扩展字段2',
    ext3       text                                  null comment '扩展字段3',
    extra_json text                                  null comment '扩展json字段',
    created_at datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by varchar(128)                          null comment '更新人'
)
    comment '类目' charset = utf8;

create table if not exists aquarius_item_redeem
(
    id                 bigint auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id          bigint                                 not null comment '租户ID',
    trade_no           varchar(32)                            not null comment '订单编号',
    sub_trade_no       varchar(32)                            not null comment '子订单编号',
    member_id          bigint                                 not null comment '会员ID',
    member_name        varchar(32)                            null comment '会员名称',
    member_mobile      varchar(11)                            null comment '会员手机号',
    receiver           varchar(32)                            null comment '收件人',
    receiver_province  varchar(64)                            null comment '收件人所在省',
    receiver_city      varchar(64)                            null comment '收件人城市',
    receiver_region    varchar(64)                            null comment '收件人地区',
    receiver_street    varchar(64)                            null comment '收件人街道',
    receiver_address   text                                   null comment '收件人地址',
    receiver_mobile    varchar(11)                            null comment '收件人手机号',
    bu_code            varchar(64)  default ''                not null comment '下单渠道',
    bu_name            varchar(64)  default ''                not null comment '下单渠道名',
    portal             varchar(16)                            not null comment '下单portal',
    portal_name        varchar(64)  default ''                not null comment '下单portal名',
    thumbnail          text                                   not null comment '缩略图',
    item_code          varchar(32)                            not null comment '商品编码',
    item_name          varchar(200) default ''                not null comment '商品名称',
    item_type          varchar(16)                            not null comment 'GIFT:礼品 COUPON:优惠券',
    out_code           varchar(32)                            null comment '供应商商品编码',
    out_name           text                                   null comment '供应商商品名称',
    gl_code            varchar(16)                            not null comment '账户类型',
    gl_name            varchar(64)  default ''                not null comment '账户类型名',
    item_num           int(4)                                 not null comment '商品数量',
    item_price         int(4)                                 not null comment '商品单价',
    trade_at           datetime     default CURRENT_TIMESTAMP not null comment '兑换时间',
    status             varchar(16)                            not null comment '状态 ',
    activity_id        varchar(64)                            null comment '活动ID',
    activity_name      varchar(64)                            null comment '活动名称',
    out_trade_no       varchar(100) default ''                null comment '外部订单编号',
    out_status         varchar(32)  default 'TODELIVER'       not null comment '外部订单状态',
    tms_no             varchar(200)                           null comment '物流单号',
    ext1               text                                   null comment '扩展字段1',
    ext2               text                                   null comment '扩展字段2',
    ext3               text                                   null comment '扩展字段3',
    extra_json         text                                   null comment '扩展json字段',
    created_at         datetime     default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at         datetime     default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by         varchar(128)                           null comment '更新人',
    dl_auto_created_at datetime     default CURRENT_TIMESTAMP not null comment '数据入湖时间',
    dl_auto_updated_at datetime     default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '数据更新时间',
    constraint UK_sub_trade_no
        unique (sub_trade_no)
)
    comment '兑换记录' charset = utf8;

create index Normal_trade_no
    on aquarius_item_redeem (trade_no);

create table if not exists aquarius_item_stock_log
(
    id                bigint auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    tenant_id         bigint                             not null comment '租户ID',
    code              varchar(32)                        not null comment '商品编码',
    sellable_quantity int      default 0                 null comment '可用数量',
    ext1              text                               null comment '扩展字段1',
    ext2              text                               null comment '扩展字段2',
    ext3              text                               null comment '扩展字段3',
    extra_json        text                               null comment '扩展json字段',
    created_at        datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at        datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by        varchar(128)                       null comment '更新人'
)
    comment '商品库存更改日志' charset = utf8;

create table if not exists aquarius_out_item
(
    id            bigint auto_increment comment '外部商品ID'
        constraint `PRIMARY`
        primary key,
    tenant_id     bigint                                not null comment '租户ID',
    supplier_id   varchar(64)                           not null comment '供应商id',
    supplier_name varchar(64)                           not null comment '供应商名称',
    name          text                                  not null comment '外部商品名称',
    code          varchar(32)                           not null comment '外部商品编码',
    description   text                                  null comment '外部商品描述',
    status        varchar(16) default 'UNRELATED'       not null comment '状态 未绑定:unrelated 已绑定:related 删除:deleted',
    ext1          text                                  null comment '扩展字段1',
    ext2          text                                  null comment '扩展字段2',
    ext3          text                                  null comment '扩展字段3',
    extra_json    text                                  null comment '扩展json字段',
    created_at    datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at    datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by    varchar(128)                          null comment '更新人',
    constraint UK_code_tenant_id
        unique (code, supplier_id, tenant_id)
)
    comment '供应商商品' charset = utf8;

create table if not exists mobil_item_index
(
    id           bigint unsigned auto_increment comment '编号'
        constraint `PRIMARY`
        primary key,
    item_id      bigint unsigned                           null comment '商品编号',
    item_code    varchar(32)                               null comment '商品编码',
    item_name    varchar(200)                              null comment '商品名称',
    min_point    int unsigned                              null comment '最小积分',
    max_point    int unsigned                              null comment '最大积分',
    price        decimal(8, 2)                             null comment '价格',
    bu_code      varchar(256)                              null comment '渠道',
    onsale_time  datetime                                  null comment '上架时间',
    status       varchar(16)     default 'OFF_SHELVES'     null comment '状态 TOBE_ONSALE:待上架 TOBE_OFFSALE:待下架 ONSALE:上架OFFSALE:下架',
    sales_volume bigint unsigned default 0                 null comment '销量',
    category_id  bigint                                    null comment '类目id',
    created_at   datetime        default CURRENT_TIMESTAMP null comment '创建时间',
    updated_at   datetime        default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '更新时间',
    constraint udx_item_id
        unique (item_id)
)
    comment '商品索引表';

create index idx_point_asc
    on mobil_item_index (min_point, sales_volume, onsale_time);

create index idx_point_desc
    on mobil_item_index (max_point, sales_volume, onsale_time);


