create table if not exists uc_system_config
(
    id         bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    `key`      varchar(255)            null comment 'key',
    value      varchar(255)            null comment 'value',
    `desc`     varchar(255)            null comment '描述',
    created_id varchar(30) default '0' null comment '创建人工号，0：系统',
    created_at datetime                not null comment '创建时间',
    updated_id varchar(30) default '0' null comment '修改人工号，0: 系统',
    updated_at datetime                null comment '修改时间',
    delete_yn  tinyint(1)  default 0   not null comment '删除标记，0:未删除，1：已删除'
)
    comment '系统配置表';

create table if not exists uc_table_config
(
    id         bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    name       varchar(256)            not null comment '报表名称',
    icon       varchar(256)            null comment '报表封面图标',
    link       varchar(256)            not null comment '链接',
    acl_key    varchar(256)            not null comment '权限点key',
    created_id varchar(30) default '0' null comment '创建人工号，0：系统',
    created_at datetime                not null comment '创建时间',
    updated_id varchar(30) default '0' null comment '修改人工号，0: 系统',
    updated_at datetime                null comment '修改时间',
    delete_yn  tinyint(1)  default 0   not null comment '删除标记，0:未删除，1：已删除'
)
    comment '报表配置表';

create table if not exists uc_user
(
    id            bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id     int(20)                   not null comment '租户ID',
    username      varchar(128)              not null comment '用户名',
    nickname      varchar(120)              null comment '昵称',
    avatar        varchar(255)              null comment '头像',
    mobile        varchar(64) charset utf8  null comment '手机号',
    email         varchar(128)              null comment '邮箱',
    password      varchar(255) charset utf8 null comment '密码',
    pwd_expire_at date                      null comment '密码过期时间',
    enabled       tinyint(1) default 1      not null comment '是否启用',
    locked        tinyint(1) default 0      not null comment '是否冻结',
    deleted       tinyint(1) default 0      not null comment '逻辑删除delete flag (0:not,1:yes)',
    channel       varchar(255)              null comment '注册渠道',
    channel_type  varchar(64)               null comment '渠道类型',
    source        varchar(255)              null comment '用户来源',
    source_type   varchar(64)               null comment '来源类型',
    tag           varchar(255)              null comment '标签',
    version       int                       null comment '版本',
    extra         varchar(2048)             null comment '扩展字段',
    updated_by    varchar(128)              null comment '更新人，操作日志',
    created_at    datetime                  not null comment '创建时间',
    updated_at    datetime                  null comment '更新时间',
    last_login_at datetime                  null comment '最后一次登录时间',
    constraint uni_email
        unique (email, tenant_id),
    constraint uni_mobile
        unique (mobile, tenant_id),
    constraint uni_username
        unique (username, tenant_id)
)
    comment '用户表';

create table if not exists uc_user_detail
(
    user_id bigint        not null comment '用户ID',
    info    varchar(2048) null comment '用户JSON信息',
    constraint `PRIMARY`
        primary key (user_id)
)
    comment '用户信息表';

create table if not exists uc_user_event_log
(
    id          bigint auto_increment
        constraint `PRIMARY`
        primary key,
    user_id     bigint        null,
    event_type  varchar(32)   null,
    event       varchar(512)  null,
    event_time  datetime      null,
    mac_address varchar(128)  null,
    ip          varchar(64)   null,
    extra       varchar(2048) null,
    created_at  datetime      null,
    updated_at  datetime      null comment '更新时间'
)
    comment '用户事件日志表';

create index idx_user_id_event_type
    on uc_user_event_log (user_id, event_type);

create table if not exists uc_user_third_account
(
    id           bigint auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    user_id      bigint        not null comment '用户ID',
    account_id   varchar(255)  not null comment '三方账户ID',
    account_name varchar(255)  null comment '第三方账户名',
    account_type varchar(255)  not null comment '第三方账户类型：QQ、WECHAT、WECHAT-MP、WEIBO',
    app_id       varchar(255)  not null comment '授权APPID',
    open_id      varchar(64)   null comment 'OPEN ID',
    extra        varchar(2048) null comment '扩展JSON字段',
    created_at   datetime      not null comment '创建时间',
    updated_at   datetime      null comment '更新时间'
)
    comment '第三方账户';

create function json_extract(json text, required_field varchar(255)) returns text
BEGIN
    DECLARE length0,length1,count0,point BIGINT DEFAULT 0;
    DECLARE current_key VARCHAR(100);
    SET json = REPLACE(REPLACE(REPLACE(json, CHAR(10), ''), CHAR(13), ''), CHAR(32), '');
    SET required_field = TRIM(required_field);
    SET length0 = LENGTH(required_field);
    SET length1 = LENGTH(REPLACE(required_field, '.', ''));
    SET count0 = length0 - length1;
    SET point = 0;
    SET required_field = CONCAT(TRIM(LEADING '$' FROM required_field), '.');
    WHILE point < count0
        DO
            SET json = TRIM(LEADING '{' FROM json);
            SET json = TRIM(TRAILING '}' FROM json);
            SET current_key = SUBSTRING_INDEX(SUBSTRING_INDEX(required_field, '.', point + 2), '.', -1);
            IF LOCATE(CONCAT('"', current_key, '":'), json) = 0 THEN
                RETURN NULL;
            ELSEIF point + 1 = count0 THEN
                SET json = SUBSTRING_INDEX(SUBSTRING_INDEX(json, CONCAT('"', current_key, '":'), -1), ',"', 1);
            ELSE
                SET json = SUBSTRING_INDEX(SUBSTRING_INDEX(json, CONCAT('"', current_key, '":'), -1), '},"', 1);
            END IF;
            SET json = TRIM(BOTH '"' FROM json);
            SET point = point + 1;
        END WHILE;
    RETURN json;
END;


