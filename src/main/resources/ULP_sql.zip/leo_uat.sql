create table if not exists leo_message
(
    id         bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    topic      varchar(64)  default ''                not null comment '消息topic',
    tag        varchar(64)                            null comment '消息tag',
    context    longtext                               not null comment '明细内容',
    msg_id     varchar(128) default ''                null comment '消息id',
    status     varchar(32)  default ''                not null comment 'DONE:执行成功，FAIL:处理失败',
    created_at datetime     default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at datetime     default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by varchar(128)                           null comment '操作人信息',
    constraint idx_msg_id
        unique (msg_id)
);

create table if not exists leo_privileges
(
    id          bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id   smallint                              not null comment '租户ID',
    name        varchar(64) default ''                not null comment '权益名称',
    type        varchar(16)                           not null comment '权益类型',
    series      varchar(16)                           not null comment '权益系列',
    `group`     varchar(16)                           null comment '权益分组',
    period varchar (16) not null comment '权益有效周期',
    value       bigint      default 0                 not null comment '权益值',
    description text                                  null comment '权益描述',
    code        varchar(64) default ''                not null comment '权益码',
    logo        text                                  null comment '权益缩略图url',
    status      varchar(16) default 'DRAFT'           not null comment 'DRAFT:草稿,PUBLISH:发布,FROZEN:冻结',
    start_at    datetime    default CURRENT_TIMESTAMP not null comment '权益开始时间',
    end_at      datetime                              null comment '权益结束时间',
    rule_code   varchar(64)                           null comment '积分规则码',
    ext1        varchar(16)                           null comment '账户类型',
    ext2        text                                  null comment '扩展字段2',
    ext3        text                                  null comment '扩展字段3',
    extra_json  text                                  null comment '扩展json字段',
    created_at  datetime    default CURRENT_TIMESTAMP not null comment '权益创建时间',
    updated_at  datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '权益更新时间',
    updated_by  varchar(128)                          null comment '更新人',
    constraint idx_uni_code
        unique (code)
);

create table if not exists leo_privileges_relation
(
    id             bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id      smallint                              not null comment '租户ID',
    out_id         varchar(32) default ''                not null comment '外部ID',
    privilege_code varchar(64) default ''                not null comment '权益码',
    biz_type       varchar(16) default 'LEVEL'           not null comment '业务类型   LEVEL:等级',
    seq            int(4)                                not null comment '序号',
    status         varchar(16) default 'ENABLE'          not null comment 'ENABLE:启用,DISABLE:禁用',
    ext1           text                                  null comment '扩展字段1',
    ext2           text                                  null comment '扩展字段2',
    ext3           text                                  null comment '扩展字段3',
    extra_json     text                                  null comment '扩展字段json',
    created_at     datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at     datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by     varchar(128)                          null comment '更新人'
);

create table if not exists leo_privileges_writeoff
(
    id             bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id      smallint                              not null comment '租户ID',
    owner_id       bigint                                not null comment '用户ID',
    out_id         varchar(32) default ''                not null comment '外部ID',
    privilege_code varchar(64)                           not null comment '权益码',
    series         varchar(16)                           not null comment '权益系列',
    biz_type       varchar(16)                           not null comment '业务类型',
    num            int(4)      default 1                 not null comment '权益使用数额',
    writeoff_at    datetime    default CURRENT_TIMESTAMP not null comment '核销时间',
    hash_code      varchar(32) default ''                not null comment '唯一hash码',
    ext1           text                                  null comment '扩展字段1',
    ext2           text                                  null comment '扩展字段2',
    ext3           text                                  null comment '扩展字段3',
    extra_json     text                                  null comment '扩展字段json',
    created_at     datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at     datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by     varchar(128)                          null comment '更新人',
    constraint idx_uni_hashcode
        unique (hash_code)
);

create index idx_uni_
    on leo_privileges_writeoff (privilege_code, series, owner_id, out_id, biz_type, tenant_id);

create table if not exists tb_gift_package
(
    id            bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    name          varchar(64)  not null comment '礼包名称',
    channel       varchar(64)  null comment '发放渠道',
    type          varchar(64)  null comment '礼包内容',
    point_rule_id bigint       null comment '积分规则编号',
    coupon_ids    text         null comment '优惠券编号',
    status        smallint     not null comment '状态 -1:草稿 1:已生效 0:已停用',
    `desc`        varchar(512) null comment '礼包描述',
    created_at    datetime     null comment '创建时间',
    updated_at    datetime     null comment '更新时间',
    delete_yn     tinyint      null comment '删除标识  0：未删除 1：已删除'
)
    comment '礼包管理表' charset = utf8;


