create table if not exists act_call_log
(
    id                  int(11) unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    process_instance_id varchar(63)         default ''   not null comment '流程实例id',
    execution_id        varchar(63)         default ''   not null comment '任务实例id, 如果是调用方是ExecutionListener, 则对应ExecutionId',
    element_name        varchar(255)        default ''   null comment '任务名称',
    service_type        tinyint(1) unsigned default 1    not null comment '1:Dubbo，2:Http',
    service_entry_point varchar(63)         default ''   not null comment '服务调用的切入地点(TaskListener, ExecutionListener, TaskService)',
    service_path        varchar(510)        default ''   not null comment '服务调用path',
    service_config      varchar(255)        default '{}' null comment '服务调用config配置json数据，zkAddress、version、timeout等',
    service_params      varchar(255)        default '{}' null comment '服务调用参数',
    service_error       varchar(510)        default ''   null comment '服务调用失败错误信息',
    service_error_stack text                             null comment '服务调用失败错误堆栈',
    start_time          datetime                         null comment '服务调用开始时间',
    end_time            datetime                         null comment '服务调用结束时间',
    status              tinyint(1)          default 0    null comment '-1：调用失败，1：调用成功',
    extra_json          varchar(1024)       default '{}' null comment '额外信息',
    created_at          datetime                         not null comment '创建时间',
    updated_at          datetime                         not null comment '修改时间'
)
    collate = utf8_bin;

create table if not exists act_evt_log
(
    LOG_NR_       bigint auto_increment
        constraint `PRIMARY`
        primary key,
    TYPE_         varchar(64)                               null,
    PROC_DEF_ID_  varchar(64)                               null,
    PROC_INST_ID_ varchar(64)                               null,
    EXECUTION_ID_ varchar(64)                               null,
    TASK_ID_      varchar(64)                               null,
    TIME_STAMP_   timestamp(3) default CURRENT_TIMESTAMP(3) not null on update CURRENT_TIMESTAMP(3),
    USER_ID_      varchar(255)                              null,
    DATA_         longblob                                  null,
    LOCK_OWNER_   varchar(255)                              null,
    LOCK_TIME_    timestamp(3)                              null,
    IS_PROCESSED_ tinyint      default 0                    null
)
    collate = utf8_bin;

create table if not exists act_ge_property
(
    NAME_  varchar(64) default '' not null,
    VALUE_ varchar(300)           null,
    REV_   int                    null,
    constraint `PRIMARY`
        primary key (NAME_)
)
    collate = utf8_bin;

create table if not exists act_hi_actinst
(
    ID_                varchar(64)             not null,
    PROC_DEF_ID_       varchar(64)             not null,
    PROC_INST_ID_      varchar(64)             not null,
    EXECUTION_ID_      varchar(64)             not null,
    ACT_ID_            varchar(255)            not null,
    TASK_ID_           varchar(64)             null,
    CALL_PROC_INST_ID_ varchar(64)             null,
    ACT_NAME_          varchar(255)            null,
    ACT_TYPE_          varchar(255)            not null,
    ASSIGNEE_          varchar(255)            null,
    START_TIME_        datetime(3)             not null,
    END_TIME_          datetime(3)             null,
    DURATION_          bigint                  null,
    DELETE_REASON_     varchar(4000)           null,
    TENANT_ID_         varchar(255) default '' null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_HI_ACT_INST_END
    on act_hi_actinst (END_TIME_);

create index ACT_IDX_HI_ACT_INST_EXEC
    on act_hi_actinst (EXECUTION_ID_, ACT_ID_);

create index ACT_IDX_HI_ACT_INST_PROCINST
    on act_hi_actinst (PROC_INST_ID_, ACT_ID_);

create index ACT_IDX_HI_ACT_INST_START
    on act_hi_actinst (START_TIME_);

create table if not exists act_hi_attachment
(
    ID_           varchar(64)   not null,
    REV_          int           null,
    USER_ID_      varchar(255)  null,
    NAME_         varchar(255)  null,
    DESCRIPTION_  varchar(4000) null,
    TYPE_         varchar(255)  null,
    TASK_ID_      varchar(64)   null,
    PROC_INST_ID_ varchar(64)   null,
    URL_          varchar(4000) null,
    CONTENT_ID_   varchar(64)   null,
    TIME_         datetime(3)   null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create table if not exists act_hi_comment
(
    ID_           varchar(64)   not null,
    TYPE_         varchar(255)  null,
    TIME_         datetime(3)   not null,
    USER_ID_      varchar(255)  null,
    TASK_ID_      varchar(64)   null,
    PROC_INST_ID_ varchar(64)   null,
    ACTION_       varchar(255)  null,
    MESSAGE_      varchar(4000) null,
    FULL_MSG_     longblob      null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create table if not exists act_hi_detail
(
    ID_           varchar(64)   not null,
    TYPE_         varchar(255)  not null,
    PROC_INST_ID_ varchar(64)   null,
    EXECUTION_ID_ varchar(64)   null,
    TASK_ID_      varchar(64)   null,
    ACT_INST_ID_  varchar(64)   null,
    NAME_         varchar(255)  not null,
    VAR_TYPE_     varchar(255)  null,
    REV_          int           null,
    TIME_         datetime(3)   not null,
    BYTEARRAY_ID_ varchar(64)   null,
    DOUBLE_       double        null,
    LONG_         bigint        null,
    TEXT_         varchar(4000) null,
    TEXT2_        varchar(4000) null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_HI_DETAIL_ACT_INST
    on act_hi_detail (ACT_INST_ID_);

create index ACT_IDX_HI_DETAIL_NAME
    on act_hi_detail (NAME_);

create index ACT_IDX_HI_DETAIL_PROC_INST
    on act_hi_detail (PROC_INST_ID_);

create index ACT_IDX_HI_DETAIL_TASK_ID
    on act_hi_detail (TASK_ID_);

create index ACT_IDX_HI_DETAIL_TIME
    on act_hi_detail (TIME_);

create table if not exists act_hi_identitylink
(
    ID_           varchar(64) default '' not null,
    GROUP_ID_     varchar(255)           null,
    TYPE_         varchar(255)           null,
    USER_ID_      varchar(255)           null,
    TASK_ID_      varchar(64)            null,
    PROC_INST_ID_ varchar(64)            null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_HI_IDENT_LNK_PROCINST
    on act_hi_identitylink (PROC_INST_ID_);

create index ACT_IDX_HI_IDENT_LNK_TASK
    on act_hi_identitylink (TASK_ID_);

create index ACT_IDX_HI_IDENT_LNK_USER
    on act_hi_identitylink (USER_ID_);

create table if not exists act_hi_procinst
(
    ID_                        varchar(64)             not null,
    PROC_INST_ID_              varchar(64)             not null,
    BUSINESS_KEY_              varchar(255)            null,
    PROC_DEF_ID_               varchar(64)             not null,
    START_TIME_                datetime(3)             not null,
    END_TIME_                  datetime(3)             null,
    DURATION_                  bigint                  null,
    START_USER_ID_             varchar(255)            null,
    START_ACT_ID_              varchar(255)            null,
    END_ACT_ID_                varchar(255)            null,
    SUPER_PROCESS_INSTANCE_ID_ varchar(64)             null,
    DELETE_REASON_             varchar(4000)           null,
    TENANT_ID_                 varchar(255) default '' null,
    NAME_                      varchar(255)            null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint PROC_INST_ID_
        unique (PROC_INST_ID_)
)
    collate = utf8_bin;

create index ACT_IDX_HI_PRO_INST_END
    on act_hi_procinst (END_TIME_);

create index ACT_IDX_HI_PRO_I_BUSKEY
    on act_hi_procinst (BUSINESS_KEY_);

create table if not exists act_hi_taskinst
(
    ID_             varchar(64)             not null,
    PROC_DEF_ID_    varchar(64)             null,
    TASK_DEF_KEY_   varchar(255)            null,
    PROC_INST_ID_   varchar(64)             null,
    EXECUTION_ID_   varchar(64)             null,
    NAME_           varchar(255)            null,
    PARENT_TASK_ID_ varchar(64)             null,
    DESCRIPTION_    varchar(4000)           null,
    OWNER_          varchar(255)            null,
    ASSIGNEE_       varchar(255)            null,
    START_TIME_     datetime(3)             not null,
    CLAIM_TIME_     datetime(3)             null,
    END_TIME_       datetime(3)             null,
    DURATION_       bigint                  null,
    DELETE_REASON_  varchar(4000)           null,
    PRIORITY_       int                     null,
    DUE_DATE_       datetime(3)             null,
    FORM_KEY_       varchar(255)            null,
    CATEGORY_       varchar(255)            null,
    TENANT_ID_      varchar(255) default '' null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_HI_TASK_INST_PROCINST
    on act_hi_taskinst (PROC_INST_ID_);

create table if not exists act_hi_varinst
(
    ID_                varchar(64)   not null,
    PROC_INST_ID_      varchar(64)   null,
    EXECUTION_ID_      varchar(64)   null,
    TASK_ID_           varchar(64)   null,
    NAME_              varchar(255)  not null,
    VAR_TYPE_          varchar(100)  null,
    REV_               int           null,
    BYTEARRAY_ID_      varchar(64)   null,
    DOUBLE_            double        null,
    LONG_              bigint        null,
    TEXT_              varchar(4000) null,
    TEXT2_             varchar(4000) null,
    CREATE_TIME_       datetime(3)   null,
    LAST_UPDATED_TIME_ datetime(3)   null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_HI_PROCVAR_NAME_TYPE
    on act_hi_varinst (NAME_, VAR_TYPE_);

create index ACT_IDX_HI_PROCVAR_PROC_INST
    on act_hi_varinst (PROC_INST_ID_);

create index ACT_IDX_HI_PROCVAR_TASK_ID
    on act_hi_varinst (TASK_ID_);

create table if not exists act_id_group
(
    ID_   varchar(64) default '' not null,
    REV_  int                    null,
    NAME_ varchar(255)           null,
    TYPE_ varchar(255)           null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create table if not exists act_id_info
(
    ID_        varchar(64) default '' not null,
    REV_       int                    null,
    USER_ID_   varchar(64)            null,
    TYPE_      varchar(64)            null,
    KEY_       varchar(255)           null,
    VALUE_     varchar(255)           null,
    PASSWORD_  longblob               null,
    PARENT_ID_ varchar(255)           null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create table if not exists act_id_user
(
    ID_         varchar(64) default '' not null,
    REV_        int                    null,
    FIRST_      varchar(255)           null,
    LAST_       varchar(255)           null,
    EMAIL_      varchar(255)           null,
    PWD_        varchar(255)           null,
    PICTURE_ID_ varchar(64)            null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create table if not exists act_id_membership
(
    USER_ID_  varchar(64) default '' not null,
    GROUP_ID_ varchar(64) default '' not null,
    constraint `PRIMARY`
        primary key (USER_ID_, GROUP_ID_),
    constraint ACT_FK_MEMB_GROUP
        foreign key (GROUP_ID_) references act_id_group (ID_),
    constraint ACT_FK_MEMB_USER
        foreign key (USER_ID_) references act_id_user (ID_)
)
    collate = utf8_bin;

create table if not exists act_re_deployment
(
    ID_             varchar(64)  default '' not null,
    NAME_           varchar(255)            null,
    CATEGORY_       varchar(255)            null,
    KEY_            varchar(255)            null,
    TENANT_ID_      varchar(255) default '' null,
    DEPLOY_TIME_    timestamp(3)            null,
    ENGINE_VERSION_ varchar(255)            null,
    constraint `PRIMARY`
        primary key (ID_)
)
    collate = utf8_bin;

create table if not exists act_ge_bytearray
(
    ID_            varchar(64) default '' not null,
    REV_           int                    null,
    NAME_          varchar(255)           null,
    DEPLOYMENT_ID_ varchar(64)            null,
    BYTES_         longblob               null,
    GENERATED_     tinyint                null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_BYTEARR_DEPL
        foreign key (DEPLOYMENT_ID_) references act_re_deployment (ID_)
)
    collate = utf8_bin;

create table if not exists act_re_model
(
    ID_                           varchar(64)             not null,
    REV_                          int                     null,
    NAME_                         varchar(255)            null,
    KEY_                          varchar(255)            null,
    CATEGORY_                     varchar(255)            null,
    CREATE_TIME_                  timestamp(3)            null,
    LAST_UPDATE_TIME_             timestamp(3)            null,
    VERSION_                      int                     null,
    META_INFO_                    varchar(4000)           null,
    DEPLOYMENT_ID_                varchar(64)             null,
    EDITOR_SOURCE_VALUE_ID_       varchar(64)             null,
    EDITOR_SOURCE_EXTRA_VALUE_ID_ varchar(64)             null,
    TENANT_ID_                    varchar(255) default '' null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_MODEL_DEPLOYMENT
        foreign key (DEPLOYMENT_ID_) references act_re_deployment (ID_),
    constraint ACT_FK_MODEL_SOURCE
        foreign key (EDITOR_SOURCE_VALUE_ID_) references act_ge_bytearray (ID_),
    constraint ACT_FK_MODEL_SOURCE_EXTRA
        foreign key (EDITOR_SOURCE_EXTRA_VALUE_ID_) references act_ge_bytearray (ID_)
)
    collate = utf8_bin;

create table if not exists act_re_procdef
(
    ID_                     varchar(64)             not null,
    REV_                    int                     null,
    CATEGORY_               varchar(255)            null,
    NAME_                   varchar(255)            null,
    KEY_                    varchar(255)            not null,
    VERSION_                int                     not null,
    DEPLOYMENT_ID_          varchar(64)             null,
    RESOURCE_NAME_          varchar(4000)           null,
    DGRM_RESOURCE_NAME_     varchar(4000)           null,
    DESCRIPTION_            varchar(4000)           null,
    HAS_START_FORM_KEY_     tinyint                 null,
    HAS_GRAPHICAL_NOTATION_ tinyint                 null,
    SUSPENSION_STATE_       int                     null,
    TENANT_ID_              varchar(255) default '' null,
    ENGINE_VERSION_         varchar(255)            null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_UNIQ_PROCDEF
        unique (KEY_, VERSION_, TENANT_ID_)
)
    collate = utf8_bin;

create table if not exists act_procdef_info
(
    ID_           varchar(64) not null,
    PROC_DEF_ID_  varchar(64) not null,
    REV_          int         null,
    INFO_JSON_ID_ varchar(64) null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_UNIQ_INFO_PROCDEF
        unique (PROC_DEF_ID_),
    constraint ACT_FK_INFO_JSON_BA
        foreign key (INFO_JSON_ID_) references act_ge_bytearray (ID_),
    constraint ACT_FK_INFO_PROCDEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_INFO_PROCDEF
    on act_procdef_info (PROC_DEF_ID_);

create table if not exists act_ru_execution
(
    ID_                   varchar(64)  default '' not null,
    REV_                  int                     null,
    PROC_INST_ID_         varchar(64)             null,
    BUSINESS_KEY_         varchar(255)            null,
    PARENT_ID_            varchar(64)             null,
    PROC_DEF_ID_          varchar(64)             null,
    SUPER_EXEC_           varchar(64)             null,
    ROOT_PROC_INST_ID_    varchar(64)             null,
    ACT_ID_               varchar(255)            null,
    IS_ACTIVE_            tinyint                 null,
    IS_CONCURRENT_        tinyint                 null,
    IS_SCOPE_             tinyint                 null,
    IS_EVENT_SCOPE_       tinyint                 null,
    IS_MI_ROOT_           tinyint                 null,
    SUSPENSION_STATE_     int                     null,
    CACHED_ENT_STATE_     int                     null,
    TENANT_ID_            varchar(255) default '' null,
    NAME_                 varchar(255)            null,
    START_TIME_           datetime(3)             null,
    START_USER_ID_        varchar(255)            null,
    LOCK_TIME_            timestamp(3)            null,
    IS_COUNT_ENABLED_     tinyint                 null,
    EVT_SUBSCR_COUNT_     int                     null,
    TASK_COUNT_           int                     null,
    JOB_COUNT_            int                     null,
    TIMER_JOB_COUNT_      int                     null,
    SUSP_JOB_COUNT_       int                     null,
    DEADLETTER_JOB_COUNT_ int                     null,
    VAR_COUNT_            int                     null,
    ID_LINK_COUNT_        int                     null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_EXE_PARENT
        foreign key (PARENT_ID_) references act_ru_execution (ID_)
            on delete cascade,
    constraint ACT_FK_EXE_PROCDEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_),
    constraint ACT_FK_EXE_PROCINST
        foreign key (PROC_INST_ID_) references act_ru_execution (ID_)
            on update cascade on delete cascade,
    constraint ACT_FK_EXE_SUPER
        foreign key (SUPER_EXEC_) references act_ru_execution (ID_)
            on delete cascade
)
    collate = utf8_bin;

create table if not exists act_ru_deadletter_job
(
    ID_                  varchar(64)             not null,
    REV_                 int                     null,
    TYPE_                varchar(255)            not null,
    EXCLUSIVE_           tinyint(1)              null,
    EXECUTION_ID_        varchar(64)             null,
    PROCESS_INSTANCE_ID_ varchar(64)             null,
    PROC_DEF_ID_         varchar(64)             null,
    EXCEPTION_STACK_ID_  varchar(64)             null,
    EXCEPTION_MSG_       varchar(4000)           null,
    DUEDATE_             timestamp(3)            null,
    REPEAT_              varchar(255)            null,
    HANDLER_TYPE_        varchar(255)            null,
    HANDLER_CFG_         varchar(4000)           null,
    TENANT_ID_           varchar(255) default '' null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_DEADLETTER_JOB_EXCEPTION
        foreign key (EXCEPTION_STACK_ID_) references act_ge_bytearray (ID_),
    constraint ACT_FK_DEADLETTER_JOB_EXECUTION
        foreign key (EXECUTION_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_DEADLETTER_JOB_PROCESS_INSTANCE
        foreign key (PROCESS_INSTANCE_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_DEADLETTER_JOB_PROC_DEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_)
)
    collate = utf8_bin;

create table if not exists act_ru_event_subscr
(
    ID_            varchar(64)                               not null,
    REV_           int                                       null,
    EVENT_TYPE_    varchar(255)                              not null,
    EVENT_NAME_    varchar(255)                              null,
    EXECUTION_ID_  varchar(64)                               null,
    PROC_INST_ID_  varchar(64)                               null,
    ACTIVITY_ID_   varchar(64)                               null,
    CONFIGURATION_ varchar(255)                              null,
    CREATED_       timestamp(3) default CURRENT_TIMESTAMP(3) not null,
    PROC_DEF_ID_   varchar(64)                               null,
    TENANT_ID_     varchar(255) default ''                   null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_EVENT_EXEC
        foreign key (EXECUTION_ID_) references act_ru_execution (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_EVENT_SUBSCR_CONFIG_
    on act_ru_event_subscr (CONFIGURATION_);

create index ACT_IDC_EXEC_ROOT
    on act_ru_execution (ROOT_PROC_INST_ID_);

create index ACT_IDX_EXEC_BUSKEY
    on act_ru_execution (BUSINESS_KEY_);

create table if not exists act_ru_job
(
    ID_                  varchar(64)             not null,
    REV_                 int                     null,
    TYPE_                varchar(255)            not null,
    LOCK_EXP_TIME_       timestamp(3)            null,
    LOCK_OWNER_          varchar(255)            null,
    EXCLUSIVE_           tinyint(1)              null,
    EXECUTION_ID_        varchar(64)             null,
    PROCESS_INSTANCE_ID_ varchar(64)             null,
    PROC_DEF_ID_         varchar(64)             null,
    RETRIES_             int                     null,
    EXCEPTION_STACK_ID_  varchar(64)             null,
    EXCEPTION_MSG_       varchar(4000)           null,
    DUEDATE_             timestamp(3)            null,
    REPEAT_              varchar(255)            null,
    HANDLER_TYPE_        varchar(255)            null,
    HANDLER_CFG_         varchar(4000)           null,
    TENANT_ID_           varchar(255) default '' null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_JOB_EXCEPTION
        foreign key (EXCEPTION_STACK_ID_) references act_ge_bytearray (ID_),
    constraint ACT_FK_JOB_EXECUTION
        foreign key (EXECUTION_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_JOB_PROCESS_INSTANCE
        foreign key (PROCESS_INSTANCE_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_JOB_PROC_DEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_)
)
    collate = utf8_bin;

create table if not exists act_ru_suspended_job
(
    ID_                  varchar(64)             not null,
    REV_                 int                     null,
    TYPE_                varchar(255)            not null,
    EXCLUSIVE_           tinyint(1)              null,
    EXECUTION_ID_        varchar(64)             null,
    PROCESS_INSTANCE_ID_ varchar(64)             null,
    PROC_DEF_ID_         varchar(64)             null,
    RETRIES_             int                     null,
    EXCEPTION_STACK_ID_  varchar(64)             null,
    EXCEPTION_MSG_       varchar(4000)           null,
    DUEDATE_             timestamp(3)            null,
    REPEAT_              varchar(255)            null,
    HANDLER_TYPE_        varchar(255)            null,
    HANDLER_CFG_         varchar(4000)           null,
    TENANT_ID_           varchar(255) default '' null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_SUSPENDED_JOB_EXCEPTION
        foreign key (EXCEPTION_STACK_ID_) references act_ge_bytearray (ID_),
    constraint ACT_FK_SUSPENDED_JOB_EXECUTION
        foreign key (EXECUTION_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_SUSPENDED_JOB_PROCESS_INSTANCE
        foreign key (PROCESS_INSTANCE_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_SUSPENDED_JOB_PROC_DEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_)
)
    collate = utf8_bin;

create table if not exists act_ru_task
(
    ID_               varchar(64)  default '' not null,
    REV_              int                     null,
    EXECUTION_ID_     varchar(64)             null,
    PROC_INST_ID_     varchar(64)             null,
    PROC_DEF_ID_      varchar(64)             null,
    NAME_             varchar(255)            null,
    PARENT_TASK_ID_   varchar(64)             null,
    DESCRIPTION_      varchar(4000)           null,
    TASK_DEF_KEY_     varchar(255)            null,
    OWNER_            varchar(255)            null,
    ASSIGNEE_         varchar(255)            null,
    DELEGATION_       varchar(64)             null,
    PRIORITY_         int                     null,
    CREATE_TIME_      timestamp(3)            null,
    DUE_DATE_         datetime(3)             null,
    CATEGORY_         varchar(255)            null,
    SUSPENSION_STATE_ int                     null,
    TENANT_ID_        varchar(255) default '' null,
    FORM_KEY_         varchar(255)            null,
    CLAIM_TIME_       datetime(3)             null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_TASK_EXE
        foreign key (EXECUTION_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_TASK_PROCDEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_),
    constraint ACT_FK_TASK_PROCINST
        foreign key (PROC_INST_ID_) references act_ru_execution (ID_)
)
    collate = utf8_bin;

create table if not exists act_ru_identitylink
(
    ID_           varchar(64) default '' not null,
    REV_          int                    null,
    GROUP_ID_     varchar(255)           null,
    TYPE_         varchar(255)           null,
    USER_ID_      varchar(255)           null,
    TASK_ID_      varchar(64)            null,
    PROC_INST_ID_ varchar(64)            null,
    PROC_DEF_ID_  varchar(64)            null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_ATHRZ_PROCEDEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_),
    constraint ACT_FK_IDL_PROCINST
        foreign key (PROC_INST_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_TSKASS_TASK
        foreign key (TASK_ID_) references act_ru_task (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_ATHRZ_PROCEDEF
    on act_ru_identitylink (PROC_DEF_ID_);

create index ACT_IDX_IDENT_LNK_GROUP
    on act_ru_identitylink (GROUP_ID_);

create index ACT_IDX_IDENT_LNK_USER
    on act_ru_identitylink (USER_ID_);

create index ACT_IDX_TASK_CREATE
    on act_ru_task (CREATE_TIME_);

create table if not exists act_ru_timer_job
(
    ID_                  varchar(64)             not null,
    REV_                 int                     null,
    TYPE_                varchar(255)            not null,
    LOCK_EXP_TIME_       timestamp(3)            null,
    LOCK_OWNER_          varchar(255)            null,
    EXCLUSIVE_           tinyint(1)              null,
    EXECUTION_ID_        varchar(64)             null,
    PROCESS_INSTANCE_ID_ varchar(64)             null,
    PROC_DEF_ID_         varchar(64)             null,
    RETRIES_             int                     null,
    EXCEPTION_STACK_ID_  varchar(64)             null,
    EXCEPTION_MSG_       varchar(4000)           null,
    DUEDATE_             timestamp(3)            null,
    REPEAT_              varchar(255)            null,
    HANDLER_TYPE_        varchar(255)            null,
    HANDLER_CFG_         varchar(4000)           null,
    TENANT_ID_           varchar(255) default '' null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_TIMER_JOB_EXCEPTION
        foreign key (EXCEPTION_STACK_ID_) references act_ge_bytearray (ID_),
    constraint ACT_FK_TIMER_JOB_EXECUTION
        foreign key (EXECUTION_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_TIMER_JOB_PROCESS_INSTANCE
        foreign key (PROCESS_INSTANCE_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_TIMER_JOB_PROC_DEF
        foreign key (PROC_DEF_ID_) references act_re_procdef (ID_)
)
    collate = utf8_bin;

create table if not exists act_ru_variable
(
    ID_           varchar(64)   not null,
    REV_          int           null,
    TYPE_         varchar(255)  not null,
    NAME_         varchar(255)  not null,
    EXECUTION_ID_ varchar(64)   null,
    PROC_INST_ID_ varchar(64)   null,
    TASK_ID_      varchar(64)   null,
    BYTEARRAY_ID_ varchar(64)   null,
    DOUBLE_       double        null,
    LONG_         bigint        null,
    TEXT_         varchar(4000) null,
    TEXT2_        varchar(4000) null,
    constraint `PRIMARY`
        primary key (ID_),
    constraint ACT_FK_VAR_BYTEARRAY
        foreign key (BYTEARRAY_ID_) references act_ge_bytearray (ID_),
    constraint ACT_FK_VAR_EXE
        foreign key (EXECUTION_ID_) references act_ru_execution (ID_),
    constraint ACT_FK_VAR_PROCINST
        foreign key (PROC_INST_ID_) references act_ru_execution (ID_)
)
    collate = utf8_bin;

create index ACT_IDX_VARIABLE_TASK_ID
    on act_ru_variable (TASK_ID_);

create table if not exists aries_addresses
(
    id           bigint       not null,
    pid          bigint       null comment '父级ID',
    name         varchar(50)  null comment '名称',
    level        int          null comment '级别',
    has_children tinyint(1)   not null comment '是否有下一级',
    pinyin       varchar(100) null comment '拼音',
    english_name varchar(100) null comment '英文名',
    unicode_code varchar(200) null comment 'ASCII码',
    order_no     varchar(32)  null comment '排序号',
    lon          double       null comment '精度',
    lat          double       null comment '纬度',
    constraint `PRIMARY`
        primary key (id)
)
    charset = utf8;

create index idx_addresses_pid
    on aries_addresses (pid);

create table if not exists aries_batch_task
(
    id           bigint auto_increment
        constraint `PRIMARY`
        primary key,
    task_type    varchar(64)                           not null comment '任务类型',
    file_name    varchar(256)                          not null comment '文件名称',
    flow_id      varchar(64) default ''                null comment '审批节点',
    audit_status varchar(32) default ''                null comment '审批状态 WAITING-待审SUCCESS-审核成功，FAILED-审核不通过',
    file_url     varchar(512)                          null comment '文件地址',
    remark       varchar(1024)                         null comment '调整原因说明',
    data         text                                  null comment '导入数据JSON',
    result       text                                  null comment '导入结果JSON',
    auditd_at    datetime                              null comment '审批时间',
    created_by   varchar(128)                          null comment '更新人',
    created_at   datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at   datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by   varchar(128)                          null comment '更新人'
)
    charset = utf8;

create table if not exists aries_channels
(
    id           smallint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant       varchar(32)  null comment '租户',
    name         varchar(32)  not null comment '渠道名称',
    description  varchar(256) null comment '渠道描述',
    point_budget bigint       not null comment '积分预算',
    used_budget  bigint       not null comment '已使用的积分预算',
    rest_budget  bigint       not null comment '剩余的积分预算',
    created_at   datetime     not null comment '创建时间',
    updated_at   datetime     not null comment '更新时间',
    updated_by   varchar(128) null comment '操作人信息',
    constraint idx_ac_tenant_name
        unique (tenant, name)
)
    comment '会员渠道' collate = utf8mb4_unicode_ci;

create table if not exists aries_compensate_message
(
    id            bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    type          varchar(32)       not null comment 'INSIDE:内部处理消息, OUTSIDE:外部处理消息',
    topic         varchar(64)       null comment '消息topic',
    tag           varchar(64)       null comment '消息tag',
    biz_no        varchar(64)       null comment '外部单据',
    biz_type      varchar(64)       null comment '外部单据类型',
    entity_id     varchar(64)       null comment '实体id',
    context       longtext          null comment '明细内容',
    msg_id        varchar(128)      null comment '消息id',
    status        varchar(32)       null comment 'DONE:执行成功，FAIL:处理失败, INIT:初始化, PROCESSING:处理中',
    fail_count    tinyint default 0 null comment '失败次数',
    priority      tinyint           null comment '优先级',
    failed_reason text              null comment '上次失败原因',
    created_at    datetime          not null comment '创建时间',
    updated_at    datetime          not null comment '更新时间',
    constraint idx_acm_biz_no_and_type
        unique (biz_no, biz_type),
    constraint idx_acm_msg_id
        unique (msg_id)
)
    comment '会员消息记录表';

create table if not exists aries_coupon_reissue_log
(
    id                          bigint unsigned auto_increment comment '编号'
        constraint `PRIMARY`
        primary key,
    user_id                     bigint unsigned null comment '用户编号',
    user_name                   varchar(64)     null comment '用户名',
    name                        varchar(64)     null comment '券名称',
    use_channel                 varchar(32)     null comment '使用渠道',
    shop_id                     bigint unsigned null comment '店铺id',
    activity_id                 bigint unsigned null comment '活动id',
    outer_code                  varchar(32)     null comment '关联外部编号',
    coupon_id                   bigint unsigned null comment '券id',
    activity_preferential_type  tinyint         null comment '优惠方式，1.满减；2.折扣；3.扣减',
    activity_discount_value     bigint          null comment '面额或者折扣，最小单位',
    activity_discount_condition bigint          null comment '满足金额阀值，最小单位',
    coupon_desc                 varchar(200)    null comment '优惠券描述',
    start_at                    datetime        null comment '生效时间',
    expired_at                  datetime        null comment '结束时间',
    flow_id                     varchar(64)     null comment '审批流程实例id',
    audit_status                varchar(10)     null comment '审批状态',
    reason                      varchar(255)    null comment '申请原因',
    extra_json                  varchar(255)    null comment '额外信息',
    created_at                  datetime        null comment '创建时间',
    created_by                  bigint unsigned null comment '创建人',
    updated_at                  datetime        null comment '更新时间',
    updated_by                  bigint unsigned null comment '更新人',
    constraint idx_flow
        unique (flow_id)
)
    comment '优惠券补发';

create table if not exists aries_equities
(
    id          bigint auto_increment
        constraint `PRIMARY`
        primary key,
    created_at  datetime           not null comment '创建时间',
    description varchar(256)       null comment '渠道描述',
    flag        smallint default 0 not null comment '系统标识 0:非系统配置 1:系统配置',
    `group`     int                null comment '权益分组',
    logo        varchar(512)       null comment 'LOGO图片',
    name        varchar(32)        not null comment '权益名称',
    rate_up     int                null comment '追加的积分倍率(单位:万分之一)',
    status      smallint           not null comment '状态 0:未生效, 1:已生效',
    type        smallint           not null comment '1:基础权益  2:定制权益',
    updated_at  datetime           not null comment '更新时间',
    updated_by  varchar(128)       null comment '操作人信息'
)
    collate = utf8mb4_unicode_ci;

create table if not exists aries_equity_groups
(
    id          bigint auto_increment
        constraint `PRIMARY`
        primary key,
    created_at  datetime     not null comment '创建时间',
    description varchar(256) null comment '描述',
    logo        varchar(512) null comment '分组Logo',
    name        varchar(32)  not null comment '分组名称',
    updated_at  datetime     not null comment '更新时间',
    updated_by  varchar(128) null comment '操作人信息'
)
    collate = utf8mb4_unicode_ci;

create table if not exists aries_equity_rule_budget
(
    id               bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant           varchar(32) not null comment '租户',
    member_id        varchar(64) not null comment '会员id',
    equity_rule_id   bigint      not null comment '权益规则id',
    equity_rule_code varchar(64) null comment '权益规则码',
    meta_key         varchar(64) null comment '预算关联的 metakey',
    quota_meta       smallint    null comment '配额类型',
    total            bigint      null comment '预算总额',
    used             bigint      null comment '已使用',
    period_type      varchar(64) null comment '预算周期',
    start_at         datetime    null comment '预算开始时间',
    effective_days   smallint    null comment '预算有效期',
    created_at       datetime    not null comment '创建时间',
    updated_at       datetime    not null comment '更新时间'
)
    comment '权益规则预算计算' collate = utf8mb4_unicode_ci;

create table if not exists aries_equity_rules
(
    id                 bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant             varchar(32)  null comment '租户',
    name               varchar(64)  not null comment '规则名称',
    description        varchar(128) null comment '权益规则描述',
    image_url          text         null comment '权益图标',
    code               varchar(64)  null comment '权益规则码',
    type               varchar(64)  not null comment '业务类型',
    channel            varchar(64)  not null comment '渠道',
    status             varchar(32)  not null comment '状态',
    start_at           datetime     null comment '规则开始时间',
    expired_at         datetime     null comment '规则结束时间',
    is_qualification   varchar(32)  null comment '是否存在领用或者发放的权益(true or false)',
    condition_json     text         null comment '条件参数',
    action_json        text         null comment '动作参数(结果集)',
    qualification_json text         null comment '配额参数(存在发放或者领用行为)',
    extra_json         text         null comment '扩展字段, json表示',
    source             varchar(64)  null comment '来源',
    source_type        varchar(64)  null comment '来源类型',
    updated_by         varchar(64)  null comment '操作人员',
    created_at         datetime     not null comment '创建时间',
    updated_at         datetime     not null comment '更新时间',
    constraint idx_aer_tenan_coe
        unique (tenant, code),
    constraint idx_aer_tenan_name
        unique (tenant, name)
)
    comment '权益规则' collate = utf8mb4_unicode_ci;

create table if not exists aries_equity_snapshot_log
(
    id              bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant          varchar(32) null comment '租户id',
    biz_id          varchar(64) null comment '业务id',
    biz_type        varchar(64) null comment '业务类型',
    biz_source      varchar(64) null comment '业务类型',
    biz_source_type varchar(64) null comment '业务类型',
    member_id       varchar(64) null comment '会员id',
    channel         varchar(64) null comment '业务类型',
    stage           varchar(64) null comment '阶段(1.领用或者发放,2.使用或者核销)',
    result_json     text        null comment '动作结果',
    extra_json      text        null comment '扩展字段, json表示',
    created_at      datetime    not null comment '创建时间',
    updated_at      datetime    not null comment '更新时间'
)
    comment '权益快照日志' collate = utf8mb4_unicode_ci;

create table if not exists aries_exchange_info_log
(
    member_id   bigint               not null comment '用户ID',
    exchange_id bigint               not null comment '兑换单号',
    type        smallint             not null comment '变动类型，1:增加 2:扣减',
    sku_name    varchar(256)         not null comment '兑换商品名称',
    use_point   bigint(10)           not null comment '兑换使用积分',
    created_at  datetime             not null comment '创建时间',
    updated_at  datetime             null comment '修改时间',
    delete_yn   tinyint(1) default 0 not null comment '删除标记，0:未删除，1：已删除',
    status      int(10)              not null,
    id          bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key
)
    comment '会员兑换信息表';

create index idx_ap_updated_at
    on aries_exchange_info_log (updated_at);

create table if not exists aries_exchange_rules
(
    id                 bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    store_id           varchar(32)  null comment '店铺id',
    store_type         tinyint      null comment '店铺类型',
    exchange_ratio     bigint       not null comment '积分兑换系数（万分之一）',
    exchange_unit      bigint       not null comment '积分固定兑换单位',
    min_exchange_value bigint       not null comment '积分最小起兑值',
    max_exchange_value bigint       not null comment '积分最大起兑值',
    is_default         tinyint      not null comment '是否默认 0:否  1:是',
    created_at         datetime     not null comment '创建时间',
    updated_at         datetime     not null comment '更新时间',
    updated_by         varchar(128) null comment '操作人信息'
)
    comment '会员积分兑换规则' collate = utf8mb4_unicode_ci;

create table if not exists aries_froms
(
    id          smallint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id   smallint     not null comment '租户id',
    name        varchar(32)  not null comment '来源名称',
    description varchar(256) null comment '来源描述',
    created_at  datetime     not null comment '创建时间',
    updated_at  datetime     not null comment '更新时间',
    updated_by  varchar(128) null comment '操作人信息',
    constraint idx_af_name
        unique (tenant_id, name)
)
    comment '会员注册渠道';

create table if not exists aries_frozen_logs
(
    id            bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    identity      varchar(32)  not null comment '会员唯一标识 id/手机号/卡号',
    type          tinyint      not null comment '类型 -1-冻结, 1-解冻',
    status        tinyint      not null comment '操作状态 -1-操作失败, 1-操作成功',
    adjust_reason varchar(128) null comment '调整原因',
    fail_reason   varchar(128) null comment '任务失败原因',
    task_id       bigint       null comment '批处理任务id',
    ext1          varchar(32)  null comment '预留字段1',
    ext2          varchar(32)  null comment '预留字段2',
    ext3          varchar(32)  null comment '预留字段3',
    extra_json    text         null comment '额外json字段',
    created_at    datetime     not null comment '创建时间',
    updated_at    datetime     not null comment '更新时间',
    updated_by    varchar(128) null comment '操作人信息'
)
    comment '会员冻结记录';

create index idx_afl_created_at
    on aries_frozen_logs (created_at);

create index idx_afl_task_id
    on aries_frozen_logs (task_id);

create table if not exists aries_import_task
(
    id             bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    type           varchar(32)  null comment '任务类型 FROZEN:冻结任务',
    total_number   bigint       null comment '总数量',
    success_number bigint       null comment '成功数量',
    fail_number    bigint       null comment '失败数量',
    file_name      varchar(256) not null comment '上传文件名',
    file_path      varchar(256) not null comment '上传路径',
    reason         varchar(128) not null comment '任务创建原因',
    status         tinyint      not null comment '任务状态 -1-处理失败，0-未处理，1-处理中，2-处理完成',
    ext1           varchar(32)  null comment '预留字段1',
    ext2           varchar(32)  null comment '预留字段2',
    ext3           varchar(32)  null comment '预留字段3',
    extra_json     text         null comment '额外json字段',
    created_at     datetime     not null comment '创建时间',
    updated_at     datetime     not null comment '更新时间',
    updated_by     varchar(128) null comment '操作人信息'
)
    comment '导入文件任务';

create index idx_ait_created_at
    on aries_import_task (created_at);

create index idx_ait_type
    on aries_import_task (type);

create table if not exists aries_invitation_info
(
    id                  bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    invite_member_id    bigint             not null comment '邀请人会员编号',
    be_invite_member_id bigint             not null comment '被邀请人会员编号',
    activity_rule_code  varchar(256)       null comment '活动规则码',
    award_point         bigint   default 0 null comment '奖励积分',
    status              smallint default 1 not null comment '状态',
    remark              varchar(2048)      null comment '备注原因',
    create_at           datetime           null comment '创建时间',
    update_at           datetime           null comment '更新时间',
    delete_yn           tinyint            null comment '删除标识  0：未删除 1：已删除'
)
    comment '会员邀请记录' collate = utf8mb4_unicode_ci;

create table if not exists aries_marketing_scope
(
    id          bigint auto_increment
        constraint `PRIMARY`
        primary key,
    created_at  datetime     not null comment '创建时间',
    entity_code varchar(256) null comment '目标代码',
    entity_id   varchar(256) null comment '目标id',
    entity_type varchar(64)  not null comment '目标类型',
    scope_id    bigint       not null comment '范围id',
    updated_at  datetime     not null comment '更新时间',
    updated_by  varchar(128) null comment '操作人信息'
)
    collate = utf8mb4_unicode_ci;

create table if not exists aries_marketing_scope_def
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    scope_name        varchar(64)  not null comment '范围名称',
    scope_description varchar(256) null comment '范围描述',
    status            varchar(16)  not null comment '状态',
    creator           varchar(64)  null comment '创建者',
    file_path         varchar(256) null comment '文件路径',
    fail_path         varchar(256) null comment '失败路径',
    task_status       varchar(64)  null comment '任务状态',
    success_number    bigint       null comment '成功数量',
    fail_number       bigint       null comment '失败数量',
    created_at        datetime     not null comment '创建时间',
    updated_at        datetime     not null comment '更新时间',
    updated_by        varchar(128) null comment '操作人信息',
    constraint idx_amsd_scope_name
        unique (scope_name)
)
    collate = utf8mb4_unicode_ci;

create table if not exists aries_marketing_scopes
(
    id          bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    scope_id    bigint       not null comment '范围名称',
    entity_id   varchar(32)  null comment '目标id',
    entity_code varchar(128) null comment '目标代码',
    entity_type varchar(32)  not null comment '目标类型',
    created_at  datetime     not null comment '创建时间',
    updated_at  datetime     not null comment '更新时间',
    updated_by  varchar(128) null comment '操作人信息',
    constraint idx_ams_scope_id_and_entity_id_and_entity_type
        unique (scope_id, entity_id, entity_type)
)
    collate = utf8mb4_unicode_ci;

create table if not exists aries_member_car_data
(
    id             bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    member_id      bigint unsigned not null comment '会员编号',
    channel        varchar(255)    null comment '渠道标识',
    car_brand      varchar(255)    null comment '车辆品牌',
    car_km         varchar(255)    null comment '里程',
    car_type       varchar(255)    null comment '车辆类型',
    car_year       varchar(255)    null comment '年份',
    car_vehicle_id varchar(255)    null comment '车辆类型code',
    car_vehicle    varchar(255)    null comment '车辆类型',
    cc             varchar(255)    null comment '车辆排量',
    created_at     datetime        null comment '创建时间',
    updated_at     datetime        null comment '更新时间',
    delete_yn      tinyint         null comment '删除标识  0：未删除 1：已删除'
)
    charset = utf8;

create table if not exists aries_oem_gift_record
(
    id            bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    member_id     bigint        not null comment '会员编号',
    type          tinyint       null comment '1:新会员 2：老会员',
    activity_code varchar(32)   null comment '活动编码',
    mobile_md5    varchar(64)   not null comment '手机号md5',
    gift_name     varchar(256)  null comment '礼品名称',
    remark        varchar(2048) null comment '备注原因',
    created_at    datetime      null comment '领取时间',
    constraint idx_mobile_md5
        unique (mobile_md5, activity_code)
)
    comment 'OEM礼品领取记录表' collate = utf8mb4_unicode_ci;

create index idx_activity_code
    on aries_oem_gift_record (activity_code);

create table if not exists aries_order_info_log
(
    id                bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    member_id         bigint(100)                             not null comment '用户ID',
    order_id          varchar(50)                             not null comment '订单编号',
    order_status      smallint                                null comment '订单状态 订单状态0:未支付 1:待支付 2:待发货 -1:已关闭',
    order_channel     smallint                                null comment '订单渠道 订单渠道 1:微信商城 2:天猫 3:京东',
    order_type        smallint                                null comment '订单类型',
    sku_name          varchar(128) collate utf8mb4_unicode_ci not null comment '商品名称',
    sku_type          smallint                                not null comment '商品类型 1:乘用车润滑油 2:商用车润滑油3:摩托车润滑油4:机油滤清器5:刹车油',
    quantity          bigint(10)                              not null comment '商品数量',
    pay_money         bigint(10)                              not null comment '支付金额',
    discounts_money   bigint(10)                              null comment '优惠金额',
    payment           smallint                                not null comment '支付方式',
    pay_time          datetime                                null comment '支付时间',
    consingee_name    varchar(64) collate utf8mb4_unicode_ci  null comment '收货人',
    freight           bigint(10)                              null comment '运费',
    consingee_address varchar(512) collate utf8mb4_unicode_ci null comment '收货地址',
    invoice_status    smallint                                null comment '发票状态',
    created_at        datetime                                not null comment '创建时间',
    updated_at        datetime                                null comment '修改时间',
    delete_yn         tinyint(1) default 0                    not null comment '删除标记，0:未删除，1：已删除',
    constraint idx_ap_member_order_id
        unique (member_id, order_id)
)
    comment '会员订单信息表';

create index idx_ap_updated_at
    on aries_order_info_log (updated_at);

create table if not exists aries_point_info_log
(
    member_id    bigint               not null comment '用户ID',
    type         smallint             not null comment '变动类型，1:增加 2:扣减',
    change_count bigint(10)           not null comment '变动积分数值',
    change_info  varchar(256)         not null comment '积分变动备注',
    created_at   datetime             not null comment '创建时间',
    updated_at   datetime             null comment '修改时间',
    delete_yn    tinyint(1) default 0 not null comment '删除标记，0:未删除，1：已删除',
    id           bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key
)
    comment '会员积分信息表';

create index idx_ap_updated_at
    on aries_point_info_log (updated_at);

create table if not exists aries_point_manual_adjust_log
(
    id            bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id     bigint       not null comment '会员ID',
    point         bigint       not null comment '积分',
    type          smallint     not null comment '1:加积分 2:减积分',
    root_id       bigint       null comment '关联积分明细id',
    root_type_id  varchar(32)  null comment '积分增加关联规则的id',
    status        varchar(32)  null comment 'SUCCESS -操作成功,FAIL - 操作失败',
    adjust_reason varchar(256) null comment '任务调整理由',
    fail_reason   varchar(128) null comment '任务失败原因',
    operator      varchar(32)  null comment '操作账户',
    `from`        varchar(32)  null comment '归属渠道',
    from_type     smallint     null comment '归属渠道类型',
    task_id       varchar(32)  null comment '批处理任务id',
    ext1          varchar(64)  null comment '预留字段1',
    ext2          varchar(64)  null comment '预留字段2',
    ext3          varchar(64)  null comment '预留字段3',
    created_at    datetime     not null comment '创建时间',
    updated_at    datetime     not null comment '更新时间'
)
    comment '积分人工调整记录' collate = utf8mb4_unicode_ci;

create index idx_afl_created_at
    on aries_point_manual_adjust_log (member_id);

create index idx_afl_task_id
    on aries_point_manual_adjust_log (task_id);

create table if not exists aries_potential_batchs
(
    id          bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    name        varchar(64)   not null comment '批次名称',
    description varchar(1024) null comment '批次备注',
    total       bigint        not null comment '批次人数 初始化0',
    status      tinyint       not null comment '批次状态 1:有效 -1:无效',
    ext1        varchar(256)  null comment '扩展字段1',
    ext2        varchar(256)  null comment '扩展字段2',
    ext3        varchar(256)  null comment '扩展字段3',
    extra_json  varchar(512)  null comment '扩展信息JSON格式',
    created_at  datetime      not null comment '创建时间',
    updated_at  datetime      not null comment '更新时间',
    updated_by  varchar(64)   null comment '操作人'
)
    comment '潜客批次表';

create table if not exists aries_potential_import_tasks
(
    id            bigint unsigned auto_increment comment '自增主键'
        constraint `PRIMARY`
        primary key,
    batch_id      bigint        null,
    business_type tinyint       not null comment '任务类型 1:潜客导入 2:导入会员打标 3:导入潜客打标',
    tags          varchar(256)  null comment '标签ids',
    file_name     varchar(64)   not null comment '文件名称',
    file_url      varchar(256)  not null comment '导入文件url',
    total_count   bigint        null comment '总记录数',
    success_count bigint        null comment '成功记录数',
    fail_count    bigint        null comment '失败记录数',
    fail_reason   varchar(256)  null comment '失败原因',
    fail_url      varchar(256)  null comment '失败文件url',
    status        tinyint       not null comment '任务状态 0-正在处理 1-处理完成 2-处理失败',
    description   varchar(1024) null comment '备注',
    ext1          varchar(256)  null comment '扩展字段1',
    ext2          varchar(256)  null comment '扩展字段2',
    ext3          varchar(256)  null comment '扩展字段3',
    extra_json    varchar(512)  null comment '扩展信息json格式',
    created_at    datetime      not null comment '创建时间',
    updated_at    datetime      not null comment '更新时间',
    updated_by    varchar(32)   null comment '操作人名称'
)
    comment '潜客任务表';

create table if not exists aries_potential_transform_analyze
(
    id                         bigint unsigned auto_increment comment '自增主键'
        constraint `PRIMARY`
        primary key,
    tag_group_id               bigint       null comment '潜客标签群组ID',
    total_number               bigint       null comment '当前群组总人数',
    total_convert_number       bigint       null comment '累计转化会员数',
    daily_convert_number       bigint       null comment '日转化会员数',
    convert_number_ratio       int          null comment '累计转化会员数比率(整数)',
    convert_channel_ratio_json varchar(256) null comment '记录各个渠道的转化比率，例如：{"微信":23,"短信":77}',
    sum_at                     datetime     null comment '汇总时间',
    created_at                 datetime     null comment '创建时间',
    updated_at                 datetime     null comment '更新时间'
)
    comment '潜客转化日汇总表';

create index idx_apta_sum_at
    on aries_potential_transform_analyze (sum_at);

create index idx_apta_tag_group_id
    on aries_potential_transform_analyze (tag_group_id);

create table if not exists aries_potential_user_batch_details
(
    id            bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    user_id       bigint       not null comment '潜客id',
    batch_id      bigint       not null comment '批次id',
    name          varchar(64)  null comment '姓名',
    source        varchar(256) not null comment '来源描述',
    source_type   tinyint      not null comment '来源类型 0-线上 1-线下',
    identify_code varchar(64)  not null comment '唯一识别号',
    identify_type varchar(64)  not null comment '唯一识别类型 手机号、微信、邮箱',
    ext1          varchar(256) null comment '扩展字段1',
    ext2          varchar(256) null comment '扩展字段2',
    ext3          varchar(256) null comment '扩展字段3',
    extra_json    varchar(512) null comment '扩展信息json格式',
    created_at    datetime     not null comment '创建时间',
    updated_at    datetime     not null comment '更新时间'
)
    comment '潜客与潜客批次关联表';

create table if not exists aries_potential_users
(
    id             bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    name           varchar(64)  null comment '姓名',
    profile_id     bigint       null comment '匹配会员id',
    identify_code  varchar(64)  not null comment '唯一识别号',
    identify_type  varchar(64)  not null comment '唯一识别类型 手机号、微信、邮箱',
    status         tinyint      not null comment '潜客状态 1:有效 -1:无效',
    convert_status tinyint      not null comment '转化状态 0:待转化 1:原始匹配 2:转化会员',
    convert_at     datetime     null comment '转化时间',
    source         varchar(256) not null comment '来源描述',
    source_type    tinyint      not null comment '来源类型 0-线上 1-线下',
    ext1           varchar(256) null comment '扩展字段1',
    ext2           varchar(256) null comment '扩展字段2',
    ext3           varchar(256) null comment '扩展字段3',
    extra_json     varchar(512) null comment '扩展信息json格式',
    created_at     datetime     not null comment '创建时间',
    updated_at     datetime     not null comment '更新时间'
)
    comment '潜客资料表';

create table if not exists aries_profiles
(
    id                                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id                         varchar(32)                           null comment '租户',
    user_id                           bigint                                null comment '用户ID',
    nickname                          varchar(1024)                         null comment '昵称_加密字段',
    type                              smallint                              null comment '会员类型',
    mobile                            varchar(128)                          null comment '手机号_加密字段',
    email                             varchar(128)                          null comment '邮箱_加密字段',
    outer_id                          varchar(64)                           null comment '外部关联ID',
    barcode                           varchar(256)                          null comment '小程序条形码URL',
    status                            smallint                              null comment '状态',
    `from`                            varchar(32) default ''                null comment '注册渠道',
    from_type                         smallint                              null comment '注册渠道类型',
    source_channel                    varchar(32)                           null comment '会员历史来源',
    srv                               varchar(32)                           null comment '服务渠道',
    srv_type                          smallint                              null comment '服务渠道类型',
    level                             smallint                              null comment '会员等级, link mc_levels.level',
    point                             bigint                                null comment '积分',
    avatar                            varchar(512)                          null comment '头像',
    first_name                        varchar(512)                          null comment '真实名_加密字段',
    last_name                         varchar(256)                          null comment '真实姓',
    gender                            smallint                              null comment '性别',
    birthday                          datetime                              null comment '出生日期',
    birthmonth                        varchar(4)                            null comment '出生日期-月',
    birthdate                         varchar(4)                            null comment '出生日期-日',
    register_at                       datetime                              null comment '注册时间',
    last_active_at                    datetime                              null comment '最近活跃时间',
    last_level_changed_at             datetime                              null comment '上次等级变更时间',
    level_expire_at                   datetime                              null comment '等级失效时间',
    sum_at                            datetime                              null comment '统计时间(若为空则取上次等级变更时间)',
    country                           varchar(32)                           null comment '国家ID',
    province                          varchar(32)                           null comment '省ID',
    city                              varchar(32)                           null comment '市ID',
    region                            varchar(32)                           null comment '区ID',
    street                            varchar(512)                          null comment '街道',
    detail_address                    varchar(256)                          null comment '地址_加密字段',
    address                           varchar(512)                          null comment '详细地址',
    ext1                              varchar(64)                           null comment '预留字段1',
    ext2                              varchar(64)                           null comment '预留字段2',
    ext3                              varchar(64)                           null comment '预留字段3',
    extra_json                        text                                  null comment '额外json字段',
    is_wechat_mini_program_notice     smallint    default 0                 null comment '是否接收微信小程序通知 0： 否 1：是',
    is_wechat_official_account_notice smallint    default 0                 null comment '是否接收微信公众号通知 0： 否 1：是',
    is_email_notice                   smallint    default 0                 null comment '是否接收邮件通知 0： 否 1：是',
    is_sms_notice                     smallint    default 0                 null comment '是否接收短信通知 0： 否 1：是',
    is_alipay_notice                  smallint    default 0                 null comment '是否接收支付宝小程序通知 0： 否 1：是',
    is_account                        smallint    default 1                 null comment '是否接收账户变动推送',
    is_first                          smallint    default 0                 null comment '是否首次完善信息',
    complete_info_channel             varchar(20)                           null comment '完善信息渠道',
    certificate_no                    varchar(32)                           null comment '证件号',
    is_delete                         tinyint                               null comment '逻辑删除 删除(1) 否(0)',
    msg_time                          bigint                                null comment 'MQ消息接收时间',
    created_at                        datetime                              not null comment '创建时间',
    updated_at                        datetime                              not null comment '更新时间',
    updated_birthday_at               datetime                              null comment '更新生日时间',
    updated_by                        varchar(128)                          null comment '操作人信息',
    last_login_at                     datetime                              null comment '最后登录时间',
    last_location                     varchar(32)                           null comment '最近一次的位置',
    is_destroy                        smallint    default 0                 null comment '是否注销后注册0:否 1:是',
    dl_auto_created_at                datetime    default CURRENT_TIMESTAMP not null comment '数据入湖时间',
    dl_auto_updated_at                datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '数据更新时间',
    nick_name_md5                     varchar(64)                           null comment '姓名md5',
    mobile_md5                        varchar(64)                           null comment '手机号md5',
    email_md5                         varchar(64)                           null comment '邮箱md5',
    address_md5                       varchar(64)                           null comment '地址md5',
    constraint idx_ap_tenant_mobile
        unique (tenant_id, mobile),
    constraint idx_ap_tenant_outer_id
        unique (tenant_id, outer_id),
    constraint idx_ap_tenant_user_id
        unique (tenant_id, user_id),
    constraint idx_mobile_md5
        unique (mobile_md5)
)
    comment '会员基础信息' collate = utf8mb4_unicode_ci;

create index idx_ap_register_at
    on aries_profiles (register_at);

create index idx_ap_updated_at
    on aries_profiles (updated_at);

create index idx_email_md5
    on aries_profiles (email_md5, register_at);

create index idx_nick_name_md5
    on aries_profiles (nick_name_md5, register_at);

create table if not exists aries_profiles_backup_a_20200323_180050
(
    id                                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id                         varchar(32)                           null comment '租户',
    user_id                           bigint                                null comment '用户ID',
    nickname                          varchar(128)                          null comment '昵称',
    type                              smallint                              null comment '会员类型',
    mobile                            varchar(64)                           null comment '手机号',
    email                             varchar(128)                          null comment '邮箱',
    outer_id                          varchar(64)                           null comment '外部关联ID',
    barcode                           varchar(256)                          null comment '小程序条形码URL',
    status                            smallint                              null comment '状态',
    `from`                            varchar(32) default ''                null comment '注册渠道',
    from_type                         smallint                              null comment '注册渠道类型',
    history_channel                   varchar(32)                           null comment '会员历史来源',
    srv                               varchar(32)                           null comment '服务渠道',
    srv_type                          smallint                              null comment '服务渠道类型',
    level                             smallint                              null comment '会员等级, link mc_levels.level',
    point                             bigint                                null comment '积分',
    avatar                            varchar(512)                          null comment '头像',
    first_name                        varchar(128)                          null comment '真实名',
    last_name                         varchar(128)                          null comment '真实姓',
    gender                            smallint                              null comment '性别',
    birthday                          datetime                              null comment '出生日期',
    birthmonth                        varchar(4)                            null comment '出生日期-月',
    birthdate                         varchar(4)                            null comment '出生日期-日',
    register_at                       datetime                              null comment '注册时间',
    last_active_at                    datetime                              null comment '最近活跃时间',
    last_level_changed_at             datetime                              null comment '上次等级变更时间',
    level_expire_at                   datetime                              null comment '等级失效时间',
    sum_at                            datetime                              null comment '统计时间(若为空则取上次等级变更时间)',
    country                           varchar(32)                           null comment '国家ID',
    province                          varchar(32)                           null comment '省ID',
    city                              varchar(32)                           null comment '市ID',
    region                            varchar(32)                           null comment '区ID',
    street                            varchar(512)                          null comment '街道',
    detail_address                    varchar(256)                          null,
    address                           varchar(512)                          null comment '详细地址',
    ext1                              varchar(64)                           null comment '预留字段1',
    ext2                              varchar(64)                           null comment '预留字段2',
    ext3                              varchar(64)                           null comment '预留字段3',
    extra_json                        text                                  null comment '额外json字段',
    is_wechat_mini_program_notice     smallint    default 0                 null comment '是否接收微信小程序通知 0： 否 1：是',
    is_wechat_official_account_notice smallint    default 0                 null comment '是否接收微信公众号通知 0： 否 1：是',
    is_email_notice                   smallint    default 0                 null comment '是否接收邮件通知 0： 否 1：是',
    is_sms_notice                     smallint    default 0                 null comment '是否接收短信通知 0： 否 1：是',
    is_alipay_notice                  smallint    default 0                 null comment '是否接收支付宝小程序通知 0： 否 1：是',
    is_account                        smallint    default 1                 null comment '是否接收账户变动推送',
    is_first                          smallint    default 0                 null comment '是否首次完善信息',
    complete_info_channel             varchar(20)                           null comment '完善信息渠道',
    certificate_no                    varchar(32)                           null comment '证件号',
    is_delete                         tinyint                               null comment '逻辑删除 删除(1) 否(0)',
    msg_time                          bigint                                null comment 'MQ消息接收时间',
    created_at                        datetime                              not null comment '创建时间',
    updated_at                        datetime                              not null comment '更新时间',
    updated_by                        varchar(128)                          null comment '操作人信息',
    last_login_at                     datetime                              null comment '最后登录时间',
    is_destroy                        smallint    default 0                 null comment '是否注销后注册0:否 1:是',
    dl_auto_created_at                datetime    default CURRENT_TIMESTAMP not null comment '数据入湖时间',
    dl_auto_updated_at                datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '数据更新时间',
    constraint idx_ap_tenant_email
        unique (tenant_id, email),
    constraint idx_ap_tenant_mobile
        unique (tenant_id, mobile),
    constraint idx_ap_tenant_outer_id
        unique (tenant_id, outer_id),
    constraint idx_ap_tenant_user_id
        unique (tenant_id, user_id)
)
    comment '会员基础信息' collate = utf8mb4_unicode_ci;

create index idx_ap_register_at
    on aries_profiles_backup_a_20200323_180050 (register_at);

create index idx_ap_updated_at
    on aries_profiles_backup_a_20200323_180050 (updated_at);

create table if not exists aries_profiles_channel_config
(
    id                  bigint auto_increment
        constraint `PRIMARY`
        primary key,
    regist_channel      varchar(128)                       not null comment '注册渠道',
    regist_channel_code varchar(128)                       not null comment '注册渠道编码',
    status              tinyint  default 1                 not null comment '状态(1草稿,2启用,3停用)',
    created_by          varchar(128)                       not null comment '创建人',
    created_at          datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at          datetime default CURRENT_TIMESTAMP null comment '更新时间',
    updated_by          varchar(128)                       null comment '更新人',
    creator_id          varchar(128)                       not null comment '创建人id',
    updator_id          varchar(128)                       null comment '更新人id',
    flow_id             varchar(64)                        null comment '审批实例id',
    audit_status        varchar(16)                        null comment '审批状态 WAITING-待审核 SUCCESS-审核成功 FAILED-审核失败',
    constraint idx_code
        unique (regist_channel_code)
)
    charset = utf8;

create table if not exists aries_profiles_copy1
(
    id                                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id                         varchar(32)                           null comment '租户',
    user_id                           bigint                                null comment '用户ID',
    nickname                          varchar(128)                          null comment '昵称',
    type                              smallint                              null comment '会员类型',
    mobile                            varchar(64)                           null comment '手机号',
    email                             varchar(128)                          null comment '邮箱',
    outer_id                          varchar(64)                           null comment '外部关联ID',
    barcode                           varchar(256)                          null comment '小程序条形码URL',
    status                            smallint                              null comment '状态',
    `from`                            varchar(32) default ''                null comment '注册渠道',
    from_type                         smallint                              null comment '注册渠道类型',
    history_channel                   varchar(32)                           null comment '会员历史来源',
    srv                               varchar(32)                           null comment '服务渠道',
    srv_type                          smallint                              null comment '服务渠道类型',
    level                             smallint                              null comment '会员等级, link mc_levels.level',
    point                             bigint                                null comment '积分',
    avatar                            varchar(512)                          null comment '头像',
    first_name                        varchar(128)                          null comment '真实名',
    last_name                         varchar(128)                          null comment '真实姓',
    gender                            smallint                              null comment '性别',
    birthday                          datetime                              null comment '出生日期',
    birthmonth                        varchar(4)                            null comment '出生日期-月',
    birthdate                         varchar(4)                            null comment '出生日期-日',
    register_at                       datetime                              null comment '注册时间',
    last_active_at                    datetime                              null comment '最近活跃时间',
    last_level_changed_at             datetime                              null comment '上次等级变更时间',
    level_expire_at                   datetime                              null comment '等级失效时间',
    sum_at                            datetime                              null comment '统计时间(若为空则取上次等级变更时间)',
    country                           varchar(32)                           null comment '国家ID',
    province                          varchar(32)                           null comment '省ID',
    city                              varchar(32)                           null comment '市ID',
    region                            varchar(32)                           null comment '区ID',
    street                            varchar(512)                          null comment '街道',
    detail_address                    varchar(256)                          null,
    address                           varchar(512)                          null comment '详细地址',
    ext1                              varchar(64)                           null comment '预留字段1',
    ext2                              varchar(64)                           null comment '预留字段2',
    ext3                              varchar(64)                           null comment '预留字段3',
    extra_json                        text                                  null comment '额外json字段',
    is_wechat_mini_program_notice     smallint    default 0                 null comment '是否接收微信小程序通知 0： 否 1：是',
    is_wechat_official_account_notice smallint    default 0                 null comment '是否接收微信公众号通知 0： 否 1：是',
    is_email_notice                   smallint    default 0                 null comment '是否接收邮件通知 0： 否 1：是',
    is_sms_notice                     smallint    default 0                 null comment '是否接收短信通知 0： 否 1：是',
    is_alipay_notice                  smallint    default 0                 null comment '是否接收支付宝小程序通知 0： 否 1：是',
    is_account                        smallint    default 1                 null comment '是否接收账户变动推送',
    is_first                          smallint    default 0                 null comment '是否首次完善信息',
    complete_info_channel             varchar(20)                           null comment '完善信息渠道',
    certificate_no                    varchar(32)                           null comment '证件号',
    is_delete                         tinyint                               null comment '逻辑删除 删除(1) 否(0)',
    msg_time                          bigint                                null comment 'MQ消息接收时间',
    created_at                        datetime                              not null comment '创建时间',
    updated_at                        datetime                              not null comment '更新时间',
    updated_by                        varchar(128)                          null comment '操作人信息',
    last_login_at                     datetime                              null comment '最后登录时间',
    is_destroy                        smallint    default 0                 null comment '是否注销后注册0:否 1:是',
    dl_auto_created_at                datetime    default CURRENT_TIMESTAMP not null comment '数据入湖时间',
    dl_auto_updated_at                datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '数据更新时间',
    constraint idx_ap_tenant_email
        unique (tenant_id, email),
    constraint idx_ap_tenant_mobile
        unique (tenant_id, mobile),
    constraint idx_ap_tenant_outer_id
        unique (tenant_id, outer_id),
    constraint idx_ap_tenant_user_id
        unique (tenant_id, user_id)
)
    comment '会员基础信息' collate = utf8mb4_unicode_ci;

create index idx_ap_register_at
    on aries_profiles_copy1 (register_at);

create index idx_ap_updated_at
    on aries_profiles_copy1 (updated_at);

create table if not exists aries_profiles_destroy
(
    id         bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id  bigint       not null comment '会员id',
    mobile     varchar(128) not null comment '手机号',
    mobile_md5 varchar(64)  not null comment '手机号md5',
    reason     varchar(512) null comment '注销原因',
    extra_json text         null comment '额外json字段',
    created_at datetime     not null comment '创建时间',
    updated_at datetime     not null comment '更新时间'
)
    comment '会员基础信息' collate = utf8mb4_unicode_ci;

create table if not exists aries_profiles_destroy_copy1
(
    id         bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id  bigint       not null comment '会员id',
    mobile     varchar(32)  not null comment '手机号',
    reason     varchar(512) null comment '注销原因',
    extra_json text         null comment '额外json字段',
    created_at datetime     not null comment '创建时间',
    updated_at datetime     not null comment '更新时间'
)
    comment '会员基础信息' collate = utf8mb4_unicode_ci;

create table if not exists aries_profiles_temp
(
    id                    bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant                varchar(32)                           null comment '租户',
    user_id               bigint                                null comment '用户ID',
    nickname              varchar(32)                           null comment '昵称',
    type                  smallint                              null comment '会员类型',
    mobile                varchar(32)                           null comment '手机号',
    email                 varchar(128)                          null comment '邮箱',
    outer_id              varchar(64)                           null comment '外部关联ID',
    status                smallint    default 1                 null comment '状态',
    `from`                varchar(32) default ''                null comment '注册渠道',
    from_type             smallint    default 0                 null comment '注册渠道类型',
    srv                   varchar(32)                           null comment '服务渠道',
    srv_type              smallint                              null comment '服务渠道类型',
    level                 smallint    default 1                 null comment '会员等级, link mc_levels.level',
    point                 bigint      default 0                 null comment '积分',
    avatar                varchar(512)                          null comment '头像',
    first_name            varchar(128)                          null comment '真实名',
    last_name             varchar(128)                          null comment '真实姓',
    gender                smallint                              null comment '性别',
    birthday              datetime                              null comment '出生日期',
    register_at           datetime                              null comment '注册时间',
    last_active_at        datetime                              null comment '最近活跃时间',
    last_level_changed_at datetime                              null comment '上次等级变更时间',
    level_expire_at       datetime                              null comment '等级失效时间',
    sum_at                datetime                              null comment '统计时间(若为空则取上次等级变更时间)',
    country               varchar(32)                           null comment '国家ID',
    province              varchar(32)                           null comment '省ID',
    city                  varchar(32)                           null comment '市ID',
    region                varchar(32)                           null comment '区ID',
    street                varchar(512)                          null comment '街道',
    address               varchar(512)                          null comment '详细地址',
    certificate_no        varchar(32)                           null comment '证件号',
    ext1                  varchar(64)                           null comment '预留字段1',
    ext2                  varchar(64)                           null comment '预留字段2',
    ext3                  varchar(64)                           null comment '预留字段3',
    is_marketing          smallint    default 0                 null comment '是否接收营销推送 0： 否 1：是',
    is_account            smallint    default 1                 null comment '是否接收账户变动推送',
    car_type              varchar(128)                          null comment '车辆类型 ',
    car_brand             varchar(128)                          null comment '品牌',
    vehicle_type          varchar(128)                          null comment '车型',
    cc                    varchar(128)                          null comment '排量',
    car_year              varchar(128)                          null comment '年份',
    car_km                varchar(128)                          null comment '里程',
    created_at            datetime                              not null comment '创建时间',
    updated_at            datetime                              not null comment '更新时间',
    updated_by            varchar(128)                          null comment '操作人信息',
    dl_auto_created_at    datetime    default CURRENT_TIMESTAMP not null comment '数据入湖时间',
    dl_auto_updated_at    datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '数据更新时间',
    constraint idx_ap_tenant_email
        unique (tenant, email),
    constraint idx_ap_tenant_mobile
        unique (tenant, mobile),
    constraint idx_ap_tenant_outer_id
        unique (tenant, outer_id),
    constraint idx_ap_tenant_user_id
        unique (tenant, user_id)
)
    comment '会员基础信息' collate = utf8mb4_unicode_ci;

create index idx_ap_register_at
    on aries_profiles_temp (register_at);

create index idx_ap_updated_at
    on aries_profiles_temp (updated_at);

create table if not exists aries_roi_task
(
    id             bigint       not null,
    created_at     datetime     not null comment '创建时间',
    end_at         datetime     not null comment '统计截止时间',
    fail_reason    longtext     null comment '失败原因',
    file_url       varchar(256) not null comment '文件路径',
    name           varchar(64)  null comment '任务名称',
    result         longtext     null comment '统计结果',
    result_type    varchar(64)  not null comment 'roi类型,detail具体明细,num数量结果',
    roi_request    longtext     not null comment 'roi指标请求',
    scope          varchar(64)  null comment '统计范围',
    start_at       datetime     not null comment '统计开始时间',
    statistic_type varchar(128) not null comment '统计类型',
    status         varchar(64)  not null comment '操作状态 INIT:初始 PROCESS:进行中 FINISH:完成 FAIL:异常失败',
    updated_at     datetime     not null comment '更新时间',
    constraint `PRIMARY`
        primary key (id)
);

create table if not exists aries_sequence
(
    id    bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    name  varchar(32) null comment '名称',
    value varchar(32) null comment 'value'
)
    comment '全局唯一码' collate = utf8mb4_unicode_ci;

create table if not exists aries_shipping_address
(
    id                 bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id          bigint unsigned       not null comment '会员id',
    receiver_name      varchar(20)           not null comment '收件人姓名',
    receiver_mobile    varchar(20)           null comment '收件人手机号',
    receiver_telephone varchar(20)           null comment '收件人电话',
    province_id        bigint                not null comment '省 id',
    province_name      varchar(20)           null comment '省名',
    city_id            bigint                null,
    city_name          varchar(20)           null comment '市名',
    district_id        bigint                null comment '区 id',
    district_name      varchar(20)           null comment '区名',
    street_id          bigint                null comment '街道 id',
    street_name        varchar(20)           null comment '街道名',
    detail_address     varchar(255)          not null comment '详细地址',
    postcode           varchar(20)           null comment '邮编',
    is_default         tinyint(1) default 0  not null comment '是否是默认地址',
    created_at         datetime              not null comment '创建时间',
    updated_at         datetime              not null comment '更新时间',
    is_delete          tinyint(1) default -1 not null comment '是否删除地址',
    longitude          double                null comment '经度',
    latitude           double                null comment '维度',
    extra              varchar(2000)         null comment '扩展字段',
    gender             smallint              null
)
    comment '收货地址表';

create index idx_asa_member_id
    on aries_shipping_address (member_id);

create table if not exists aries_srvs
(
    id          varchar(32)  not null,
    tenant_id   smallint     not null comment '租户id',
    name        varchar(32)  not null comment '来源名称',
    description varchar(256) null comment '来源描述',
    created_at  datetime     not null comment '创建时间',
    updated_at  datetime     not null comment '更新时间',
    updated_by  varchar(128) null comment '操作人信息',
    constraint `PRIMARY`
        primary key (id),
    constraint idx_af_name
        unique (tenant_id, name)
)
    comment '会员服务渠道';

create table if not exists aries_third_channel_profiles
(
    id          bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    member_id   bigint                                            not null comment '用户ID',
    third_id    varchar(20)                                       null comment '第三方渠道会员编号',
    nickname    varchar(512) collate utf8mb4_unicode_ci           null comment '昵称',
    mobile      varchar(32) collate utf8mb4_unicode_ci            null comment '手机号',
    email       varchar(128) collate utf8mb4_unicode_ci           null comment '邮箱',
    outer_id    varchar(64) collate utf8mb4_unicode_ci            null comment '外部关联ID',
    status      smallint                                          not null comment '状态',
    `from`      varchar(32) collate utf8mb4_unicode_ci default '' null comment '注册渠道',
    from_type   smallint                                          null comment '注册渠道类型',
    gender      smallint                                          null comment '性别',
    birthday    datetime                                          null comment '出生日期',
    register_at datetime                                          null comment '注册时间',
    province    varchar(32) collate utf8mb4_unicode_ci            null comment '省ID',
    city        varchar(32) collate utf8mb4_unicode_ci            null comment '市ID',
    region      varchar(32) collate utf8mb4_unicode_ci            null comment '区ID',
    street      varchar(512) collate utf8mb4_unicode_ci           null comment '街道',
    created_at  datetime                                          not null comment '创建时间',
    updated_at  datetime                                          null comment '修改时间',
    delete_yn   tinyint(1)                             default 0  not null comment '删除标记，0:未删除，1：已删除'
)
    comment '会员第三方渠道信息表';

create index idx_ap_register_at
    on aries_third_channel_profiles (register_at);

create index idx_ap_updated_at
    on aries_third_channel_profiles (updated_at);

create index idx_memberid_deleteyn
    on aries_third_channel_profiles (member_id, delete_yn);

create table if not exists aries_trade_order_details
(
    id                  bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    member_id           bigint       not null comment '会员ID',
    trade_amount        bigint       not null comment '交易金额',
    refund_trade_amount bigint       not null comment '累计退货金额',
    rest_trade_amount   bigint       not null comment '有效交易金额',
    compute_money       bigint       not null comment '积分金额',
    trade_no            varchar(32)  null comment '交易流水号',
    outer_id            varchar(32)  null comment '外部单据id',
    outer_type          smallint     null comment '外部单据类型',
    source              varchar(32)  null comment '来源(可以考虑取服务渠道)',
    source_type         smallint     null comment '来源类型',
    status              smallint     not null comment '0: 无效, 1: 有效',
    year                varchar(4)   not null comment '发生年',
    occurred_at         datetime     not null comment '发生时间',
    created_at          datetime     not null comment '创建时间',
    updated_at          datetime     not null comment '更新时间',
    updated_by          varchar(128) null comment '操作人信息'
)
    comment '累计金额明细' collate = utf8mb4_unicode_ci;

create index idx_atod_member_id
    on aries_trade_order_details (member_id);

create index idx_atod_outer_id
    on aries_trade_order_details (outer_id);

create table if not exists aries_types
(
    id          smallint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id   smallint     not null comment '租户id',
    name        varchar(32)  not null comment '类型名称                         ',
    description varchar(256) null comment '类型描述',
    created_at  datetime     not null comment '创建时间',
    updated_at  datetime     not null comment '更新时间',
    updated_by  varchar(64)  null comment '操作人信息',
    constraint idx_at_name
        unique (tenant_id, name)
)
    comment '会员类型';

create table if not exists aries_user_authorizations
(
    id         bigint auto_increment
        constraint `PRIMARY`
        primary key,
    user_id    bigint       not null comment '用户id',
    role_id    bigint       not null comment '角色id',
    status     smallint     not null comment '状态',
    created_at datetime     not null comment '创建时间',
    updated_at datetime     not null comment '更新时间',
    updated_by varchar(128) null comment '操作人信息'
)
    comment '运营账户授权' collate = utf8mb4_unicode_ci;

create index idx_aua_user_id
    on aries_user_authorizations (user_id);

create table if not exists aries_user_roles
(
    id          bigint auto_increment
        constraint `PRIMARY`
        primary key,
    tenant      varchar(32)  null comment '租户',
    name        varchar(40)  not null comment '用户名',
    description varchar(256) null comment '描述',
    allow_json  text         not null comment '角色对应选中权限树节点列表',
    status      smallint     not null comment '状态',
    created_at  datetime     not null comment '创建时间',
    updated_at  datetime     not null comment '更新时间',
    updated_by  varchar(128) null comment '操作人信息',
    constraint idx_aur_tenant_name
        unique (tenant, name)
)
    comment '运营账户角色表' collate = utf8mb4_unicode_ci;

create table if not exists aries_users
(
    id         bigint auto_increment
        constraint `PRIMARY`
        primary key,
    tenant     varchar(32)  null comment '租户',
    name       varchar(32)  null comment '用户名',
    password   varchar(32)  null comment '登录密码',
    outer_id   varchar(32)  null comment '外部用户id',
    roles_json text         null comment '角色列表(json)',
    status     smallint     null comment '状态: 未启用(-1) 启用(1)',
    created_at datetime     not null,
    updated_at datetime     not null,
    updated_by varchar(128) null comment '操作人信息',
    constraint idx_au_tenant_name
        unique (tenant, name),
    constraint idx_au_tenant_outer_id
        unique (tenant, outer_id)
)
    comment '运营账户表' collate = utf8mb4_unicode_ci;

create table if not exists batch_job_execution_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
)
    collate = utf8mb4_unicode_ci;

create table if not exists batch_job_instance
(
    JOB_INSTANCE_ID bigint       not null,
    VERSION         bigint       null,
    JOB_NAME        varchar(100) not null,
    JOB_KEY         varchar(32)  not null,
    constraint `PRIMARY`
        primary key (JOB_INSTANCE_ID),
    constraint JOB_INST_UN
        unique (JOB_NAME, JOB_KEY)
)
    collate = utf8mb4_unicode_ci;

create table if not exists batch_job_execution
(
    JOB_EXECUTION_ID           bigint        not null,
    VERSION                    bigint        null,
    JOB_INSTANCE_ID            bigint        not null,
    CREATE_TIME                datetime      not null,
    START_TIME                 datetime      null,
    END_TIME                   datetime      null,
    STATUS                     varchar(10)   null,
    EXIT_CODE                  varchar(2500) null,
    EXIT_MESSAGE               varchar(2500) null,
    LAST_UPDATED               datetime      null,
    JOB_CONFIGURATION_LOCATION varchar(2500) null,
    constraint `PRIMARY`
        primary key (JOB_EXECUTION_ID),
    constraint JOB_INST_EXEC_FK
        foreign key (JOB_INSTANCE_ID) references batch_job_instance (JOB_INSTANCE_ID)
)
    collate = utf8mb4_unicode_ci;

create table if not exists batch_job_execution_context
(
    JOB_EXECUTION_ID   bigint        not null,
    SHORT_CONTEXT      varchar(2500) not null,
    SERIALIZED_CONTEXT text          null,
    constraint `PRIMARY`
        primary key (JOB_EXECUTION_ID),
    constraint JOB_EXEC_CTX_FK
        foreign key (JOB_EXECUTION_ID) references batch_job_execution (JOB_EXECUTION_ID)
)
    collate = utf8mb4_unicode_ci;

create table if not exists batch_job_execution_params
(
    JOB_EXECUTION_ID bigint       not null,
    TYPE_CD          varchar(6)   not null,
    KEY_NAME         varchar(100) not null,
    STRING_VAL       varchar(250) null,
    DATE_VAL         datetime     null,
    LONG_VAL         bigint       null,
    DOUBLE_VAL       double       null,
    IDENTIFYING      char         not null,
    constraint JOB_EXEC_PARAMS_FK
        foreign key (JOB_EXECUTION_ID) references batch_job_execution (JOB_EXECUTION_ID)
)
    collate = utf8mb4_unicode_ci;

create table if not exists batch_job_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
)
    collate = utf8mb4_unicode_ci;

create table if not exists batch_step_execution
(
    STEP_EXECUTION_ID  bigint        not null,
    VERSION            bigint        not null,
    STEP_NAME          varchar(100)  not null,
    JOB_EXECUTION_ID   bigint        not null,
    START_TIME         datetime      not null,
    END_TIME           datetime      null,
    STATUS             varchar(10)   null,
    COMMIT_COUNT       bigint        null,
    READ_COUNT         bigint        null,
    FILTER_COUNT       bigint        null,
    WRITE_COUNT        bigint        null,
    READ_SKIP_COUNT    bigint        null,
    WRITE_SKIP_COUNT   bigint        null,
    PROCESS_SKIP_COUNT bigint        null,
    ROLLBACK_COUNT     bigint        null,
    EXIT_CODE          varchar(2500) null,
    EXIT_MESSAGE       varchar(2500) null,
    LAST_UPDATED       datetime      null,
    constraint `PRIMARY`
        primary key (STEP_EXECUTION_ID),
    constraint JOB_EXEC_STEP_FK
        foreign key (JOB_EXECUTION_ID) references batch_job_execution (JOB_EXECUTION_ID)
)
    collate = utf8mb4_unicode_ci;

create table if not exists batch_step_execution_context
(
    STEP_EXECUTION_ID  bigint        not null,
    SHORT_CONTEXT      varchar(2500) not null,
    SERIALIZED_CONTEXT text          null,
    constraint `PRIMARY`
        primary key (STEP_EXECUTION_ID),
    constraint STEP_EXEC_CTX_FK
        foreign key (STEP_EXECUTION_ID) references batch_step_execution (STEP_EXECUTION_ID)
)
    collate = utf8mb4_unicode_ci;

create table if not exists batch_step_execution_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
)
    collate = utf8mb4_unicode_ci;

create table if not exists compensate_biz
(
    id            bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    trade_no      varchar(64)  null comment '交易流水号',
    trans_type    varchar(64)  not null comment '交易业务类型',
    context       longtext     null comment '明细内容',
    msg_id        varchar(128) null comment '消息id',
    status        varchar(32)  not null comment '状态',
    fail_count    tinyint      null comment '失败次数',
    priority      tinyint      null comment '优先级',
    failed_reason text         null comment '上次失败原因',
    created_at    datetime     not null comment '创建时间',
    updated_at    datetime     not null comment '更新时间',
    constraint idx_virgo_cb_unique
        unique (trade_no)
)
    comment '业务补偿表' collate = utf8mb4_unicode_ci;

create table if not exists disks
(
    id                 bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    name               varchar(128) default ''                not null comment '磁盘名',
    name_pinyin        varchar(128) default ''                not null comment '磁盘名拼⾳音',
    type               varchar(64)  default ''                not null comment '磁盘类型: SYSTEM, NORMAL',
    creator_id         varchar(255) default ''                not null comment '创建⼈人 ID',
    delete_yn          tinyint(1)   default 0                 not null comment '逻辑删除标记',
    created_at         datetime                               not null comment '表记录创建时间',
    updated_at         datetime                               not null comment '表记录更更新时间',
    dl_auto_created_at datetime     default CURRENT_TIMESTAMP not null comment '数据入湖时间',
    dl_auto_updated_at datetime     default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '数据更新时间',
    constraint uk_name
        unique (name)
)
    collate = utf8mb4_unicode_ci;

create table if not exists eve_article_category
(
    id        int auto_increment
        constraint `PRIMARY`
        primary key,
    namespace varchar(128) null,
    parentId  int          not null,
    name      varchar(128) not null,
    createdAt datetime     not null,
    updatedAt datetime     not null,
    constraint eve_article_category_namespace_parent_id_name
        unique (namespace, parentId, name)
);

create table if not exists eve_article
(
    id          int auto_increment
        constraint `PRIMARY`
        primary key,
    categoryId  int                                                            not null,
    title       varchar(128)                                                   not null,
    content     mediumtext                                                     null,
    creator     varchar(64)                                                    null,
    status      enum ('unpublish', 'published', 'disable') default 'unpublish' null,
    keyword     varchar(512)                                                   null,
    description varchar(1024)                                                  null,
    attach      varchar(1000)                                                  null,
    data        text                                                           null,
    sortNum     int                                                            null,
    createdAt   datetime                                                       not null,
    updatedAt   datetime                                                       not null,
    constraint eve_article_category_id_title
        unique (categoryId, title),
    constraint eve_article_ibfk_1
        foreign key (categoryId) references eve_article_category (id)
            on update cascade on delete cascade
);

create table if not exists eve_site_info
(
    id           int auto_increment
        constraint `PRIMARY`
        primary key,
    namespace    varchar(128)                       null,
    appType      enum ('pc', 'mobile') default 'pc' null,
    domain       varchar(1024)                      null,
    activeSiteId int                                null,
    owner        varchar(128)                       null,
    createdAt    datetime                           not null,
    updatedAt    datetime                           not null,
    deletedAt    datetime                           null
);

create table if not exists eve_site
(
    id            int auto_increment
        constraint `PRIMARY`
        primary key,
    siteInfoId    int                                     not null,
    type          enum ('site', 'templet') default 'site' null,
    appType       enum ('pc', 'mobile')    default 'pc'   null,
    name          varchar(128)                            not null,
    layout        varchar(128)                            not null,
    isDefaultTemp tinyint(1)               default 0      null,
    isRelease     tinyint(1)               default 0      null,
    thumbnail     varchar(256)                            null,
    templetId     int                                     null,
    createdAt     datetime                                not null,
    updatedAt     datetime                                not null,
    deletedAt     datetime                                null,
    constraint eve_site_ibfk_1
        foreign key (siteInfoId) references eve_site_info (id)
            on update cascade on delete cascade
);

create index siteInfoId
    on eve_site (siteInfoId);

create table if not exists nc_email_account
(
    id         bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    third_id   bigint                        not null comment '对应的第三方账号ud',
    user_name  varchar(50) charset utf8mb4   not null comment '邮箱名',
    password   varchar(50) charset utf8mb4   not null comment '密码或者授权码',
    is_default tinyint(1) unsigned default 0 not null comment '是否默认使用邮箱',
    type       tinyint(2)                    not null comment '邮箱类型：1、163邮箱。2、qq邮箱。3、腾讯企业邮箱',
    created_at datetime                      not null comment '创建时间',
    updated_at datetime                      null comment '修改时间',
    is_deleted tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '邮箱账号表' collate = utf8mb4_bin;

create index email_account_third_id
    on nc_email_account (third_id);

create table if not exists nc_email_content
(
    id         bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    third_id   bigint                        not null comment '第三方id',
    content    text charset utf8mb4          not null comment '邮件内容',
    created_at datetime                      not null comment '创建时间',
    updated_at datetime                      null comment '修改时间',
    is_deleted tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '邮件发送内容表' collate = utf8mb4_bin;

create table if not exists nc_email_schedule
(
    id            bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    content       varchar(8000) charset utf8mb4 not null comment '500个手机号最多',
    is_handle     tinyint(1) unsigned default 0 not null comment '是否处理',
    type          tinyint(1)          default 1 not null comment '1、模板站邮件。2、自定义站邮件。',
    schedule_time datetime                      not null comment '定时时间',
    created_at    datetime                      not null comment '创建时间',
    updated_at    datetime                      null comment '修改时间',
    is_deleted    tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '短信定时任务表' collate = utf8mb4_bin;

create table if not exists nc_email_template
(
    id           bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    notice_type  varchar(30)                   not null comment '通知类型，对应NoticeType',
    name         varchar(50)                   not null comment '模板名称',
    type         varchar(50)                   null comment '业务类型',
    third_id     bigint                        not null comment '对应的第三方账号id',
    content      text                          not null comment '模板内容',
    notice_code  varchar(20)                   not null comment '对应通知中心对业务方唯一的code',
    code_length  tinyint(1) unsigned           null comment '验证码长度，通知类型为验证码时必填',
    code_index   tinyint(1) unsigned           null comment '验证码在模板中的索引，通知类型为验证码时必填',
    expired_time smallint(6) unsigned          null comment '验证码失效时间，以秒为单位，通知类型为验证码时必',
    sender_email bigint unsigned               null comment '发送邮箱',
    is_html      tinyint(1) unsigned default 0 not null comment '是否html格式',
    subject      varchar(500)                  null comment '主题',
    created_at   datetime                      not null comment '创建时间',
    updated_at   datetime                      null comment '修改时间',
    is_deleted   tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '邮件模板表' collate = utf8mb4_bin;

create index email_uniform_third_id
    on nc_email_template (third_id);

create table if not exists nc_email_verify_code
(
    id            bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    code          varchar(10)                   not null comment '验证码',
    expired_at    datetime                      not null comment '失效时间',
    notice_code   varchar(20)                   not null,
    email_address varchar(50)                   not null comment '邮箱地址',
    third_id      bigint                        not null comment '第三方id',
    verified_time tinyint(2) unsigned default 0 not null comment '已经验证次数',
    created_at    datetime                      not null comment '创建时间',
    updated_at    datetime                      null comment '修改时间',
    is_deleted    tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '邮件验证码表' collate = utf8mb4_bin;

create index email_verify_code_index
    on nc_email_verify_code (email_address, third_id);

create table if not exists nc_manager
(
    id          bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    user_id     bigint unsigned               null comment '对应用户中心id',
    create_user bigint unsigned               not null comment '创建人',
    created_at  datetime                      not null,
    updated_at  datetime                      not null on update CURRENT_TIMESTAMP comment '修改时间',
    is_deleted  tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '管理员表' collate = utf8mb4_bin;

create table if not exists nc_mobile_app
(
    id              bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    app_name        varchar(20) charset utf8mb4      not null,
    third_id        bigint                           not null comment '第三方用户id',
    push_channel    tinyint(1)          default 2    not null comment '推送渠道。1、友盟。2、阿里云推送。',
    notify_bar_type tinyint(2)                       null comment '安卓8barType',
    notify_channel  varchar(20)                      null comment '安卓8通道',
    extra_config    varchar(255)        default '{}' not null comment 'app额外配置',
    created_at      datetime                         not null comment '创建时间',
    updated_at      datetime                         null comment '修改时间',
    is_deleted      tinyint(1) unsigned default 0    not null comment '是否删除'
)
    comment '移动app表' collate = utf8mb4_bin;

create index nc_mobile_app_third_id
    on nc_mobile_app (third_id);

create table if not exists nc_push_aliyun
(
    id            bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    mobile_app_id bigint unsigned               not null comment '对应nc_mobile_app',
    app_key       bigint                        not null comment 'app_key',
    key_id        varchar(40) charset utf8mb4   not null comment '阿里云账号的keyId',
    key_secret    varchar(40) charset utf8mb4   not null comment '阿里云账号的key_secret',
    type          tinyint(1)                    not null comment '应用类型：1、Android。2、IOS',
    created_at    datetime                      not null comment '创建时间',
    updated_at    datetime                      null comment '修改时间',
    is_deleted    tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '阿里云推送表' collate = utf8mb4_bin;

create index umeng_mobile_app_id
    on nc_push_aliyun (mobile_app_id);

create table if not exists nc_push_content
(
    id            bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    third_id      bigint                        not null comment '第三方id',
    content       text charset utf8mb4          not null comment 'appPushDTO序列化成json',
    title         varchar(200) charset utf8mb4  not null comment '标题',
    extra_info    varchar(2000) charset utf8mb4 null comment '发送时的额外配置',
    description   varchar(200) charset utf8mb4  null comment '消息描述',
    is_broadcast  tinyint(1) unsigned default 0 not null comment '是否广播',
    alias         varchar(7000) charset utf8mb4 null comment '别名，不超过500个',
    alias_type    varchar(50) charset utf8mb4   null comment '别名类型',
    schedule_time varchar(19) charset utf8mb4   null comment '定时发送时间',
    expire_time   varchar(19) charset utf8mb4   null comment '失效时间',
    created_at    datetime                      not null comment '创建时间',
    updated_at    datetime                      null comment '修改时间',
    is_deleted    tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '推送内容表' collate = utf8mb4_bin;

create table if not exists nc_push_umeng
(
    id                bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    mobile_app_id     bigint unsigned               not null comment '对应nc_mobile_app',
    app_key           varchar(50) charset utf8mb4   not null comment 'app_key',
    app_master_secret varchar(50) charset utf8mb4   not null comment 'appMasterSecret',
    type              tinyint(1)                    not null comment '应用类型：1、Android。2、IOS',
    created_at        datetime                      not null comment '创建时间',
    updated_at        datetime                      null comment '修改时间',
    is_deleted        tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '友盟推送表' collate = utf8mb4_bin;

create index umeng_mobile_app_id
    on nc_push_umeng (mobile_app_id);

create table if not exists nc_schedule
(
    id            bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    content       text charset utf8mb4          not null comment 'json对象',
    handle        varchar(30)                   not null comment '处理类型，对应NoticeHandleEnum',
    type          varchar(30)                   not null comment '通知类型，对应NoticeType，站内信、短信、邮件、App',
    created_at    datetime                      not null comment '创建时间',
    schedule_time datetime                      not null comment '定时任务时间',
    updated_at    datetime                      null comment '修改时间',
    is_deleted    tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '定时任务表' collate = utf8mb4_bin;

create table if not exists nc_sms_account
(
    id           bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    account_name varchar(50) charset utf8mb4   not null comment '账号名称',
    access_key   text charset utf8mb4          not null comment '数组，包括key和secret:{"key":"","secret":""}',
    sign         text charset utf8mb4          not null comment '签名组成的字符串数组',
    type         varchar(50) charset utf8mb4   not null comment '账号类型，枚举',
    third_id     bigint                        not null comment '对应的第三方账号ud',
    priority     tinyint(2) unsigned default 0 not null comment '优先级',
    webhook      varchar(255)                  null comment '自定义钩子，在类型时自定义时生效',
    created_at   datetime                      not null comment '创建时间',
    updated_at   datetime                      null comment '修改时间',
    is_deleted   tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '短信账号（渠道）表' collate = utf8mb4_bin;

create table if not exists nc_sms_channel_template
(
    id         bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    account_id bigint                        not null comment '账号id',
    type       varchar(50)                   null comment '模板类型，验证码或者通知等',
    name       varchar(50)                   null comment '模板名称',
    code       varchar(50)                   null comment '模板code，阿里云渠道必填',
    content    varchar(500)                  not null comment '模板内容',
    apply_desc varchar(500)                  null comment '申请描述',
    created_at datetime                      not null comment '创建时间',
    updated_at datetime                      null comment '修改时间',
    is_deleted tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '短信渠道模板表' collate = utf8mb4_bin;

create table if not exists nc_sms_channel_template_rel
(
    id         bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    uniform_id bigint unsigned               not null comment '对外统一的模板id',
    account_id bigint unsigned               not null comment '绑定的账号id',
    channel_id bigint unsigned               null comment '对应的渠道id',
    sign       varchar(50)                   null comment '签名选填',
    created_at datetime                      not null comment '创建时间',
    updated_at datetime                      null comment '修改时间',
    is_deleted tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '短信渠道模板关系表' collate = utf8mb4_bin;

create index template_rel_uniform_id
    on nc_sms_channel_template_rel (uniform_id);

create table if not exists nc_sms_content
(
    id          bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    content     text                            not null comment '短信内容',
    user_number smallint(20) unsigned default 1 not null comment '发送的用户数',
    created_at  datetime                        not null comment '创建时间',
    updated_at  datetime                        null comment '修改时间',
    is_deleted  tinyint(1) unsigned   default 0 not null comment '是否删除'
)
    comment '短信内容表' collate = utf8mb4_bin;

create table if not exists nc_sms_schedule
(
    id            bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    content       text charset utf8mb4          not null comment '500个手机号最多',
    is_handle     tinyint(1) unsigned default 0 not null comment '是否处理',
    type          tinyint(1)          default 1 not null comment '1、模板短信。2、自定义短信。',
    created_at    datetime                      not null comment '创建时间',
    schedule_time datetime                      not null comment '定时任务时间',
    updated_at    datetime                      null comment '修改时间',
    is_deleted    tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '短信定时任务表' collate = utf8mb4_bin;

create table if not exists nc_sms_uniform_template
(
    id           bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    notice_type  varchar(30)                   not null comment '通知类型，对应NoticeType',
    type         varchar(50)                   null comment '模板类型',
    third_id     bigint                        not null comment '对应的第三方账号id',
    name         varchar(50)                   null comment '模板名称，50字以内',
    content      varchar(500)                  not null comment '模板内容',
    notice_code  varchar(50)                   not null comment '对应通知中心对业务方唯一的code',
    code_length  tinyint(1) unsigned           null comment '验证码长度，通知类型为验证码时必填',
    code_index   tinyint(1) unsigned           null comment '验证码在模板中的索引，通知类型为验证码时必填',
    expired_time smallint(6) unsigned          null comment '验证码失效时间，以秒为单位，通知类型为验证码时必',
    created_at   datetime                      not null comment '创建时间',
    updated_at   datetime                      null comment '修改时间',
    is_deleted   tinyint(1) unsigned default 0 not null comment '是否删除',
    constraint uniform_third_id
        unique (third_id, notice_code)
)
    comment '短信模板表' collate = utf8mb4_bin;

create table if not exists nc_sms_user
(
    id             bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    phone_number   varchar(20)                   not null comment '手机号',
    sms_content_id bigint                        not null comment '对应内容id',
    is_sent        tinyint(1) unsigned default 0 not null comment '是否发送成功',
    created_at     datetime                      not null comment '创建时间',
    updated_at     datetime                      null comment '修改时间',
    is_deleted     tinyint unsigned    default 0 not null comment '是否删除'
)
    collate = utf8mb4_bin;

create table if not exists nc_sms_verify_code
(
    id            bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    code          varchar(10)                   not null comment '验证码',
    expired_at    datetime                      not null comment '失效时间',
    notice_code   varchar(20)                   not null comment '对应uniform_id的notice_code',
    phone_number  varchar(20)                   not null comment '手机号',
    third_id      bigint                        not null comment '第三方id',
    verified_time tinyint(2) unsigned default 0 not null comment '验证次数',
    created_at    datetime                      not null comment '创建时间',
    updated_at    datetime                      null comment '修改时间',
    is_deleted    tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '短信验证码表' collate = utf8mb4_bin;

create index verify_code_index
    on nc_sms_verify_code (phone_number, third_id);

create table if not exists nc_station_letter_broad_cast
(
    id         bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    third_id   bigint                        not null,
    notice_id  bigint                        not null,
    content    text charset utf8mb4          null comment '广播消息其他参数',
    created_at datetime                      not null comment '创建时间',
    updated_at datetime                      null comment '更新时间',
    is_deleted tinyint(1) unsigned default 0 not null comment '是否删除',
    constraint third_id_index
        unique (third_id, notice_id)
)
    comment '站内信广播表' collate = utf8mb4_bin;

create index broadcast_credate
    on nc_station_letter_broad_cast (created_at);

create table if not exists nc_station_letter_content
(
    id          bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    third_id    bigint                        not null comment '第三方id',
    content     text                          null comment '通知内容',
    extra_info  text                          null comment '额外信息',
    user_number bigint unsigned     default 0 not null comment '发送的用户数量',
    created_at  datetime                      not null comment '创建时间',
    updated_at  datetime                      null comment '更新时间',
    is_deleted  tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '站内信内容表' collate = utf8mb4_bin;

create index nc_third_id_index
    on nc_station_letter_content (third_id);

create table if not exists nc_station_letter_schedule
(
    id            bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    content       text charset utf8mb4          not null,
    is_handle     tinyint(1) unsigned default 0 not null comment '是否处理',
    type          tinyint(1)          default 1 not null comment '1、模板站内信。2、自定义站内信。',
    schedule_time datetime                      not null comment '定时时间',
    created_at    datetime                      not null comment '创建时间',
    updated_at    datetime                      null comment '修改时间',
    is_deleted    tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '站内信定时任务表' collate = utf8mb4_bin;

create table if not exists nc_station_letter_template
(
    id          bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    third_id    bigint                        not null comment '第三方id',
    type        varchar(50) charset utf8mb4   null comment '分类',
    name        varchar(50) charset utf8mb4   not null comment '模板名称',
    notice_code varchar(50) charset utf8mb4   not null comment 'niotice_code，third_id下唯一',
    title       varchar(100)                  null comment '标题',
    content     text                          not null comment '通知内容',
    extra_info  varchar(2000)                 null comment '额外信息',
    status      tinyint(1) unsigned default 1 not null comment '0、关闭。1、开通。',
    created_at  datetime                      not null comment '创建时间',
    updated_at  datetime                      null comment '更新时间',
    is_deleted  tinyint(1) unsigned default 0 not null comment '是否删除',
    constraint slc_third_id_ncode
        unique (third_id, notice_code)
)
    comment '站内信模板表' collate = utf8mb4_bin;

create table if not exists nc_station_letter_user_rel
(
    id            bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    third_id      bigint unsigned               not null comment '第三方id',
    user_id       bigint unsigned               not null comment '用户id',
    notice_id     bigint unsigned               null comment '对应站内信内容id',
    is_read       tinyint(1) unsigned default 0 not null comment '是否已读',
    is_pushed     tinyint(1) unsigned default 0 not null comment '是否已推送',
    is_broadcast  tinyint(1) unsigned default 0 not null comment '1、是广播。0、非广播。',
    business_id   varchar(100)                  null,
    business_type varchar(100)                  not null comment '通知类型，由业务方维护',
    content       text                          null comment '通知内容',
    extra_info    text                          null comment '额外信息',
    title         varchar(100)                  null comment '标题',
    created_at    datetime                      not null comment '创建时间',
    updated_at    datetime                      null comment '修改时间',
    is_deleted    tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '站内信用户关系（站内信记录）表' collate = utf8mb4_bin;

create index station_letter_user_check
    on nc_station_letter_user_rel (third_id, user_id);

create table if not exists nc_third_party_app
(
    id          bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    app_id      varchar(20)                   not null comment '分配给某个域的唯一标识',
    private_key varchar(60)                   not null comment '私钥，用于加密和解密',
    name        varchar(20)                   not null comment '名称',
    create_user bigint unsigned               not null comment '创建者',
    remark      varchar(50)                   null comment '描述',
    status      tinyint(1) unsigned default 0 not null comment '0、申请完的初始状态。5、审核通过。8、已取消权限。',
    app_type    tinyint(1)          default 1 not null,
    config      text charset utf8mb4          not null comment '租户级别的配置',
    created_at  datetime                      not null comment '创建时间',
    updated_at  datetime                      null comment '更新时间',
    is_deleted  tinyint(1) unsigned default 0 not null comment '是否删除',
    constraint third_party_app_id_index
        unique (app_id)
)
    comment '账户表' collate = utf8mb4_bin;

create table if not exists nc_third_party_app_admin
(
    id          bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    nc_third_id bigint unsigned               not null comment '对应nc_third_party_app的id',
    user_id     bigint unsigned               not null comment '用户中心id',
    type        tinyint(1)                    not null comment '1、SUPER_ADMIN。2、SUB_ADMIN',
    remark      varchar(255)                  null comment '备注',
    create_user bigint unsigned               null comment '创建人',
    created_at  datetime                      not null comment '创建时间',
    updated_at  datetime                      not null on update CURRENT_TIMESTAMP comment '修改时间',
    is_deleted  tinyint(1) unsigned default 0 not null comment '是否删除。'
)
    comment '账户管理员表' collate = utf8mb4_bin;

create table if not exists nc_wechat_content
(
    id         bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    third_id   bigint                        not null comment '第三方id',
    type       tinyint(1)                    not null comment '类型：1、模板消息。2、被动消息。',
    content    text charset utf8mb4          not null comment '提交到微信api-server的content',
    created_at datetime                      not null comment '创建时间',
    updated_at datetime                      null comment '修改时间',
    is_deleted tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '微信推送推送内容表' collate = utf8mb4_bin;

create table if not exists nc_wechat_template
(
    id             bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    third_id       bigint                        not null comment '对应的第三方账号id',
    notice_code    varchar(50)                   not null comment '对应通知中心对业务方唯一的code',
    template_id    varchar(100) charset utf8mb4  not null comment '对应的微信模板id',
    title          varchar(50) charset utf8mb4   null comment '标题（选填）',
    type           varchar(50)                   null comment '模板类型(选填)',
    wechat_content varchar(500)                  not null comment '微信原始模板信息',
    content        varchar(500)                  not null comment '模板内容，数组格式，存数组发送方无需关心key按顺序发送即可，例：[{"key":"","color":""}]。key对应微信模板关键字，必填。其他字段选填：包括：color等，详见微信开发文档。',
    url            varchar(100) charset utf8mb4  null comment '跳转链接',
    mini_app_id    varchar(50) charset utf8mb4   null comment '如果要跳转到小程序必填',
    mini_page_path varchar(50) charset utf8mb4   null comment '所需跳转到小程序的具体页面路径，支持带参数,（示例index?foo=bar），暂不支持小游戏',
    created_at     datetime                      not null comment '创建时间',
    updated_at     datetime                      null comment '修改时间',
    is_deleted     tinyint(1) unsigned default 0 not null comment '是否删除'
)
    comment '微信模板标' collate = utf8mb4_bin;

create index wechat_template_third_id
    on nc_wechat_template (third_id);

create table if not exists oem_activity_stock_log
(
    id           bigint auto_increment comment '日志id'
        constraint `PRIMARY`
        primary key,
    source       int           not null comment '原来数值',
    value        int           not null comment '库存改变值',
    creator_id   varchar(32)   null comment '创建人id',
    creator      varchar(32)   null comment '创建人名称',
    created_at   datetime      null comment '创建时间',
    updater_id   varchar(32)   null comment '更新人id',
    updater_name varchar(32)   null comment '更新人名称',
    updated_at   datetime      null comment '更新时间',
    del_flag     tinyint       null comment '是否删除',
    extra_json   varchar(1024) null comment '其他信息'
)
    comment 'OEM活动变更库存' charset = utf8;

create table if not exists quickbi_pagekeyandid_mapping
(
    id        bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    page_key  varchar(32) default '' not null comment 'QuickBi前端传递 page_key',
    page_id   varchar(64)            null,
    page_name varchar(32)            not null comment 'QuickBi page_name'
)
    comment 'QuickBi PageKey PageId映射表' collate = utf8mb4_unicode_ci;

create table if not exists risk_strategy
(
    id             bigint auto_increment comment '策略id'
        constraint `PRIMARY`
        primary key,
    name           varchar(64)   not null comment '策略名称',
    touch_scene    varchar(64)   not null comment '触发场景code',
    control_action text          not null comment '风控措施: (computeType : 0  等于,1  小于 ,2 大于,3 小于等于, 4 大于等于 ,5 A < X < B ,6 A <=X < B,7 A < X <=B, 8 A <=X <=B, 9 Like,10 不等于,11 is not null)',
    strategy_state tinyint       not null comment '状态:0草稿 1已启用 2已停用',
    create_id      varchar(32)   not null comment '创建者id',
    create_name    varchar(32)   not null comment '创建者名称',
    create_time    datetime      not null comment '创建时间',
    update_id      varchar(32)   not null comment '创建者id',
    update_name    varchar(32)   not null comment '更新者名称',
    update_time    datetime      not null comment '更新时间',
    del_flag       tinyint       not null comment '是否删除',
    extra_json     varchar(1024) null comment '其他信息'
)
    comment '风险识别策略表';

create table if not exists risk_strategy_action
(
    id           bigint auto_increment comment '措施id'
        constraint `PRIMARY`
        primary key,
    touch_scene  varchar(64)   not null comment '触发场景',
    action       varchar(64)   not null comment '风控措施',
    scene_code   varchar(64)   not null comment '触发场景code',
    action_code  varchar(64)   not null comment '风控措施code',
    creator_id   varchar(32)   null comment '创建人id',
    creator      varchar(32)   null comment '创建人名称',
    created_at   datetime      null comment '创建时间',
    updater_id   varchar(32)   null comment '更新人id',
    updater_name varchar(32)   null comment '更新人名称',
    updated_at   datetime      null comment '更新时间',
    del_flag     tinyint       null comment '是否删除',
    extra_json   varchar(1024) null comment '其他信息'
)
    comment '风险策略风控措施表';

create table if not exists risk_strategy_log
(
    id           bigint auto_increment comment '日志id'
        constraint `PRIMARY`
        primary key,
    mobile       varchar(32)             not null comment '手机号Md5',
    mobile_smk   varchar(128) default '' not null comment '手机号smk',
    result       text                    not null comment '结果',
    ip           varchar(32)             not null comment '真实ip',
    scene_code   varchar(64)             not null comment '触发场景code',
    action_code  varchar(64)             not null comment '风控措施code',
    creator_id   varchar(32)             null comment '创建人id',
    creator      varchar(32)             null comment '创建人名称',
    created_at   datetime                null comment '创建时间',
    updater_id   varchar(32)             null comment '更新人id',
    updater_name varchar(32)             null comment '更新人名称',
    updated_at   datetime                null comment '更新时间',
    del_flag     tinyint                 null comment '是否删除',
    extra_json   varchar(1024)           null comment '其他信息'
)
    comment '风险策略log表';

create table if not exists sms_black_and_white_list_config
(
    id         bigint auto_increment
        constraint `PRIMARY`
        primary key,
    num        varchar(20)                          not null comment '号码段',
    restricted varchar(20)                          null comment '限制功能 1：发送短信验证码 2：会员注册',
    type       tinyint                              not null comment '类型(1：黑名单,2：白名单)',
    created_by varchar(128)                         not null comment '创建人',
    created_at datetime   default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at datetime   default CURRENT_TIMESTAMP null comment '更新时间',
    updated_by varchar(128)                         null comment '更新人',
    delete_yn  tinyint(1) default 0                 not null comment '删除标记，0:未删除，1：已删除',
    constraint idx_list_num
        unique (num)
)
    charset = utf8;

create table if not exists sms_list_intercept_log
(
    id         bigint auto_increment
        constraint `PRIMARY`
        primary key,
    mobile     varchar(20)                        not null comment '手机号码',
    restricted varchar(20)                        null comment '拦截类型 1：发送短信验证码 2：会员注册',
    created_at datetime default CURRENT_TIMESTAMP not null comment '创建时间'
)
    charset = utf8;


