create table if not exists acl_app
(
    id          bigint unsigned auto_increment comment '主键id'
        constraint `PRIMARY`
        primary key,
    project_id  bigint                 not null comment '项目id',
    name        varchar(50) default '' not null comment 'app名称',
    `key`       varchar(50) default '' not null comment '项目下逻辑主键',
    `desc`      varchar(500)           null comment '描述',
    meta_data   varchar(1024)          null comment '元信息',
    created_at  datetime               not null,
    modified_at datetime               not null,
    deleted     tinyint(1)             not null comment '删除状态，如果存在逻辑删除的时候使用'
)
    comment '应用表';

create index CREATED_AT_INDEX
    on acl_app (created_at);

create index KEY_INDEX
    on acl_app (`key`);

create index PROJECT_ID_INDEX
    on acl_app (project_id);

create table if not exists acl_biz_object_config
(
    id                  bigint auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id           bigint               null comment '租户id',
    biz_id              varchar(128)         not null comment '业务对象id',
    permission_delegate tinyint(1) default 1 null comment '权限是否下放：0-不下放，1-下放',
    created_at          datetime             not null,
    updated_at          datetime             not null,
    constraint idx_biz_id
        unique (biz_id)
)
    charset = utf8;

create table if not exists acl_department
(
    id              bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    parent_id       bigint unsigned         not null comment '父部门编号',
    department_name varchar(255)            not null comment '部门名称',
    department_type varchar(10)             null comment '部门类型',
    source_type     varchar(64)             null comment '来源',
    created_id      varchar(30) default '0' null comment '创建人工号，0：系统',
    created_at      datetime                not null comment '创建时间',
    updated_id      varchar(30) default '0' null comment '修改人工号，0: 系统',
    updated_at      datetime                null comment '修改时间',
    delete_yn       tinyint(1)  default 0   not null comment '删除标记，0:未删除，1：已删除'
)
    comment '部门表';

create index acl_department_parent_id_idx
    on acl_department (parent_id);

create table if not exists acl_department_user_relation
(
    id            bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    department_id bigint                  not null comment '部门编号',
    user_id       bigint                  not null comment '用户id',
    created_id    varchar(30) default '0' null comment '创建人工号，0：系统',
    created_at    datetime                not null comment '创建时间',
    updated_id    varchar(30) default '0' null comment '修改人工号，0: 系统',
    updated_at    datetime                null comment '修改时间',
    delete_yn     tinyint(1)  default 0   not null comment '删除标记，0:未删除，1：已删除'
)
    comment '部门用户关联表';

create index acl_department_id_idx
    on acl_department_user_relation (department_id);

create index acl_user_id_idx
    on acl_department_user_relation (user_id);

create table if not exists acl_feature_group
(
    id          bigint unsigned auto_increment comment '主键id'
        constraint `PRIMARY`
        primary key,
    parent_id   bigint                                 null comment '父组ID',
    `key`       varchar(50)                            not null comment '节点标识',
    name        varchar(50) charset utf8mb4 default '' not null comment '功能权限组名称',
    project_id  bigint                                 not null comment '项目id',
    app_id      bigint                                 not null comment '应用id',
    created_at  datetime                               not null,
    modified_at datetime                               not null,
    deleted     tinyint(1)                             not null
)
    comment '功能组表' collate = utf8mb4_bin;

create index key_app_id
    on acl_feature_group (app_id);

create index key_parentid
    on acl_feature_group (parent_id);

create index key_project_id
    on acl_feature_group (project_id);

create table if not exists acl_feature_group_permission_rel
(
    id               bigint unsigned auto_increment comment '主键id'
        constraint `PRIMARY`
        primary key,
    feature_group_id bigint unsigned not null comment '功能分组id',
    permission_id    bigint unsigned not null comment '权限id',
    project_id       bigint unsigned not null comment '项目id',
    app_id           bigint unsigned not null comment '应用id',
    created_at       datetime        not null,
    modified_at      datetime        not null,
    deleted          tinyint(1)      not null
)
    comment '功能组与权限关系表' collate = utf8mb4_bin;

create table if not exists acl_permission
(
    id            bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id     bigint                         null,
    parent_id     bigint                         null,
    name          varchar(50)         default '' not null,
    `key`         varchar(128)        default '' not null,
    type          tinyint(1)                     not null comment '1-代表功能权限，2-代表数据权限',
    safe_level_id bigint                         null,
    `desc`        varchar(500)                   null,
    project_id    bigint                         not null,
    app_id        bigint unsigned                null,
    directed      tinyint(1) unsigned default 0  null comment '是否直接挂在app下',
    created_at    datetime                       not null,
    modified_at   datetime                       not null,
    deleted       tinyint(1)          default 0  not null,
    relation_ids  varchar(50)                    null comment '关联权限的id列表,json格式'
)
    comment '权限表';

create table if not exists acl_project
(
    id          bigint unsigned auto_increment comment '主键id'
        constraint `PRIMARY`
        primary key,
    tenant_id   bigint unsigned        not null comment '租户id',
    name        varchar(50) default '' not null comment '项目名称',
    `key`       varchar(50) default '' not null comment '逻辑主键',
    `desc`      varchar(500)           null comment '描述信息',
    sync_url    varchar(500)           null,
    create_user bigint                 not null comment '创建人',
    created_at  datetime               not null,
    modified_at datetime               not null,
    deleted     tinyint(1)             not null,
    constraint PROJECT_KEY_INDEX
        unique (tenant_id, `key`)
)
    comment '项目表';

create index CREATED_AT_INDEX
    on acl_project (created_at);

create table if not exists acl_role
(
    id              bigint unsigned auto_increment comment '主键id'
        constraint `PRIMARY`
        primary key,
    name            varchar(255) default '' not null comment '名称',
    hide            tinyint(1)              not null comment '是否隐藏， 0=正常，1=隐藏',
    tenant_id       bigint unsigned         not null comment '租户id',
    `key`           varchar(50)  default '' not null comment '逻辑主键',
    `desc`          varchar(500)            null comment '描述',
    project_id      bigint                  not null comment '应用id',
    app_id          bigint                  null comment '项目id',
    meta_data       varchar(1024)           null comment 'metadata',
    created_by      bigint                  null comment '创建人用户id',
    created_at      datetime                not null,
    modified_at     datetime                not null,
    deleted         tinyint                 not null,
    type_id         bigint                  null comment '角色类型id',
    limited         tinyint      default 0  null comment '是否限制适用范围',
    related_role_id bigint                  null comment '关联角色id，当通用角色第一次关联模板角色时获取模板角色当时拥有的所有权限'
)
    comment '角色表';

create index APP_ID_INDEX
    on acl_role (app_id);

create index CREATED_AT_INDEX
    on acl_role (created_at);

create index KEY_INDEX
    on acl_role (`key`);

create table if not exists acl_role_permission_authorization
(
    id              bigint auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    auth_type       tinyint(1) default 0 not null comment '0-正向授权，1-反向授权',
    permission_type tinyint(1)           not null comment '权限类型，对应权限表的功能权限类型和数据权限类型',
    permission_id   bigint               not null comment '权限id，包含功能权限和数据权限',
    role_id         bigint               not null comment '授权角色id，可以是虚拟角色或者实体角色',
    inherit         tinyint(1) default 0 null comment '权限是否可被继承，0-否，1-是',
    disable         tinyint(1) default 0 null comment '权限是否禁用，0-否，1-是',
    project_id      bigint               not null comment '授权项目id',
    tenant_id       bigint               null comment '租户id',
    permission_key  varchar(128)         null comment '权限key',
    permission_rule text                 null comment '数据权限约束',
    created_at      datetime             not null,
    modified_at     datetime             not null
)
    comment '角色授权的权限关系表';

create index ROLE_AUTH_PERMISSION_ID_INDEX
    on acl_role_permission_authorization (permission_id);

create index ROLE_AUTH_ROLE_ID_INDEX
    on acl_role_permission_authorization (role_id);

create table if not exists acl_role_relation
(
    id                  bigint unsigned auto_increment comment '主键id'
        constraint `PRIMARY`
        primary key,
    project_id          bigint unsigned     not null comment '项目id',
    role_id             bigint              not null comment '角色id',
    hide                tinyint(1) unsigned not null comment '是否隐藏',
    permission_delegate tinyint(1)          null comment '下放权限',
    rule_id             bigint              null comment '下放规则',
    biz_id              varchar(128)        not null comment '业务对象id',
    created_at          datetime            not null,
    modified_at         datetime            not null
)
    comment '角色关系表';

create index ROLE_ID_INDEX
    on acl_role_relation (role_id);

create index idx_biz_id_biz_type
    on acl_role_relation (biz_id);

create table if not exists acl_sequence
(
    id         bigint auto_increment
        constraint `PRIMARY`
        primary key,
    max_id     bigint      not null,
    role       varchar(64) not null,
    updated_at datetime    null,
    created_at datetime    null
)
    charset = utf8;

create table if not exists acl_tree
(
    id               bigint unsigned auto_increment comment '维度id'
        constraint `PRIMARY`
        primary key,
    name             varchar(255) default '' not null comment '名称',
    `key`            varchar(50)  default '' not null comment '逻辑主键',
    is_default       tinyint(1)   default 0  not null comment '1 - 默认， 0-非默认',
    `desc`           varchar(128)            null comment '说明',
    tenant_id        bigint                  not null comment '租户id',
    meta_data        varchar(2048)           null comment '元信息',
    last_change_time datetime                null comment '上次变更时间',
    last_sync_time   datetime                null comment '上次同步时间',
    created_at       datetime                not null,
    updated_at       datetime                not null
)
    comment '对象树维度表';

create index CREATED_AT_INDEX
    on acl_tree (created_at);

create index KEY_INDEX
    on acl_tree (`key`);

create table if not exists acl_tree_node
(
    id                  bigint auto_increment
        constraint `PRIMARY`
        primary key,
    `key`               bigint               not null comment '逻辑主键',
    tenant_id           bigint               null comment '租户id',
    biz_id              varchar(128)         not null comment '业务对象id',
    biz_name            varchar(256)         not null comment '业务对象名称',
    biz_type            varchar(64)          null comment '业务对象类型',
    biz_type_name       varchar(128)         null comment '业务对象类型名称',
    dimension_key       varchar(50)          not null comment '权限树维度',
    full_path           varchar(512)         not null comment '父节点全路径',
    permission_delegate tinyint(1) default 0 null comment '（弃用）权限是否下放：0-不下放，1-下放',
    mobile              varchar(20)          null comment '手机号',
    is_user_node        tinyint(1)           not null comment '是否用户节点 0-不是，1-是',
    created_at          datetime             not null,
    updated_at          datetime             not null
)
    charset = utf8;

create index idx_biz_id
    on acl_tree_node (biz_id);

create index idx_biz_type
    on acl_tree_node (biz_type);

create index idx_key
    on acl_tree_node (`key`);

create table if not exists acl_user_info
(
    id         bigint auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id  bigint       null comment '租户id',
    user_id    varchar(128) not null comment '业务对象id',
    user_name  varchar(128) not null comment '业务对象名称',
    mobile     varchar(20)  not null comment '手机号',
    created_at datetime     not null,
    updated_at datetime     not null,
    constraint idx_tenant_id_user_id
        unique (tenant_id, user_id)
)
    charset = utf8;

create index idx_mobile
    on acl_user_info (mobile);

create index idx_user_name
    on acl_user_info (user_name);


