create table if not exists tb_address_master_data
(
    id          bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    parent_code bigint       null comment '父编码',
    area_code   bigint       not null comment '地域编码',
    area_name   varchar(255) not null comment '地域名称',
    level       tinyint(10)  not null comment '地域类型',
    create_at   datetime     null comment '创建时间',
    update_at   datetime     null comment '更新时间',
    delete_yn   tinyint      null comment '删除标识  0：未删除 1：已删除'
)
    charset = utf8;

create table if not exists tb_car_data
(
    id          bigint unsigned auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    parent_code bigint       null comment '父编码',
    name        varchar(255) not null comment '名称',
    type        tinyint      not null comment '类型1:车辆类型2：品牌3：车型 4：排量5：年份',
    create_at   datetime     null comment '创建时间',
    update_at   datetime     null comment '更新时间',
    delete_yn   tinyint      null comment '删除标识  0：未删除 1：已删除'
)
    charset = utf8;

create table if not exists uc_client_details
(
    id                             bigint auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    user_id                        bigint               null comment '创建的用户id',
    client_id                      varchar(255)         null comment 'clientID',
    client_name                    varchar(255)         null comment 'client名称',
    client_secret                  varchar(255)         null comment 'client密钥',
    access_token_validity          varchar(255)         null comment 'access token 校验',
    access_token_validity_seconds  int                  null comment 'access token 过期时长',
    additional_information         varchar(255)         null comment '额外信息',
    authorities                    varchar(255)         null comment '权限',
    authorized_grant_types         varchar(255)         null comment '授权方式',
    auto_approve_scopes            varchar(255)         null comment '自动核准作用域',
    refresh_token_validity         varchar(255)         null comment 'refresh token 校验',
    refresh_token_validity_seconds int                  null comment 'refresh token 过期时长',
    registered_redirect_uris       varchar(2048)        null comment '注册的重定向地址',
    resource_ids                   varchar(255)         null comment '资源信息的id',
    scope                          varchar(255)         null comment '可使用资源域',
    enabled                        tinyint(1) default 1 not null comment '是否启用',
    deleted                        tinyint(1) default 0 not null comment '逻辑删除delete flag (0:not,1:yes)',
    created_at                     datetime             not null comment '创建时间',
    updated_at                     datetime             null comment '更新时间'
);

create table if not exists uc_setting_properties
(
    id          int(11) unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    setting_key varchar(128) default '' not null comment '生效setting key，用于指定 properties 关联到哪个setting上面',
    properties  varchar(2048)           null comment '具体属性值',
    created_at  datetime                null comment '创建时间',
    updated_at  datetime                null comment '更新时间',
    constraint UN_INDEX_SETTING_KEY
        unique (setting_key)
);

create table if not exists uc_user
(
    id            bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id     int(20)                   not null comment '租户ID',
    username      varchar(128)              not null comment '用户名',
    nickname      varchar(128)              null,
    avatar        varchar(255)              null comment '头像',
    mobile        varchar(128) charset utf8 null comment '手机号',
    email         varchar(128)              null comment '邮箱',
    password      varchar(128) charset utf8 null comment '密码',
    pwd_expire_at date                      null comment '密码过期时间',
    enabled       tinyint(1) default 1      not null comment '是否启用',
    locked        tinyint(1) default 0      not null comment '是否冻结',
    deleted       tinyint(1) default 0      not null comment '逻辑删除delete flag (0:not,1:yes)',
    channel       varchar(128)              null comment '注册渠道',
    channel_type  varchar(64)               null comment '渠道类型',
    source        varchar(128)              null comment '用户来源',
    source_type   varchar(64)               null comment '来源类型',
    tag           varchar(128)              null comment '标签',
    version       int                       null comment '版本',
    extra         varchar(512)              null comment '扩展字段',
    updated_by    varchar(128)              null comment '更新人，操作日志',
    created_at    datetime                  not null comment '创建时间',
    updated_at    datetime                  null comment '更新时间',
    last_login_at datetime                  null comment '最后登录时间',
    constraint uni_email
        unique (email, tenant_id),
    constraint uni_mobile
        unique (mobile, tenant_id),
    constraint uni_username
        unique (username, tenant_id)
)
    comment '用户表';

create table if not exists uc_user_composite_task
(
    id            bigint auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    target_id     bigint            not null comment '目标ID',
    task_type     int(4)            not null comment '任务类型 0:tmall会员同步',
    task_status   int(4)            not null comment '任务状态 0:待处理 1:进行中 2:失败 3:成功',
    retry_count   int(10) default 0 not null comment '重试次数',
    extra_json    varchar(512)      null comment '任务额外任务额外信息',
    create_at     datetime          null comment '创建时间',
    update_at     datetime          null comment '更新时间',
    notice_status int(4)            not null comment '通知状态 0:未通知,1:通知',
    constraint target_id_type_unique
        unique (target_id, task_type)
)
    comment '补偿任务表' charset = utf8;

create table if not exists uc_user_copy1
(
    id            bigint auto_increment comment 'id'
        constraint `PRIMARY`
        primary key,
    tenant_id     int(20)                   not null comment '租户ID',
    username      varchar(128)              not null comment '用户名',
    nickname      varchar(128)              null,
    avatar        varchar(255)              null comment '头像',
    mobile        varchar(128) charset utf8 null comment '手机号',
    email         varchar(128)              null comment '邮箱',
    password      varchar(128) charset utf8 null comment '密码',
    pwd_expire_at date                      null comment '密码过期时间',
    enabled       tinyint(1) default 1      not null comment '是否启用',
    locked        tinyint(1) default 0      not null comment '是否冻结',
    deleted       tinyint(1) default 0      not null comment '逻辑删除delete flag (0:not,1:yes)',
    channel       varchar(128)              null comment '注册渠道',
    channel_type  varchar(64)               null comment '渠道类型',
    source        varchar(128)              null comment '用户来源',
    source_type   varchar(64)               null comment '来源类型',
    tag           varchar(128)              null comment '标签',
    version       int                       null comment '版本',
    extra         varchar(512)              null comment '扩展字段',
    updated_by    varchar(128)              null comment '更新人，操作日志',
    created_at    datetime                  not null comment '创建时间',
    updated_at    datetime                  null comment '更新时间',
    last_login_at datetime                  null comment '最后登录时间',
    constraint uni_email
        unique (email, tenant_id),
    constraint uni_mobile
        unique (mobile, tenant_id),
    constraint uni_username
        unique (username, tenant_id)
)
    comment '用户表';

create table if not exists uc_user_detail
(
    user_id bigint        not null comment '用户ID',
    info    varchar(2048) null comment '用户JSON信息',
    constraint `PRIMARY`
        primary key (user_id)
)
    comment '用户信息表';

create table if not exists uc_user_event_log
(
    id          bigint auto_increment
        constraint `PRIMARY`
        primary key,
    user_id     bigint       null,
    event_type  varchar(32)  null,
    event       varchar(512) null,
    event_time  datetime     null,
    mac_address varchar(128) null,
    ip          varchar(64)  null,
    extra       text         null,
    created_at  datetime     null,
    updated_at  datetime     null comment '更新时间'
)
    comment '用户事件日志表';

create index idx_user_id_event_type
    on uc_user_event_log (user_id, event_type);

create table if not exists uc_user_third_account
(
    id                 bigint auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    user_id            bigint                             not null comment '用户ID',
    account_id         varchar(255)                       null comment '三方账户ID',
    account_name       varchar(255)                       null comment '第三方账户名',
    account_type       varchar(255)                       null comment '第三方账户类型：QQ、WECHAT、WECHAT-MP、WEIBO',
    app_id             varchar(255)                       null,
    open_id            varchar(64)                        null comment 'OPEN ID',
    union_id           varchar(255)                       null comment 'unionid',
    extra              varchar(2048)                      null comment '扩展JSON字段',
    created_at         datetime                           not null comment '创建时间',
    updated_at         datetime                           null comment '更新时间',
    dl_auto_created_at datetime default CURRENT_TIMESTAMP not null comment '数据入湖时间',
    dl_auto_updated_at datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '数据更新时间'
)
    comment '第三方账户' collate = utf8mb4_bin;

create index index_name
    on uc_user_third_account (user_id, account_id, account_type, app_id, open_id);

create table if not exists uc_user_third_account_operate
(
    id                 bigint auto_increment comment '主键'
        constraint `PRIMARY`
        primary key,
    type               int(4)                             not null comment '绑定类型 0-绑定 1-解绑 2-注销',
    user_id            bigint                             not null comment '用户ID',
    account_id         varchar(255)                       null comment '三方账户ID',
    account_name       varchar(255)                       null comment '第三方账户名',
    account_type       varchar(255)                       null comment '第三方账户类型：QQ、WECHAT、WECHAT-MP、WEIBO',
    app_id             varchar(255)                       null,
    open_id            varchar(64)                        null comment 'OPEN ID',
    union_id           varchar(255)                       null comment 'unionid',
    extra              varchar(2048)                      null comment '扩展JSON字段',
    created_at         datetime                           not null comment '创建时间',
    updated_at         datetime                           null comment '更新时间',
    dl_auto_created_at datetime default CURRENT_TIMESTAMP not null comment '数据入湖时间',
    dl_auto_updated_at datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '数据更新时间',
    operate_at         datetime                           not null comment '操作时间'
)
    comment '第三方账户' collate = utf8mb4_bin;

create index index_name
    on uc_user_third_account_operate (user_id, account_id, account_type, app_id, open_id);


