create table if not exists batch_job_execution_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
);

create table if not exists batch_job_instance
(
    JOB_INSTANCE_ID bigint       not null,
    VERSION         bigint       null,
    JOB_NAME        varchar(100) not null,
    JOB_KEY         varchar(32)  not null,
    constraint `PRIMARY`
        primary key (JOB_INSTANCE_ID),
    constraint JOB_INST_UN
        unique (JOB_NAME, JOB_KEY)
);

create table if not exists batch_job_execution
(
    JOB_EXECUTION_ID           bigint        not null,
    VERSION                    bigint        null,
    JOB_INSTANCE_ID            bigint        not null,
    CREATE_TIME                datetime      not null,
    START_TIME                 datetime      null,
    END_TIME                   datetime      null,
    STATUS                     varchar(10)   null,
    EXIT_CODE                  varchar(2500) null,
    EXIT_MESSAGE               varchar(2500) null,
    LAST_UPDATED               datetime      null,
    JOB_CONFIGURATION_LOCATION varchar(2500) null,
    constraint `PRIMARY`
        primary key (JOB_EXECUTION_ID),
    constraint JOB_INST_EXEC_FK
        foreign key (JOB_INSTANCE_ID) references batch_job_instance (JOB_INSTANCE_ID)
);

create table if not exists batch_job_execution_context
(
    JOB_EXECUTION_ID   bigint        not null,
    SHORT_CONTEXT      varchar(2500) not null,
    SERIALIZED_CONTEXT text          null,
    constraint `PRIMARY`
        primary key (JOB_EXECUTION_ID),
    constraint JOB_EXEC_CTX_FK
        foreign key (JOB_EXECUTION_ID) references batch_job_execution (JOB_EXECUTION_ID)
);

create table if not exists batch_job_execution_params
(
    JOB_EXECUTION_ID bigint       not null,
    TYPE_CD          varchar(6)   not null,
    KEY_NAME         varchar(100) not null,
    STRING_VAL       varchar(250) null,
    DATE_VAL         datetime     null,
    LONG_VAL         bigint       null,
    DOUBLE_VAL       double       null,
    IDENTIFYING      char         not null,
    constraint JOB_EXEC_PARAMS_FK
        foreign key (JOB_EXECUTION_ID) references batch_job_execution (JOB_EXECUTION_ID)
);

create table if not exists batch_job_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
);

create table if not exists batch_step_execution
(
    STEP_EXECUTION_ID  bigint        not null,
    VERSION            bigint        not null,
    STEP_NAME          varchar(100)  not null,
    JOB_EXECUTION_ID   bigint        not null,
    START_TIME         datetime      not null,
    END_TIME           datetime      null,
    STATUS             varchar(10)   null,
    COMMIT_COUNT       bigint        null,
    READ_COUNT         bigint        null,
    FILTER_COUNT       bigint        null,
    WRITE_COUNT        bigint        null,
    READ_SKIP_COUNT    bigint        null,
    WRITE_SKIP_COUNT   bigint        null,
    PROCESS_SKIP_COUNT bigint        null,
    ROLLBACK_COUNT     bigint        null,
    EXIT_CODE          varchar(2500) null,
    EXIT_MESSAGE       varchar(2500) null,
    LAST_UPDATED       datetime      null,
    constraint `PRIMARY`
        primary key (STEP_EXECUTION_ID),
    constraint JOB_EXEC_STEP_FK
        foreign key (JOB_EXECUTION_ID) references batch_job_execution (JOB_EXECUTION_ID)
);

create table if not exists batch_step_execution_context
(
    STEP_EXECUTION_ID  bigint        not null,
    SHORT_CONTEXT      varchar(2500) not null,
    SERIALIZED_CONTEXT text          null,
    constraint `PRIMARY`
        primary key (STEP_EXECUTION_ID),
    constraint STEP_EXEC_CTX_FK
        foreign key (STEP_EXECUTION_ID) references batch_step_execution (STEP_EXECUTION_ID)
);

create table if not exists batch_step_execution_seq
(
    ID         bigint not null,
    UNIQUE_KEY char   not null,
    constraint UNIQUE_KEY_UN
        unique (UNIQUE_KEY)
);

create table if not exists test_virgo_create
(
    dl_auto_created_at datetime default CURRENT_TIMESTAMP not null comment '数据入湖时间',
    dl_auto_updated_at datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '数据更新时间'
);

create table if not exists test_virgo_create2
(
    dl_auto_created_at datetime default CURRENT_TIMESTAMP not null comment '数据入湖时间',
    dl_auto_updated_at datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '数据更新时间'
);

create table if not exists virgo_accounts
(
    id               bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id        bigint                                                         not null comment '租户ID',
    gl_code          varchar(16)                                                    not null comment '科目',
    gl_name          varchar(200)                                                   null comment '科目名称',
    owner_id         varchar(32) collate utf8_estonian_ci default ''                not null comment '所属者id',
    amount           bigint                               default 0                 not null comment '账户余额',
    frozen_amount    bigint                               default 0                 not null comment '冻结的余额',
    status           varchar(16)                                                    not null comment 'NORMAL:正常, FROZEN:冻结',
    amount_change_at datetime                             default CURRENT_TIMESTAMP not null comment '余额最近变动时间(日切使用)',
    ext1             text                                                           null comment '扩展字段1',
    ext2             text                                                           null comment '扩展字段2',
    ext3             text                                                           null comment '扩展字段3',
    extra_json       varchar(1024)                                                  null comment '扩展json字段',
    created_at       datetime                             default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at       datetime                             default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    withhold_amount  bigint                               default 0                 not null comment '预扣的余额',
    constraint idx_virgo_vfa_unique_member_code
        unique (owner_id, gl_code)
)
    charset = utf8;

create index index_owner_id
    on virgo_accounts (owner_id);

create table if not exists virgo_accounts_cancel
(
    id               bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    account_id       bigint                                                         not null comment '账户ID',
    tenant_id        bigint                                                         not null comment '租户ID',
    gl_code          varchar(16)                                                    not null comment '科目',
    owner_id         varchar(32) collate utf8_estonian_ci default ''                not null comment '所属者id',
    amount           bigint                               default 0                 not null comment '账户余额',
    frozen_amount    bigint                               default 0                 not null comment '冻结的余额',
    status           varchar(16)                                                    not null comment 'NORMAL:正常, FROZEN:冻结',
    withhold_amount  bigint                               default 0                 not null comment '预扣的余额',
    amount_change_at datetime                             default CURRENT_TIMESTAMP not null comment '余额最近变动时间(日切使用)',
    ext1             text                                                           null comment '扩展字段1',
    ext2             text                                                           null comment '扩展字段2',
    ext3             text                                                           null comment '扩展字段3',
    extra_json       varchar(1024)                                                  null comment '扩展json字段',
    created_at       datetime                             default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at       datetime                             default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    charset = utf8;

create index index_account
    on virgo_accounts_cancel (account_id);

create index index_ower_id
    on virgo_accounts_cancel (owner_id);

create table if not exists virgo_accounts_cancel_copy1
(
    id               bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    account_id       bigint                                                         not null comment '账户ID',
    tenant_id        bigint                                                         not null comment '租户ID',
    gl_code          varchar(16)                                                    not null comment '科目',
    owner_id         varchar(32) collate utf8_estonian_ci default ''                not null comment '所属者id',
    amount           bigint                               default 0                 not null comment '账户余额',
    frozen_amount    bigint                               default 0                 not null comment '冻结的余额',
    status           varchar(16)                                                    not null comment 'NORMAL:正常, FROZEN:冻结',
    withhold_amount  bigint                               default 0                 not null comment '预扣的余额',
    amount_change_at datetime                             default CURRENT_TIMESTAMP not null comment '余额最近变动时间(日切使用)',
    ext1             text                                                           null comment '扩展字段1',
    ext2             text                                                           null comment '扩展字段2',
    ext3             text                                                           null comment '扩展字段3',
    extra_json       varchar(1024)                                                  null comment '扩展json字段',
    created_at       datetime                             default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at       datetime                             default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    charset = utf8;

create index index_account
    on virgo_accounts_cancel_copy1 (account_id);

create index index_ower_id
    on virgo_accounts_cancel_copy1 (owner_id);

create table if not exists virgo_accounts_snapshot
(
    id               bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    trans_id         varchar(20)                                                    not null comment '交易流水ID',
    account_id       bigint                                                         not null comment '账户ID',
    tenant_id        bigint                                                         not null comment '租户ID',
    gl_code          varchar(16)                                                    not null comment '科目',
    owner_id         varchar(32) collate utf8_estonian_ci default ''                not null comment '所属者id',
    amount           bigint                               default 0                 not null comment '账户余额',
    frozen_amount    bigint                               default 0                 not null comment '冻结的余额',
    status           varchar(16)                                                    not null comment 'NORMAL:正常, FROZEN:冻结',
    amount_change_at datetime                             default CURRENT_TIMESTAMP not null comment '余额最近变动时间(日切使用)',
    ext1             text                                                           null comment '扩展字段1',
    ext2             text                                                           null comment '扩展字段2',
    ext3             text                                                           null comment '扩展字段3',
    extra_json       varchar(1024)                                                  null comment '扩展json字段',
    created_at       datetime                             default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at       datetime                             default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    charset = utf8;

create index index_account
    on virgo_accounts_snapshot (account_id);

create index index_trans
    on virgo_accounts_snapshot (trans_id);

create table if not exists virgo_action_divide_cfg
(
    id            bigint auto_increment
        constraint `PRIMARY`
        primary key,
    type          varchar(256) default '0'               null comment '类型',
    channel       varchar(32)  default ''                not null,
    cost_rule_exp varchar(1024)                          null comment '成本分摊比例json表达式',
    created_at    datetime     default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at    datetime     default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by    varchar(128)                           null comment '更新人',
    created_by    varchar(128)                           null comment '创建人'
)
    comment '活动分摊默认配置表' charset = utf8;

create table if not exists virgo_activity
(
    id                  bigint auto_increment
        constraint `PRIMARY`
        primary key,
    activity_name       varchar(256)                          not null comment '活动名称',
    activity_factor     smallint(8) default 100               not null comment '固定活动倍率',
    channel_factor      smallint(8) default 100               not null comment '渠道积分倍率',
    activity_started_at datetime                              null comment '活动开始时间',
    activity_ended_at   datetime                              null comment '活动结束时间',
    channel             varchar(32) default ''                not null,
    status              varchar(16)                           not null comment 'DRAFT：草稿 ,ENABLED:启用, DISABLED:停用,OVERDUE：失效',
    ext1                text                                  null comment '扩展字段1',
    ext2                text                                  null comment '扩展字段2',
    ext3                text                                  null comment '扩展字段3',
    extra_json          text                                  null comment '扩展json字段',
    remark              varchar(1024)                         null comment '活动说明',
    created_by          varchar(128)                          null comment '更新人',
    created_at          datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at          datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by          varchar(128)                          null comment '更新人',
    type                tinyint     default 0                 not null comment '活动类型 0：商城活动 1：生日礼遇',
    cost_rule_exp       varchar(1024)                         null comment '成本分摊比例json表达式',
    flow_id             varchar(63)                           null comment '流程实例id',
    audit_status        varchar(31)                           null comment '审批状态'
)
    charset = utf8;

create table if not exists virgo_batch_modify_point
(
    id           bigint auto_increment
        constraint `PRIMARY`
        primary key,
    file_name    varchar(256)                          not null comment '文件名称',
    flow_id      varchar(64) default ''                null comment '审批节点',
    audit_status varchar(32) default ''                null comment '审批状态 WAITING-待审SUCCESS-审核成功，\n\nFAILED-审核不通过',
    file_url     varchar(512)                          null comment '文件地址',
    remark       varchar(1024)                         null comment '调整原因说明',
    data         text                                  null comment '导入数据JSON',
    result       text                                  null comment '导入结果JSON',
    auditd_at    datetime                              null comment '审批时间',
    created_by   varchar(128)                          null comment '更新人',
    created_at   datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at   datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by   varchar(128)                          null comment '更新人'
)
    charset = utf8;

create table if not exists virgo_budget
(
    id                  bigint auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id           bigint                             not null comment '租户ID',
    name                varchar(255)                       not null comment '预算名称',
    platform_code       varchar(255)                       not null comment '平台编码',
    gl_code             varchar(255)                       not null comment '科目',
    budget_total_amount bigint   default 0                 not null comment '预算总额',
    budget_used         bigint   default 0                 not null comment '已用预算',
    budget_available    bigint   default 0                 not null comment '可用预算额度，总额*阀值/100 - 已用',
    status              varchar(32)                        not null comment 'DISABLE:活动停用，ENABLE:活动启用，EXPIRED:活动过期',
    threshold_number    bigint   default 0                 not null comment '预算阀值',
    started_at          datetime                           null comment '预算开始时间',
    ended_at            datetime                           null comment '预算截止时间',
    ext1                text                               null comment '预留字段1',
    ext2                text                               null comment '预留字段2  清零规则:RESET',
    ext3                text                               null comment '预留字段3',
    extra_json          text                               null comment '扩展json字段',
    created_at          datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at          datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by          varchar(128)                       null comment '更新人'
)
    charset = utf8;

create index idx_virgo_budget_created
    on virgo_budget (created_at);

create table if not exists virgo_budget_trans
(
    id            bigint auto_increment
        constraint `PRIMARY`
        primary key,
    gl_code       varchar(16)                        not null comment '科目',
    platform_code varchar(255)                       not null comment '平台编码',
    budget_id     bigint                             not null comment '预算池ID',
    trade_no      varchar(32)                        not null comment '关联的交易流水号',
    change_amount bigint   default 0                 not null comment '变更金额',
    operate_type  varchar(64)                        not null comment 'UP(增加）, DOWN(减少)',
    status        varchar(32)                        not null comment 'DISABLE:活动停用，ENABLE:活动启用',
    reason        varchar(256)                       null comment '预算变更原因',
    started_at    datetime                           null comment '开始时间',
    ended_at      datetime                           null comment '结束时间',
    created_at    datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at    datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by    varchar(255)                       null comment '更新人'
)
    charset = utf8;

create table if not exists virgo_circulate_rules
(
    id                 bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id          bigint                                not null comment '租户ID',
    gl_code            varchar(32)                           not null comment '科目编码',
    target_gl_code     varchar(32)                           not null comment '来源',
    exchange_ratio     bigint                                not null comment '科目兑换系数',
    exchange_unit      bigint                                not null comment '科目固定兑换单位',
    min_exchange_value text                                  not null comment '科目最小起兑值',
    max_exchange_value text                                  not null comment '科目最大起兑值',
    status             varchar(16) default 'ENABLED'         not null comment '状态',
    created_at         datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at         datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by         varchar(128)                          null comment '操作人信息',
    constraint idx_uni_tgt
        unique (tenant_id, gl_code, target_gl_code)
)
    comment '会员积分通兑规则' charset = utf8;

create table if not exists virgo_compensate_biz
(
    id            bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    description   text                               null comment '业务描述',
    method_name   varchar(64)                        not null comment '方法名',
    method_params text                               null comment '参数',
    class_name    varchar(64)                        not null comment '类全限定名',
    status        varchar(32)                        not null comment '状态',
    fail_count    tinyint  default 0                 null comment '失败次数',
    priority      tinyint                            null comment '优先级',
    failed_reason text                               null comment '上次失败原因',
    created_at    datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at    datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    comment '业务补偿表' charset = utf8;

create table if not exists virgo_exchange_rules
(
    id                 bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id          bigint                                not null comment '租户ID',
    gl_code            varchar(32)                           not null comment '科目编码',
    source             varchar(32)                           not null comment '来源',
    source_type        tinyint                               not null comment '来源类型',
    exchange_ratio     bigint                                not null comment '积分兑换系数（万分之一）',
    exchange_unit      bigint                                not null comment '积分固定兑换单位',
    min_exchange_value text                                  not null comment '积分最小起兑值',
    max_exchange_value text                                  not null comment '积分最大起兑值',
    status             varchar(16) default 'ENABLED'         not null comment '状态',
    is_default         tinyint     default 0                 not null comment '是否默认 0:否  1:是',
    created_at         datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at         datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by         varchar(128)                          null comment '操作人信息',
    constraint idx_uni_tgt
        unique (tenant_id, gl_code)
)
    comment '会员积分兑换规则' charset = utf8;

create table if not exists virgo_gl_codes
(
    id          bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id   bigint                             not null comment '租户ID',
    name        varchar(32)                        not null comment '账户定义名称',
    code        varchar(16)                        not null comment '编码(10000/11000)',
    application varchar(16)                        not null comment '应用',
    description varchar(32)                        not null comment '科目描述',
    properties  text                               null comment '配置',
    extra_json  text                               null comment '扩展json字段',
    ext1        text                               null comment '扩展字段1',
    ext2        text                               null comment '扩展字段2',
    ext3        text                               null comment '扩展字段3',
    created_at  datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at  datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by  varchar(128)                       null comment '更新人'
)
    comment '账户科目' charset = utf8;

create index idx_virgo_vagc_code_unq
    on virgo_gl_codes (tenant_id, code);

create table if not exists virgo_message
(
    id         bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    type       varchar(32)                            not null comment 'INSIDE:内部处理消息, OUTSIDE:外部处理消息',
    topic      varchar(64)  default ''                not null comment '消息topic',
    tag        varchar(64)                            null comment '消息tag',
    trade_no   varchar(20)  default ''                not null comment '交易流水号',
    trans_type varchar(64)  default ''                not null comment '交易类型',
    context    longtext                               not null comment '明细内容',
    msg_id     varchar(128) default ''                null comment '消息id',
    status     varchar(32)  default ''                not null comment 'DONE:执行成功，FAIL:处理失败, INIT:初始化, PROCESSING:处理中',
    created_at datetime     default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at datetime     default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by varchar(128)                           null comment '操作人信息',
    constraint idx_msg_id
        unique (msg_id),
    constraint idx_trade_no
        unique (trade_no)
);

create table if not exists virgo_reconcile
(
    id             bigint auto_increment
        constraint `PRIMARY`
        primary key,
    account_id     bigint                             not null comment '账户ID',
    last_amount    bigint                             null comment '上次平帐金额',
    current_amount bigint                             null comment '本次平帐金额',
    recon_amount   bigint                             null comment '今日计算变更金额',
    gap_amount     bigint                             null comment '平帐与账户变更差额',
    result         varchar(2048)                      null comment '平账结果',
    status         varchar(32)                        not null comment '平帐结果 SUCCESS:相等成功，FAIL:失败',
    created_at     datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at     datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    charset = utf8;

create index idx_virgo_reconcile_created
    on virgo_reconcile (created_at);

create index index_account
    on virgo_reconcile (account_id);

create table if not exists virgo_reconcile_trans
(
    id            bigint auto_increment
        constraint `PRIMARY`
        primary key,
    account_id    bigint                             null comment '账户',
    operate_type  varchar(64)                        null comment '操作类型',
    change_amount bigint                             null comment '变更金额',
    status        varchar(64)                        null comment '状态，未处理INIT，已处理 DONE',
    created_at    datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at    datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    charset = utf8;

create table if not exists virgo_settle_center_config
(
    id         bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    proportion varchar(32)                        null comment '业务方预期比例（1-100）',
    gl_code    varchar(32)                        not null comment '积分账户，10000为礼享 20000为臻选',
    cpp        varchar(32)                        not null comment '每积分消耗RMB',
    remark     varchar(1024)                      null comment '说明',
    created_by varchar(128)                       null comment '更新人',
    created_at datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by varchar(128)                       null comment '更新人'
)
    charset = utf8;

create table if not exists virgo_settle_company_config
(
    id            bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    promit_center varchar(32)                        not null comment '707807',
    company_code  varchar(32)                        not null comment '公司code',
    dine_code     varchar(32)                        not null comment 'dineCode',
    name          varchar(32)                        not null comment 'EMCH/EMCSS',
    ratio         varchar(32)                        not null comment '分摊比例',
    company_type  tinyint                            not null comment '1：负债公司 2：应付公司 3：总公司',
    created_by    varchar(128)                       null comment '更新人',
    created_at    datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at    datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by    varchar(128)                       null comment '更新人'
)
    charset = utf8;

create table if not exists virgo_settle_o2o_summary
(
    id                  bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    gl_code             varchar(32)                        not null comment '积分账户，10000为礼享 20000为臻选',
    channel             varchar(32)                        not null comment '渠道',
    type                varchar(32)                        null comment '类型',
    previous_balance    varchar(32)                        null comment '上月余额',
    newly_earned_points varchar(32)                        null comment '本月新增',
    redeemed_points     varchar(32)                        null comment '本月使用',
    point_settled       varchar(32)                        null comment '本月结算',
    epxpired_points     varchar(32)                        null comment '本月过期',
    projected_rate      varchar(32)                        null comment '预期比例',
    remaining_balance   varchar(32)                        null comment '账户剩余',
    ulp_cpp             varchar(32)                        null,
    cpp                 varchar(32)                        null,
    liablity_channel    varchar(32)                        null,
    liablity_rmb        varchar(32)                        null comment '不含税rmb',
    liablity_rmb_vat    varchar(32)                        null comment '含税rmb',
    month               varchar(6)                         not null comment '结算周期',
    level               int                                null comment '排序权重',
    created_by          varchar(128)                       null comment '更新人',
    created_at          datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at          datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by          varchar(128)                       null comment '更新人'
)
    comment 'o2o结算一览表' charset = utf8;

create table if not exists virgo_settle_sku
(
    id               bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    sku_id           varchar(32)                           not null comment 'skuid',
    sku_name         varchar(32)                           not null comment 'skuid',
    category         varchar(32)                           null comment 'sku类型',
    gl_code          varchar(32)                           not null comment '积分账户，10000为礼享 20000为臻选',
    channel          varchar(32)                           not null comment '渠道',
    unit_points      varchar(32)                           null comment '积分单价',
    unit_price       varchar(32)                           null comment '商品单价(不含税)',
    vat              varchar(32)                           null comment '税率',
    num              varchar(32)                           null comment '兑换数量',
    settle_num       varchar(32)                           null comment '结算数量',
    cost_points      varchar(32)                           null comment '消耗积分',
    settle_points    varchar(32)                           null comment '结算积分',
    settle_price     varchar(32)                           null comment '结算价格(不含税)',
    settle_price_vat varchar(32)                           null comment '结算价格(含税)',
    vendor_code      varchar(32) default '0'               not null comment '供应商编码',
    vendor           varchar(32) default '0'               not null comment '供应商名称',
    month            varchar(6)                            not null comment '结算周期',
    created_by       varchar(128)                          null comment '更新人',
    created_at       datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at       datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by       varchar(128)                          null comment '更新人',
    benefit_id       bigint                                null comment '权益id',
    sku_info         varchar(255)                          null comment 'eg: [1_0.1,2_0.2,3_3.0]
1、2: 商品
3 :优惠券
商品成本: 0.1 + 0.2 = 0.3
优惠卷成本: 3.0eg: [1_0.1,2_0.2,3_3.0]
1、2: 商品
3 :优惠券
商品成本: 0.1 + 0.2 = 0.3
优惠卷成本: 3.0
',
    order_code       varchar(255)                          null comment '订单号'
)
    comment 'sku结算表' charset = utf8;

create index index_order_code
    on virgo_settle_sku (order_code);

create index index_sku
    on virgo_settle_sku (sku_id, category);

create table if not exists virgo_settle_sku_info
(
    id               bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    sku_id           varchar(32)                           not null comment 'skuid',
    sku_name         varchar(32)                           not null comment 'skuid',
    category         varchar(32)                           null comment 'sku类型',
    unit_price       varchar(32)                           null comment '商品单价(不含税)',
    unit_price_vat   varchar(32)                           null comment '商品单价(含税)',
    vat              varchar(32)                           null comment '税率',
    vendor_code      varchar(32) default '0'               not null comment '供应商编码',
    vendor           varchar(32)                           null comment '供应商',
    valid_started_at datetime                              null comment '有效开始时间',
    valid_ended_at   datetime                              null comment '有效结束时间',
    created_by       varchar(128)                          null comment '更新人',
    created_at       datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at       datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by       varchar(128)                          null comment '更新人'
)
    comment 'sku单价税率表' charset = utf8;

create table if not exists virgo_settle_sum_data
(
    id                         bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    cogs                       varchar(32) default '0'               not null comment 'ulp总金额占比',
    opex                       varchar(32) default '0'               not null comment '渠道总金额占比',
    settle_cogs                varchar(32) default '0'               not null comment 'ulp总结算金额占比',
    settle_opex                varchar(32) default '0'               not null comment '渠道总结算金额占比',
    tmall_settle_amount        varchar(32) default '0'               not null comment '天猫结算金额总额（不含税）',
    wechat_settle_amount       varchar(32) default '0'               not null comment '微信结算金额总额（不含税）',
    o2o_settle_amount          varchar(32) default '0'               not null comment 'o2o结算金额总额（不含税）',
    jd_settle_amount           varchar(32) default '0'               not null comment '京东结算金额总额（不含税）',
    tmall_settle_amount_vat    varchar(32) default '0'               not null comment '天猫结算金额总额（含税）',
    wechat_settle_amount_vat   varchar(32) default '0'               not null comment '微信结算金额总额（含税）',
    o2o_settle_amount_vat      varchar(32) default '0'               not null comment 'o2o结算金额总额（含税）',
    jd_settle_amount_vat       varchar(32) default '0'               not null comment '京东结算金额总额（含税）',
    gift_total_count           bigint      default 0                 not null comment '礼品总数',
    coupon_total_count         bigint      default 0                 not null comment '优惠券总数',
    gift_total_amount          varchar(32) default '0'               not null comment '礼品总金额',
    coupon_total_amount        varchar(32) default '0'               not null comment '优惠券总金额',
    gift_total_settle_count    bigint      default 0                 not null comment '礼品结算总数',
    coupon_total_settle_count  bigint      default 0                 not null comment '优惠券结算总数',
    gift_total_settle_amount   varchar(32) default '0'               not null comment '礼品总结算金额',
    coupon_total_settle_amount varchar(32) default '0'               not null comment '优惠券总结算金额',
    month                      varchar(6)                            not null comment '结算周期',
    created_by                 varchar(128)                          null comment '更新人',
    created_at                 datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at                 datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by                 varchar(128)                          null comment '更新人'
)
    comment '结算汇总数据表' charset = utf8;

create table if not exists virgo_settle_summary
(
    id                  bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    gl_code             varchar(32)                        not null comment '积分账户，10000为礼享 20000为臻选',
    channel             varchar(32)                        not null comment '渠道',
    type                varchar(32)                        null comment '类型',
    previous_balance    varchar(32)                        null comment '上月余额',
    newly_earned_points varchar(32)                        null comment '本月新增',
    redeemed_points     varchar(32)                        null comment '本月使用',
    point_settled       varchar(32)                        null comment '本月结算',
    epxpired_points     varchar(32)                        null comment '本月过期',
    projected_rate      varchar(32)                        null comment '预期比例',
    remaining_balance   varchar(32)                        null comment '账户剩余',
    ulp_cpp             varchar(32)                        null,
    cpp                 varchar(32)                        null,
    liablity_channel    varchar(32)                        null,
    liablity_rmb        varchar(32)                        null comment '不含税rmb',
    liablity_rmb_vat    varchar(32)                        null comment '含税rmb',
    month               varchar(6)                         not null comment '结算周期',
    level               int                                null comment '排序权重',
    created_by          varchar(128)                       null comment '更新人',
    created_at          datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at          datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by          varchar(128)                       null comment '更新人'
)
    comment '结算一览表' charset = utf8;

create table if not exists virgo_settle_tmall_summary
(
    id                  bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    gl_code             varchar(32)                        not null comment '积分账户，10000为礼享 20000为臻选',
    channel             varchar(32)                        not null comment '渠道',
    type                varchar(32)                        null comment '类型',
    previous_balance    varchar(32)                        null comment '上月余额',
    newly_earned_points varchar(32)                        null comment '本月新增',
    redeemed_points     varchar(32)                        null comment '本月使用',
    point_settled       varchar(32)                        null comment '本月结算',
    epxpired_points     varchar(32)                        null comment '本月过期',
    projected_rate      varchar(32)                        null comment '预期比例',
    remaining_balance   varchar(32)                        null comment '账户剩余',
    ulp_cpp             varchar(32)                        null,
    cpp                 varchar(32)                        null,
    liablity_channel    varchar(32)                        null,
    liablity_rmb        varchar(32)                        null comment '不含税rmb',
    liablity_rmb_vat    varchar(32)                        null comment '含税rmb',
    month               varchar(6)                         not null comment '结算周期',
    level               int                                null comment '排序权重',
    created_by          varchar(128)                       null comment '更新人',
    created_at          datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at          datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by          varchar(128)                       null comment '更新人'
)
    comment '天猫结算一览表' charset = utf8;

create table if not exists virgo_settle_type_cfg
(
    id               bigint auto_increment
        constraint `PRIMARY`
        primary key,
    settle_type_code varchar(64) default ''                not null comment '结算类型编码',
    settle_type_name varchar(64) default ''                null comment '结算类型名称',
    gl_code          varchar(64)                           not null comment '账户科目',
    status           varchar(32) default 'DRAFT'           not null comment 'DRAFT：草稿 ,ENABLED:启用, DISABLED:停用,OVERDUE：失效',
    remark           varchar(1024)                         null comment '说明',
    level            int                                   null comment '排序权重 越小越前',
    created_by       varchar(128)                          null comment '更新人',
    created_at       datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at       datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by       varchar(128)                          null comment '更新人',
    flow_id          varchar(63)                           null comment '流程实例id',
    audit_status     varchar(31)                           null comment '审批状态',
    constraint index_settle_type_code
        unique (settle_type_code)
)
    comment '结算类型配置表' charset = utf8;

create table if not exists virgo_settle_type_mapping_cfg
(
    id               bigint auto_increment
        constraint `PRIMARY`
        primary key,
    settle_type_code varchar(64)                        not null comment '结算类型编码',
    settle_type_name varchar(64)                        not null comment '结算类型名称',
    gl_code          varchar(64)                        not null comment '账户科目',
    biz_source_type  varchar(32)                        null comment '业务类型',
    remark           varchar(1024)                      null comment '说明',
    created_by       varchar(128)                       null comment '更新人',
    created_at       datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at       datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by       varchar(128)                       null comment '更新人',
    constraint index_source_code
        unique (gl_code, biz_source_type)
)
    comment '结算类型映射配置表' charset = utf8;

create index index_type_code
    on virgo_settle_type_mapping_cfg (settle_type_code);

create table if not exists virgo_settle_wechat_summary
(
    id                  bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    gl_code             varchar(32)                        not null comment '积分账户，10000为礼享 20000为臻选',
    channel             varchar(32)                        not null comment '渠道',
    type                varchar(32)                        null comment '类型',
    previous_balance    varchar(32)                        null comment '上月余额',
    newly_earned_points varchar(32)                        null comment '本月新增',
    redeemed_points     varchar(32)                        null comment '本月使用',
    point_settled       varchar(32)                        null comment '本月结算',
    epxpired_points     varchar(32)                        null comment '本月过期',
    projected_rate      varchar(32)                        null comment '预期比例',
    remaining_balance   varchar(32)                        null comment '账户剩余',
    ulp_cpp             varchar(32)                        null,
    cpp                 varchar(32)                        null,
    liablity_channel    varchar(32)                        null,
    liablity_rmb        varchar(32)                        null comment '不含税rmb',
    liablity_rmb_vat    varchar(32)                        null comment '含税rmb',
    month               varchar(6)                         not null comment '结算周期',
    created_by          varchar(128)                       null comment '更新人',
    created_at          datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at          datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by          varchar(128)                       null comment '更新人'
)
    comment '微信结算一览表' charset = utf8;

create table if not exists virgo_trans
(
    id                 varchar(20)                           not null,
    tenant_id          bigint                                not null comment '租户id',
    owner_id           varchar(32) default ''                not null comment '所属者id',
    account_id         bigint                                not null comment '账户id',
    gl_code            varchar(64)                           not null comment '账户科目',
    trans_type         varchar(64)                           not null comment '交易业务类型',
    target_account_id  bigint                                null comment '目标账户ID',
    biz_no             varchar(64)                           not null,
    biz_type           varchar(32) default ''                not null comment '外部业务类型代码',
    biz_source         varchar(32)                           null comment '交易单据来源',
    biz_source_type    varchar(32)                           null comment '交易单据来源类型',
    amount             bigint      default 0                 not null comment '账户当前数额',
    fin_change_amount  bigint      default 0                 not null comment '交易最终变动资产',
    up_amount          bigint      default 0                 not null comment '正向数额',
    down_amount        bigint      default 0                 not null comment '扣减数额',
    trade_money        bigint      default 0                 not null comment '交易金额',
    compute_money      bigint      default 0                 not null comment '计算金额',
    refund_money       bigint      default 0                 not null comment '退款金额',
    hash_code          varchar(32)                           not null comment '唯一索引，用于幂等',
    operate_type       varchar(16) default ''                not null comment 'UP: changeAmount为正, DOWN:changeAmount为负',
    status             varchar(16)                           not null comment '状态 INIT:初始化,PROCESSING:处理中(资产未到账),DONE:交易处理完成(资产到帐),PARTDONE:部分到账,FAIL:失败(交易处理失败)',
    traded_at          datetime    default CURRENT_TIMESTAMP not null comment '交易时间',
    is_used_budget     smallint(1) default 0                 not null comment '是否使用预算 0 未使用 1 使用',
    rule_codes         text                                  not null comment '积分规则',
    source_bizs        text                                  null comment '来源单信息',
    reason             text                                  null comment '变更原因',
    fail_reason        text                                  null comment '失败原因',
    ext1               text                                  null comment '是否可冲正',
    ext2               text                                  null comment '产品类型',
    ext3               text                                  null comment '产品名称',
    ext4               text                                  null comment '订单信息',
    extra_json         text                                  null comment '扩展json字段',
    created_at         datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at         datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by         varchar(128)                          null comment '更新人',
    order_id           varchar(64)                           null comment '业务方订单号',
    dl_auto_created_at datetime    default CURRENT_TIMESTAMP not null comment '数据入湖时间',
    dl_auto_updated_at datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '数据更新时间',
    constraint `PRIMARY`
        primary key (id),
    constraint idx_bbt
        unique (biz_no, biz_type, biz_source_type, tenant_id),
    constraint idx_gbbo
        unique (biz_no, biz_type, biz_source_type, operate_type, gl_code)
)
    charset = utf8;

create index id_order_id
    on virgo_trans (order_id);

create index idx_virgo_trans_created
    on virgo_trans (created_at);

create index idx_virgo_vat_account_id
    on virgo_trans (account_id);

create index index_owner_id
    on virgo_trans (owner_id);

create table if not exists virgo_trans_debet
(
    id         bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id  bigint                                   not null comment '租户ID',
    account_id bigint                                   not null comment '账户ID',
    trade_no   varchar(32)                              not null comment '账户中心交易流水号',
    ex_rule    bigint                                   not null comment '兑换规则id，唯一值',
    amount     bigint         default 0                 not null comment '数额',
    money      decimal(10, 2) default 0.00              not null comment '钱',
    status     varchar(16)                              not null comment '状态 DEBT: 负债 REPAYING:偿还中, REPAID:已偿还',
    ext1       text                                     null comment '预留字段1',
    ext2       text                                     null comment '预留字段2',
    ext3       text                                     null comment '预留字段3',
    extra_json text                                     null comment '扩展json字段',
    created_at datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at datetime       default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by varchar(128)                             null comment '更新人',
    constraint trade_no
        unique (trade_no, tenant_id)
);

create table if not exists virgo_trans_details
(
    id              bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id       bigint                                not null comment '租户id',
    owner_id        varchar(32) default ''                not null comment '所属者id',
    account_id      bigint                                not null comment '账户id',
    gl_code         varchar(64)                           not null comment '账户科目',
    trade_no        varchar(32)                           not null comment '账户中心交易流水号',
    source_trade_no varchar(32)                           not null comment '来源单流水号',
    biz_no          varchar(64)                           not null,
    biz_type        varchar(32) default ''                not null comment '外部业务类型代码-冗余',
    biz_source      varchar(32)                           null,
    biz_source_type varchar(32)                           null,
    hash_code       varchar(32)                           not null comment '唯一索引，用于幂等',
    rule            varchar(32)                           not null comment '规则id，唯一值',
    amount          bigint      default 0                 not null comment '数额(类型为DOWN时表示已扣减)',
    used_amount     bigint      default 0                 not null comment '已核销数额(类型为DOWN时表示已偿还)',
    rest_amount     bigint      default 0                 not null comment '剩余数额(类型为DOWN时为剩余负债)',
    debt            bigint      default 0                 not null comment '负债',
    repay           bigint      default 0                 not null comment '还债',
    rest_debt       bigint      default 0                 not null comment '剩余负债',
    operate_type    varchar(16)                           not null comment 'UP(增加）, DOWN(减少)',
    status          varchar(16)                           not null comment '明细状态 INIT:未使用, USING:使用中, USED:已使用, EXPIRED:已过期, DEBT: 负债REPAYING:偿还中, REPAID:已偿还,UNPROCESSED',
    reason          varchar(128)                          null comment '变更原因',
    traded_at       datetime    default CURRENT_TIMESTAMP not null comment '交易时间',
    expired_at      datetime                              null comment '失效时间, 该字段使用与否取决 ALLOW_EXPIRE 规则',
    ext1            text                                  null comment '预留字段1',
    ext2            text                                  null comment '预留字段2',
    ext3            text                                  null comment '预留字段3',
    extra_json      text                                  null comment '扩展json字段',
    created_at      datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at      datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by      varchar(128)                          null comment '更新人'
)
    charset = utf8;

create index idx_traded_at
    on virgo_trans_details (traded_at);

create index idx_virgo_vatd_account_id
    on virgo_trans_details (account_id);

create index idx_virgo_vatd_biz_no_type_un
    on virgo_trans_details (biz_no, biz_type);

create index idx_virgo_vatd_member_id
    on virgo_trans_details (owner_id);

create index idx_virgo_vatd_trade_no
    on virgo_trans_details (trade_no);

create table if not exists virgo_trans_divide
(
    id                bigint auto_increment
        constraint `PRIMARY`
        primary key,
    trans_id          varchar(20)                           not null comment '交易流水ID',
    source_trans_id   varchar(20) default ''                null comment '扣减积分来源单交易流水ID',
    fin_change_amount bigint      default 0                 not null comment '交易最终变动资产',
    divide_json       text                                  null comment '积分分摊json字段',
    operate_type      varchar(20) default ''                null comment 'UP: changeAmount为正, DOWN:changeAmount为负''',
    biz_type          varchar(256)                          null comment '业务类型',
    channel           varchar(128)                          null comment '渠道',
    ext1              text                                  null comment '扩展字段1',
    ext2              text                                  null comment '扩展字段2',
    ext3              text                                  null comment '扩展字段3',
    extra_json        text                                  null comment '扩展json字段',
    created_at        datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at        datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by        varchar(128)                          null comment '更新人'
)
    charset = utf8;

create index index_trans
    on virgo_trans_divide (trans_id);

create table if not exists virgo_trans_operate
(
    id                bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    gl_code           varchar(32)                        not null comment '账户科目',
    owner_id          varchar(32)                        not null comment '所属者id',
    account_id        bigint                             not null comment '账户id',
    detail_id         bigint                             not null comment '明细ID',
    related_detail_id bigint                             not null comment '与明细ID关联的明细',
    budget_id         bigint                             null comment '预算ID',
    change_amount     bigint   default 0                 not null comment '变更数额 正数',
    return_amount     bigint   default 0                 not null comment '退款数额',
    operate_type      varchar(16)                        not null comment 'UP(增加）, DOWN(减少)',
    reason            varchar(128)                       null comment '变更原因',
    ext1              text                               null comment '预留字段1',
    ext2              text                               null comment '预留字段2',
    ext3              text                               null comment '预留字段3',
    extra_json        text                               null comment '扩展json字段',
    created_at        datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at        datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by        varchar(128)                       null comment '更新人'
)
    charset = utf8;

create index idx_virgo_vatc_account_id
    on virgo_trans_operate (account_id);

create index idx_virgo_vatc_credit_trans_detail_id
    on virgo_trans_operate (detail_id);

create index idx_virgo_vatc_debit_trans_detail_id
    on virgo_trans_operate (related_detail_id);

create index idx_virgo_vatc_member_id
    on virgo_trans_operate (owner_id);

create table if not exists virgo_trans_refund
(
    id              bigint auto_increment
        constraint `PRIMARY`
        primary key,
    tenant_id       bigint                                not null comment '租户id',
    gl_code         varchar(64)                           not null comment '科目',
    account_id      bigint                                not null comment '账户ID',
    owner_id        varchar(32)                           not null comment '所属者id',
    trade_no        varchar(32)                           not null comment '流水',
    trans_biz_no    varchar(64)                           not null,
    trans_biz_type  varchar(32) default ''                not null comment '业务类型',
    source_trans_no varchar(32) default ''                not null comment '来源单流水号',
    source_biz_no   varchar(64)                           not null,
    source_biz_type varchar(32) default ''                not null comment '来源单业务类型',
    refund_money    bigint      default 0                 not null comment '退款金额',
    refund_amount   bigint      default 0                 not null comment '退款数额',
    operate_type    varchar(16)                           not null comment 'UP(增加）, DOWN(减少)',
    status          varchar(16)                           not null comment 'CORRECT,REFUND',
    reason          varchar(255)                          null comment '变更原因',
    extra_json      text                                  null comment '扩展字段',
    created_at      datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at      datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    constraint trade_no
        unique (trade_no, source_trans_no)
)
    charset = utf8;

create table if not exists virgo_trans_rule_unit
(
    id          bigint(64) auto_increment
        constraint `PRIMARY`
        primary key,
    name        varchar(32)                        not null comment '规则名',
    description varchar(256)                       null comment '规则描述',
    type        varchar(16)                        not null comment 'EXCHANGE:根据金额兑换, FIXED:固定数值, ',
    extra_json  text                               null comment '扩展字段',
    created_at  datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at  datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by  varchar(128)                       null comment '更新人'
)
    comment '账户交易规则单元' charset = utf8;

create table if not exists virgo_trans_rules
(
    id            bigint auto_increment
        constraint `PRIMARY`
        primary key,
    name          varchar(32)                           not null comment '规则名',
    gl_code       varchar(64)                           not null comment '账户科目',
    code          varchar(64) default ''                not null comment '规则CODE',
    budget_id     bigint                                null comment '预算池ID',
    budget_name   varchar(128)                          null comment '预算池名称',
    description   varchar(256)                          null comment '规则描述',
    duration      varchar(16)                           not null comment '有效期规则 如P1Y表示有效期1年, PT1H有效期1小时',
    rule_exp      varchar(1024)                         null comment '规则json表达式',
    operate_type  varchar(16) default ''                null comment 'UP(增加）, DOWN(减少)',
    status        varchar(16)                           not null comment 'ENABLED:启用, DISABLED:停用',
    system_config varchar(16) default 'YES'             not null comment 'YES:系统配置,  NO:非系统配置(可修改)',
    extra_json    text                                  null comment '扩展字段',
    created_at    datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at    datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by    varchar(128)                          null comment '更新人',
    constraint idx_virgo_vatr_gl_code_code_oper_unq
        unique (gl_code, code)
)
    comment '账户交易规则表' charset = utf8;

create index idx_virgo_vatr_code
    on virgo_trans_rules (code);

create table if not exists virgo_trans_rules_extend
(
    id                bigint auto_increment
        constraint `PRIMARY`
        primary key,
    trans_rules_id    bigint   default 0                 not null comment '积分规则表主键',
    exchange_type     tinyint  default 1                 not null comment '积分类型 1:动作积分 2:消费积分 3:倍率积分',
    score             bigint                             null comment '积分类型：动作积分表示分值，消费积分表示积分比例，倍率积分表示积分倍率',
    action            varchar(128)                       null comment '行为事件',
    channel_type      varchar(128)                       null comment '渠道类型 1:天猫 2:官网 3:微信商城 4:微信公众号',
    channel_factor    smallint(8)                        null comment '渠道积分倍率',
    cost_rule_exp     varchar(1024)                      null comment '成本分摊比例json表达式',
    trans_expire_type tinyint  default 1                 not null comment '积分有效期 1:永久  2:固定',
    trans_time        tinyint                            null comment '积分固定时间',
    rules_expire_type tinyint  default 1                 not null comment '规则有效期 1:永久  3:自定义时间',
    rules_started_at  datetime                           null comment '规则开始时间',
    rules_ended_at    datetime                           null comment '规则结束时间',
    created_at        datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at        datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by        varchar(128)                       null comment '更新人',
    created_by        varchar(128)                       null comment '创建人',
    change_type       varchar(256)                       null comment '积分变化类型',
    max_count         smallint(8)                        null comment '最大积分发送次数',
    flow_id           varchar(63)                        null comment '流程实例id',
    audit_status      varchar(31)                        null comment '审批状态'
)
    comment '积分规则扩展表' charset = utf8;

create index idx_trans_rules_id
    on virgo_trans_rules_extend (trans_rules_id);

create table if not exists virgo_vendor_info
(
    id           bigint unsigned auto_increment
        constraint `PRIMARY`
        primary key,
    vendor_code  varchar(32) default '0'               not null comment '供应商编码',
    vendor       varchar(32) default '0'               not null comment '供应商名称',
    status       varchar(16)                           not null comment 'DRAFT：草稿 ,ENABLED:启用, DISABLED:停用,OVERDUE：失效',
    created_by   varchar(128)                          null comment '更新人',
    created_at   datetime    default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at   datetime    default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    updated_by   varchar(128)                          null comment '更新人',
    flow_id      varchar(63)                           null comment '流程实例id',
    audit_status varchar(31)                           null comment '审批状态'
)
    comment '供应商信息' charset = utf8;

create index index_vendor_code
    on virgo_vendor_info (vendor_code);


